import {RouteDefinition, RouteGroup } from ".";
import ComingSoon from "../views/common/ComingSoon";
import {SettingOutlined} from "@ant-design/icons";
import NewUserView from "../views/administration/NewUserView";
import UsersView from "../views/administration/UsersView";
import SingleUserView from "../views/administration/SingleUserView";
import CourseDirectory from "../views/CourseDirectory/CourseDirectory";
import FacultyViewCourse from "../views/CourseDirectory/FacultyViewCourse";
import Terms from '../views/Terms/Terms';
import Campus from '../views/Campus/Campus';
import ClassLocation from '../views/ClassLocation/ClassLocation';

export const courseDirectoryRoute: RouteDefinition = {
	name: 'Course Directory',
	path: '/coursedirectory',
	exact: false,
	component: CourseDirectory,
	visibleInMenu: true,
	orderInGroup: 1
}

export const facultyViewCourse : RouteDefinition = {
	name: "Faculty Course",
	path: "/facultyviewcourse",
	exact: false,
	component: FacultyViewCourse,
	visibleInMenu: false,
	orderInGroup: 2
}

export const viewUserRoute: RouteDefinition = {
	name: 'View User',
	path: '/users/:userId',
	exact: false,
	component: SingleUserView,
	visibleInMenu: false,
	orderInGroup: -100
}

export const usersRoute: RouteDefinition = {
	name: 'Users',
	path: '/users',
	exact: false,
	component: UsersView,
	visibleInMenu: true,
	orderInGroup: 3
}

export const newUserRoute: RouteDefinition = {
	name: 'New User',
	path: '/newuser',
	exact: false,
	component: NewUserView,
	visibleInMenu: true,
	orderInGroup: 4
}

export const termRoute: RouteDefinition = {
	name: 'Term',
	path: '/term',
	exact: false,
	component: Terms,
	visibleInMenu: true,
	orderInGroup: 2
}

export const campusRoute: RouteDefinition = {
	name: 'Campus',
	path: '/campus',
	exact: false,
	component: Campus,
	visibleInMenu: false,
	orderInGroup: 1
}

export const classLocationRoute: RouteDefinition = {
	name: 'Class Location',
	path: '/classlocation',
	exact: false,
	component: ClassLocation,
	visibleInMenu: false,
	orderInGroup: 1
}

export const administrationRouteGroup: RouteGroup = {
	name: 'Administration',
	key: '6',
	displayAsGroup: true,
	icon: <SettingOutlined />,
	routes: [courseDirectoryRoute, facultyViewCourse, viewUserRoute, usersRoute, newUserRoute, termRoute, classLocationRoute, campusRoute],
	orderInMenu: 100
}