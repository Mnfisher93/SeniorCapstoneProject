import {HomeOutlined, FontColorsOutlined, CreditCardOutlined, FileOutlined, FormOutlined, DollarOutlined, ScheduleOutlined} from '@ant-design/icons';
import Home from '../views/common/Home';
import ComingSoon from '../views/common/ComingSoon'
import TermsRegistration from '../views/common/Registration/TermsRegistration'
import ClassRegistration from '../views/common/Registration/ClassRegistration'
import {ReactNode} from 'react';
import {administrationRouteGroup} from "./administration";

import CourseDirectory from '../views/CourseDirectory/CourseDirectory';
import FacultyViewCourse from '../views/CourseDirectory/FacultyViewCourse';
import Terms from '../views/Terms/Terms';
import Campus from '../views/Campus/Campus';
import ClassLocation from '../views/ClassLocation/ClassLocation';
import RegistrationStatus from '../views/common/Registration/RegistrationStatus';
import Status from '../views/common/Registration/Status';

export interface RouteGroup {
	name?: string;
	routes: RouteDefinition[];
	icon?: any;
	displayAsGroup: boolean;
	orderInMenu: number;
	key: string;
}

export interface RouteDefinition {
	name: string;
	path: string;
	exact: boolean;
	component: any;
	permissionKey?: string;
	icon?: ReactNode;
	visibleInMenu: boolean;
	orderInGroup: number;
}

// Visible Routes
export const homeRoute: RouteDefinition = {
	name: 'Home',
	path: '/',
	exact: true,
	component: Home,
	visibleInMenu: true,
	icon:<HomeOutlined />,
	orderInGroup: 1
}

//Registration Routes
export const addDropRoute: RouteDefinition = {
	name: 'Add or Drop Classes',
	path: '/termSelection',
	exact: false,
	component: TermsRegistration,
	visibleInMenu: true,
	orderInGroup: 1
}
export const registrationRoute: RouteDefinition = {
	name: 'Register',
	path: '/classRegistration',
	exact: false,
	component: ClassRegistration,
	visibleInMenu: false,
	orderInGroup: 1
}
export const degreeWorksRoute: RouteDefinition = {
	name: 'DegreeWorks',
	path: '/degreeworks',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 2
}
export const scheduleRoute: RouteDefinition = {
	name: 'Schedule Builder',
	path: '/schedulebuilder',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 3
}
export const lookUpRoute: RouteDefinition = {
	name: 'Look Up Classes',
	path: '/lookupclasses',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 4
}
export const registrationStatusRoute: RouteDefinition = {
	name: 'Registration Status',
	path: '/registrationstatusterm',
	exact: false,
	component: RegistrationStatus,
	visibleInMenu: true,
	orderInGroup: 5
}
export const requestEnrollmentRoute: RouteDefinition = {
	name: 'Request Enrollment Verification',
	path: '/requestenrollment',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 6
}

export const viewHoldsRoute: RouteDefinition = {
	name: 'View Holds',
	path: '/viewholds',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 7
}

export const statusRoute: RouteDefinition = {
	name: 'Status',
	path: '/registrationstatus',
	exact: false,
	component: Status,
	visibleInMenu: false,
	orderInGroup: 5
}

// Current Term Routes
export const conciseRoute: RouteDefinition = {
	name: 'Concise Student Schedule',
	path: '/concise',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 1
}
export const weekAtAGlanceRoute: RouteDefinition = {
	name: 'Week at a Glance',
	path: '/weekataglance',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 2
}
export const accessBlackBoardRoute: RouteDefinition = {
	name: 'Access Blackboard',
	path: '/accessblackboard',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 3
}
export const academicCalendarRoute: RouteDefinition = {
	name: 'Academic Calendar',
	path: '/academiccalendar',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 4
}
export const finalExamScheduleRoute: RouteDefinition = {
	name: 'Final Exam Schedule',
	path: '/finalexamschedule',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 5
}
export const applyToGraduateRoute: RouteDefinition = {
	name: 'Apply to Graduate - Law Students',
	path: '/applytograduatelaw',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 6
}
export const orderTextbooksRoute: RouteDefinition = {
	name: 'Order Textbooks - Fall 2021 TTU',
	path: '/ordertextbooks',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 7
}

// Grades Routes
export const finalGradesRoute: RouteDefinition = {
	name: 'Final Grades',
	path: '/finalgrades',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 1
}
export const midtermGradesRoute: RouteDefinition = {
	name: 'Midterm Grades',
	path: '/midtermgrades',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 2
}
export const gpaCalculatorRoute: RouteDefinition = {
	name: 'GPA Calculator',
	path: '/gpacalculator',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 3
}

// Transcript Routes
export const unofficialTranscriptRoute: RouteDefinition = {
	name: 'Unofficial Transcript - View Online',
	path: '/unofficialtranscript',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 1
}
export const ttuTranscriptRequestRoute: RouteDefinition = {
	name: 'TTU Transcript Request',
	path: '/ttutranscriptrequest',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 2
}
export const ttuTranscriptStatusRoute: RouteDefinition = {
	name: 'TTU Transcript Status',
	path: '/ttutranscriptstatus',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 3
}
export const lawTranscriptRequestRoute: RouteDefinition = {
	name: 'Law Transcript Request',
	path: '/lawtranscriptrequest',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 4
}
export const lawTranscriptStatus: RouteDefinition = {
	name: 'Law Transcript Status',
	path: '/lawtranscriptstatus',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 5
}

//SBS routes
export const eBillRoute: RouteDefinition = {
	name: 'eBill',
	path: '/ebill',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 1
}
export const payingTheBillRoute: RouteDefinition = {
	name: 'Paying the Bill Checklist',
	path: '/payingthebill',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 2
}
export const myDirectDepoistRoute: RouteDefinition = {
	name: 'My Direct Deposit',
	path: '/mydirectdeposit',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 3
}
export const internationalPaymentsRoute: RouteDefinition = {
	name: 'International Payments',
	path: '/internationalpayments',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 4
}
export const globalElectronicConsent: RouteDefinition = {
	name: 'Global Electronic Consent',
	path: '/globalelectronicconsent',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 5
}
export const importantChanges1098Route: RouteDefinition = {
	name: 'Important Changes to 2018 1098-T',
	path: '/importantchangesto1098',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 6
}
export const view1098Route: RouteDefinition = {
	name: '1098T - View and Print',
	path: '/view1098',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 7
}
export const electToPayApplicationRoute: RouteDefinition = {
	name: 'Elect to Pay Application',
	path: '/electtopayapplication',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 8
}

//Aid Routes
export const viewAcceptAidPackageRoute: RouteDefinition = {
	name: 'View/Accept Aid Package',
	path: '/viewacceptaidpackage',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 1
}
export const documentationRequestedRoute: RouteDefinition = {
	name: 'Document Requested and Submitted (Missing Information)',
	path: '/documentrequestedandsubmitted',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 2
}
export const myLoansRoute: RouteDefinition = {
	name: 'My Loan(s)',
	path: '/myloans',
	exact: false,
	component: ComingSoon,
	visibleInMenu: true,
	orderInGroup: 3
}

// Hidden Routes

// Route Groups

export const indexRouteGroup: RouteGroup = {
	key:'-1',
	displayAsGroup: false,
	routes: [homeRoute],
	orderInMenu: 0
}
export const registrationRouteGroup: RouteGroup = {
	name:'Registration',
	key:'0',
	displayAsGroup: true,
	icon: <FormOutlined />,
	routes: [addDropRoute, degreeWorksRoute, scheduleRoute, lookUpRoute, registrationStatusRoute, requestEnrollmentRoute, viewHoldsRoute,],
	orderInMenu: 2
}
export const currentTermRouteGroup: RouteGroup = {
	name: 'Current Term',
	key:'1',
	icon: <ScheduleOutlined />,
	displayAsGroup: true,
	routes: [conciseRoute, weekAtAGlanceRoute, accessBlackBoardRoute, academicCalendarRoute, finalExamScheduleRoute, applyToGraduateRoute, orderTextbooksRoute],
	orderInMenu: 3
}
export const gradesRouteGroup: RouteGroup = {
	name: 'Grades',
	key:'2',
	icon: <FontColorsOutlined />,
	displayAsGroup: true,
	routes: [finalGradesRoute, midtermGradesRoute, gpaCalculatorRoute],
	orderInMenu: 4
}
export const transcriptRouteGroup: RouteGroup = {
	name: 'Transcript',
	key:'3',
	icon: <FileOutlined /> ,
	displayAsGroup: true,
	routes: [unofficialTranscriptRoute, ttuTranscriptRequestRoute, ttuTranscriptStatusRoute, lawTranscriptRequestRoute, lawTranscriptStatus],
	orderInMenu: 5
}
export const sbsRouteGroup: RouteGroup = {
	name: 'Student Business Services',
	key:'4',
	icon: <CreditCardOutlined />,
	displayAsGroup: true,
	routes: [eBillRoute, payingTheBillRoute, myDirectDepoistRoute, internationalPaymentsRoute, globalElectronicConsent, importantChanges1098Route, view1098Route, electToPayApplicationRoute],
	orderInMenu: 6
}
export const aidRouteGroup: RouteGroup = {
	name: 'Financial Aid & Scholarships',
	key:'5',
	icon: <DollarOutlined />,
	displayAsGroup: true,
	routes: [viewAcceptAidPackageRoute, documentationRequestedRoute, myLoansRoute],
	orderInMenu: 7
}

export const hiddenRouteGroup: RouteGroup = {
	name:"",
	key:"6",
	displayAsGroup:false,
	routes:[registrationRoute, statusRoute,],
	orderInMenu:8
}
export const routeGroups: RouteGroup[] = [hiddenRouteGroup, registrationRouteGroup, currentTermRouteGroup, gradesRouteGroup, transcriptRouteGroup, sbsRouteGroup, aidRouteGroup, administrationRouteGroup, indexRouteGroup];