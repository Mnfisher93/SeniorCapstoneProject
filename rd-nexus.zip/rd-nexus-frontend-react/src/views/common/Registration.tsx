import ClassRegistration from './Registration/ClassRegistration';
import TermsRegistration from './Registration/TermsRegistration';
const Registration = () => {
	return (
		<>
			<TermsRegistration/>
		</>
	);
}

export default Registration;