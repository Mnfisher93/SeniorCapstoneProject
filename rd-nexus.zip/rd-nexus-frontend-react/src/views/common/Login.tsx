import { useState, useEffect } from 'react';

import axios from 'axios';

import logo from '../../assets/png/nexus-logo-1.png';
import LightImage from '../../assets/png/LightImage.png';
import DarkImage from '../../assets/png/DarkMode.jpg';

import {Row, Col, Image, Typography, Form, Input, Button, Space, Layout, message, Switch} from 'antd';
import {UserOutlined, LockOutlined, BulbOutlined, BulbFilled} from "@ant-design/icons";
import {AUTH_API_ROOT} from "../../apiConfig";
import AuthService from "../../services/AuthService";

const authService = AuthService.getService();

const Login = () => {
	const [isSubmitting, setIsSubmitting] = useState(false);
	const [form] =  Form.useForm();

	const [backgroundImage, setBackgroundImage] = useState(LightImage);
	const darkSwitch = () => {

		if (backgroundImage === LightImage) {
			setBackgroundImage(DarkImage)
		}
		else {
			setBackgroundImage(LightImage)
		}

	}		

	const handleLogin = (values: any) => {
		setIsSubmitting(true);

		axios.get(`${AUTH_API_ROOT}/user/login`, {
			params: {
				username: values.username,
				password: values.password
			}
		})
		.then((response) => {
			authService.setTokens({accessToken: response.data.authToken, refreshToken: response.data.refreshToken});
			message.success('Successfully logged in.');

			setIsSubmitting(false);
			form.resetFields();
		})
		.catch((error) => {
			message.error('There was a problem logging in. Please try again later. If this error persists, please contact the application administrator.', 7)

			form.resetFields();
			setIsSubmitting(false);
		});
	}

	return (
		<Layout className="layout-background" style={{height: '100vh'}}>
			<Layout.Content style={{backgroundImage: `url(${backgroundImage})`, backgroundPosition: "center", backgroundRepeat: 'no-repeat', backgroundSize: 'cover'}}>
				<Row style = {{justifyContent: 'right', margin: '10px'}} align ={'top'} >
						<Switch 
      							checkedChildren={< BulbOutlined/>}
      							unCheckedChildren={<BulbFilled />}
								onChange = {darkSwitch}	
    					/>
				</Row>
				<Row justify={'center'} align={'middle'} style={{height: '100%'}}>
					<Row  className={'shadow-box'} style={{width: '50vw'}} >
						<Col className={'gutter-row'} span={12} style={{textAlign: 'center'}}>
							<Typography.Title></Typography.Title>
							<Image 
								src={logo}
								width={150}
								preview={false}
								
							/>
						</Col>
						<Col className={'gutter-row'} span={12} style={{textAlign: 'center'}}>
							<Typography.Title level={4}>Login</Typography.Title>
							<Form
								form={form}
								requiredMark={false}
								layout={'vertical'}
								onFinish={handleLogin}
								initialValues={{
									username: 'matt.padgett',
									password: 'dirt'
								}}
							>
								<Form.Item

									name={'username'}
									rules={[{ required: true, message: 'Please provide a username.'}]}
								>
									<Input
										prefix={<UserOutlined className="site-form-item-icon" />}
										placeholder="Username"
										autoFocus={true}
									/>
								</Form.Item>

								<Form.Item
									name={'password'}
									rules={[{ required: true, message: 'Please provide a password.'}]}
								>
									<Input
										prefix={<LockOutlined className="site-form-item-icon" />}
										type="password"
										placeholder="Password"
									/>
								</Form.Item>

								<Form.Item>
									<Space>
										<Button type={'primary'} htmlType={'submit'} loading={isSubmitting}>Login</Button>
										<Button type={'primary'} htmlType={'reset'} disabled={isSubmitting}>Clear</Button>
									</Space>
								</Form.Item>
							</Form>
						</Col>
					</Row>
				</Row>
			</Layout.Content>
			<Layout.Footer style={{backgroundColor: 'var(--off-white-shadow-light)'}}>
				<Row justify={'space-between'}>
					<Col>
						<Typography.Text>
							2000-2021 Nexus
						</Typography.Text>
					</Col>
					<Col>
						<Typography.Text>{`\u00a9 Raider Devs ${new Date().getFullYear()}`}</Typography.Text>
					</Col>
				</Row>
			</Layout.Footer>
		</Layout>
	);
}

export default Login;