import React, {useEffect} from 'react';

import {PageHeader, Typography} from "antd";

const ComingSoon = () => {
	return (
		<PageHeader title="Unimplemented">
			<Typography.Title level={4}>This module has not been implemented in our initial offering.</Typography.Title>
		</PageHeader>
	);
}

export default ComingSoon;