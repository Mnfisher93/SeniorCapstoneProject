import { useEffect, useState } from 'react';
import { schedulerTableFormatData, schedulerColumns } from './registrationData'
import { Table } from "antd";
import { CheckCircleFilled, QuestionCircleFilled } from '@ant-design/icons';
import '../../../assets/scss/nexus/_registration.scss';
import ReactDOMServer from 'react-dom/server';
const singleCellHeight = 39;
const singleCellWidth = 96.28;

export interface NexusSchedulerProps {
  showModal: Function;
  innerWidth: number;
  innerHeight: number;
  data: any;
  currentUserId: string;
}
function cleanArray(arr: any) {
  let obj: any = {}
  arr.forEach((item: any, i: any) => {
    obj[item[0]] = item;
  })
  arr = Object.values(obj);
  return arr
}
function dataParser(data: any, showModal: any) {
  let classBlocks: HTMLDivElement[] = [];
  let classesConflicts: any[] = [];
  let counter = 0;
  data?.forEach(function (item: any, index: number) {
    item?.times?.forEach(function (time: any, j: number) {
      const newDiv = document.createElement("div");
      let subTime = time.end - time.start;
      let topVar = Math.floor(time.start / 100) + (time.start % 100 / 60);
      newDiv.style.cssText = "width:" + singleCellWidth + "px;position:absolute;font-size:11px;padding:3px;text-decoration:underline; cursor:pointer;overflow:hidden";
      if (subTime > 100) {
        let hours = Math.floor(subTime / 100);
        let minutes = subTime % 100;
        subTime = (hours * 60) + minutes;
      }
      if (time.day == "M") {
        newDiv.style.left = singleCellWidth * 2 + "px";
      } else if (time.day == "T") {
        newDiv.style.left = singleCellWidth * 3 + "px";
      } else if (time.day == "W") {
        newDiv.style.left = singleCellWidth * 4 + "px";
      } else if (time.day == "R") {
        newDiv.style.left = singleCellWidth * 5 + "px";
      } else if (time.day == "F") {
        newDiv.style.left = singleCellWidth * 6 + "px";
      } else if (time.day == "S") {
        newDiv.style.left = singleCellWidth * 1 + "px";
      } else if (time.day == "A") {
        newDiv.style.left = singleCellWidth * 7 + "px";
      }
      newDiv.style.height = (subTime / 30) * singleCellHeight + "px";
      newDiv.className = "class" + (index + 1);
      newDiv.classList.add("SchedulerOverlay")
      newDiv.style.top = (topVar * 2) * singleCellHeight + "px";
      if (item.registrationStatus.toLowerCase() === "registered") {
        newDiv.innerHTML = ReactDOMServer.renderToString(<CheckCircleFilled style={{ color: '#039487' }} />) + " " + item.title;
      } else {
        newDiv.innerHTML = ReactDOMServer.renderToString(<QuestionCircleFilled style={{ color: '#eed202' }} />) + " " + item.title;
      }

      //Handle class conflicts if any
      let holder: any[] = [];
      classBlocks.forEach((block: any, i: number) => {
        const previousItemTop = parseInt(block.style.top, 10);
        const previousItemHeight = parseInt(block.style.height, 10);
        const previousItemLeft = parseInt(block.style.left, 10);
        const currentItemTop = parseInt(newDiv.style.top, 10);
        const currentItemLeft = parseInt(newDiv.style.left, 10);
        const checkCol = currentItemTop >= previousItemTop && currentItemTop < (previousItemTop + previousItemHeight);
        const checkRow = currentItemLeft == previousItemLeft
        if (checkCol && checkRow && !holder.includes(i)) {
          holder.push(i);
        }
        if (checkCol && checkRow && !holder.includes(counter)) {
          holder.push(counter)
        }
        if (checkCol && checkRow && !classesConflicts.includes(counter)) {
          //classesConflicts.push(counter);
        }
      })
      if (holder.length > 0) {
        classesConflicts.push(holder);
      }
      newDiv.addEventListener('click', showModal);
      classBlocks.push(newDiv);
      counter++;
    });
  })

  classesConflicts = cleanArray(classesConflicts);
  classesConflicts.forEach((item, i) => {
    let cout = 0;
    item.forEach((block: any, j: any) => {
      classBlocks[block].style.width = parseInt(classBlocks[block].style.width, 10) / item.length + "px";
      classBlocks[block].style.left = parseInt(classBlocks[block].style.left, 10) + ((parseInt(classBlocks[block].style.width, 10) * cout)) + "px";
      cout++
    })


  });

  document.querySelector("#classTable .ant-table-tbody")?.append(...classBlocks);
}
const Scheduler = (props: NexusSchedulerProps) => {
  const [classesRendered, setClassesRendered] = useState(false)

  useEffect(() => {
    //Table of the classes
    const innerTable = document.querySelector("#classTable .ant-table-body");
    let elements = document.querySelectorAll(".SchedulerOverlay");
    elements.forEach(item => { item.remove() });
    dataParser(props.data, props.showModal)
    setClassesRendered(!classesRendered);
    
    //Set the starting position of the scroll
    if (innerTable)
      innerTable.scrollTop = singleCellHeight * 18;
  },[props.data])

  return (
    <>
      <Table
        columns={schedulerColumns}
        dataSource={schedulerTableFormatData}
        pagination={false}
        size="small"
        bordered
        scroll={{ y: 360, x: 770 }}
        id="classTable"
        style={{ fontSize: "12px" }}
      />
    </>
  );
}

export default Scheduler;