import { useState } from 'react';
import { Redirect } from 'react-router'
import '../../../assets/scss/nexus/_registration.scss';
import { Typography, PageHeader, Row, Col, Select, Form, Button, Divider } from "antd";
const { Option } = Select;
const routes = [
	{
		path: 'index',
		breadcrumbName: 'Registration',
	},
	{
		path: 'first',
		breadcrumbName: 'Term Selection',
	},
];
const WWYLTD = [
	{
		options: [
			{ title: "Fall 2021 TTU", value: "1" },
			// { title: "Spring 2022 TTU", value: "2" },
			// { title: "Summer 2022 TTU", value: "3" },
			// { title: "Spring 2022 Law", value: "4" },
			// { title: "Fall 2021 TTU Vet School", value: "5" },
			// { title: "Spring 2022 Lubbock Medicine", value: "6" },
		],
	},
]

const RegistrationStatus = () => {
	const [selectedWWYLTD, setSelectedWWYLTD] = useState(WWYLTD[0]);
	const [redirect, setRedirect] = useState(false);
	const [termsForm] = Form.useForm();
	function onChange(value: any) {
		setSelectedWWYLTD(WWYLTD[value]);
	}
	const handleTermSelection = (values: any) => {
		console.log("Search for Classes API CALL: " + values.wwyltd);
		switch(values.wwyltd){
			case "0":
				setRedirect(true);
			
		}

	}
	if(redirect) {
		return (
			<Redirect to="/registrationstatus"/>
		)
	}
	return (
		<>
			<PageHeader
				className="site-page-header"
				title="Registration Status"
				breadcrumb={{ routes }}
				// subTitle="Select a Term"
			/>
			<Divider />
			<Form
				form={termsForm}
				onFinish={handleTermSelection}
			>
				<Row>
					<Col lg={24} xl={12} style={{ padding: '25px' }}>
						<Row justify="center">
							<Col xl={15} lg={24}>
								<Typography.Title level={3}>Registration Term</Typography.Title>
								<p>Select a term </p>
								<Form.Item name="wwyltd">
									<Select
										showSearch
										style={{ width: 200 }}
										placeholder="Choose an Option"
										optionFilterProp="children"
										onChange={onChange}
										filterOption={(input, option: any) =>
											option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
										}
									>
										
										
										<Option value="0">Fall 2021 TTU</Option>
										{/* <Option value="1">Spring 2022 TTU</Option>
										<Option value="2">Summer 2022 TTU</Option>
										<Option value="3">Spring 2022 Law</Option>
										<Option value="4">Fall 2021 TTU Vet School</Option>
										<Option value="5">Spring 2022 Lubbock Medicine</Option> */}

										
										{selectedWWYLTD.options.map((item) => {
											return (WWYLTD.values)
											// <Option value={item.title}>{item.title}</Option>
										})}
									</Select>
								</Form.Item>
								<Form.Item>
									<Button type="primary" htmlType={'submit'}>
										Submit
									</Button>
								</Form.Item>
							</Col>
						</Row>
					</Col>
				</Row>
			</Form>
		</>
	);
}

export default RegistrationStatus;