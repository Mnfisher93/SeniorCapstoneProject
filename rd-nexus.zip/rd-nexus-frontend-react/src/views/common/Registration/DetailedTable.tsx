import { detailedTableColumns } from './registrationData'
import { Table, Button, notification } from "antd";
import { useEffect, useState } from 'react';
import {regApi} from "../../../App";

export interface NexusDetailedTableProps {
    showModal: Function;
    innerWidth: number;
    innerHeight: number;
    data: any;
    currentUserId: string;
    updateData: Function;
}
const openErrorNotification = (title: any, desc: any) => {
    notification['error']({
        message: title,
        description: desc,
    });
};
const DetailedTable = (props: NexusDetailedTableProps) => {
    const [classData, setClassData] = useState(props.data);
    const [totalReg, setTotalReg] = useState(0);
      useEffect(()=>{
        setClassData(props.data);
      },[props.data])
    const summary = () => {
        const onClickHandler = () => {
            let total = 0;
            let addClasses:any = [];
            let deleteClasses:any = [];
            let values = document.querySelectorAll('#DetailedTable .ant-select');
            values.forEach((value: any) => {
                if(value.innerText === "Register"){
                    total += parseInt(value.attributes[2].value);
                    addClasses.push(value.attributes[1].value);
                    regApi.put(`RegistrationClasses/${props.currentUserId}/${value.attributes[1].value}`, {
                        registrationStatus: 'Registered'
                    }).then((r)=>{
                        props.updateData();
                    }).catch((e)=>{
                        console.log(e)
                    })
                } else {
                    deleteClasses.push(value.attributes[1].value)
                    regApi.delete(`RegistrationClasses/${props.currentUserId}/${value.attributes[1].value}`).then((r)=>{
                        props.updateData();
                    }).catch((e)=>{
                        console.log(e)
                    })
                }
            })
            if(total > 19) {
                openErrorNotification('Error: Class Limit','Can not register more than: ' + 19 + ' hours.')
                return;
            }
        }
        return (
            <Table.Summary fixed={true}>
                <Table.Summary.Row>
                    <Table.Summary.Cell index={0}>
                    </Table.Summary.Cell>
                    <Table.Summary.Cell index={1}>
                    </Table.Summary.Cell>
                    <Table.Summary.Cell index={2}>
                    </Table.Summary.Cell>
                    <Table.Summary.Cell index={3}>
                    </Table.Summary.Cell>
                    <Table.Summary.Cell index={4}>
                    </Table.Summary.Cell>
                    <Table.Summary.Cell index={5}>
                    </Table.Summary.Cell>
                    <Table.Summary.Cell index={6}>
                        <Button type="primary" onClick={onClickHandler}>Submit</Button>
                    </Table.Summary.Cell>
                </Table.Summary.Row>
            </Table.Summary>
        )
    }
    const footer = () => {
        let total = 0;
        let totalUnregistered = 0;
        classData.forEach((item :any) =>{
            if(item.status == "Registered")
                total += parseInt(item.hours);
            else
                totalUnregistered += parseInt(item.hours)
        })
        setTotalReg(total);
        return `Total Hours | Unregistered: ${totalUnregistered} | Registered: ${total} | Billing: ${total} | Min: 0 | Max: 19`
    }
    return (
        <>
            <Table
                columns={detailedTableColumns}
                dataSource={classData}
                pagination={false}
                scroll={{ y: 273, x: 914 }}
                size="small"
                id="DetailedTable"
                summary={summary}
                footer={footer}
            />
        </>
    );
}

export default DetailedTable;