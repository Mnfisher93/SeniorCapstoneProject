import { useEffect, useState } from 'react';
import { Redirect } from 'react-router'
import '../../../assets/scss/nexus/_registration.scss';
import { Typography, PageHeader, Row, Col, Select, Form, Button } from "antd";
import AuthService from "../../../services/AuthService";
import {courseApi} from "../../../App";
import { title } from 'process';
const { Option } = Select;


const authService = AuthService.getService();
const routes = [
	{
		path: 'index',
		breadcrumbName: 'Registration',
	},
	{
		path: 'first',
		breadcrumbName: 'Term Selection',
	},
];
const WWYLTD = (options : any) => [
	{
		title: "Prepare for Registration",
		desc: "View registration status, update student term data, and complete pre-registration requirements.",
		options,
	},
	{
		title: "Register For Classes",
		desc: "Search and register for your classes. You can view and manage your schedule.",
		options,
	},
	{
		title: "Plan Ahead",
		desc: "View your past schedules and your ungraded classes.",
		options,
	},
	{
		title: "Browse Classes",
		desc: "Looking for classes? In this section you can browse classes you find interesting.",
		options,
	},
	{
		title: "View Registration Information",
		desc: "View your past schedules and your ungraded classes.",
		options
	},
	{
		title: "Browse Course Catalog",
		desc: "Look up basic course information like subject, course and description.",
		options
	},

]
const TermsRegistration = () => {
	const [optionsArr, setOptionsArr] = useState([]);
	const [selectedWWYLTD, setSelectedWWYLTD] = useState(WWYLTD(optionsArr)[0]);
	const [redirect, setRedirect] = useState(false);
	const [termsForm] = Form.useForm();
	useEffect(() =>{
		courseApi.get("term").then((response) =>{
			
			let options : any = [];
			response.data.forEach((item:any, i: number) => {
				options.push({title:item.semester + item.year, value:i})
			});
			setOptionsArr(options);
		}).catch((e) =>{
			console.log(e)
		})
	},[])
	function onChange(value: any) {
		setSelectedWWYLTD(WWYLTD(optionsArr)[value]);
	}
	const handleTermSelection = (values: any) => {
		console.log("Search for Classes API CALL: " + values.wwyltd, values.term);
		switch (values.wwyltd) {
			case "0":
				setRedirect(true);
		}

	}
	if (redirect) {
		return (
			<Redirect to="/classRegistration" />
		)
	}
	return (
		<>
			<PageHeader
				className="site-page-header"
				title="Registration"
				breadcrumb={{ routes }}
				subTitle="Select a Term"
			/>
			<Form
				form={termsForm}
				onFinish={handleTermSelection}
			>
				<Row>
					<Col lg={24} xl={12} style={{ padding: '25px' }}>
						<Row justify="center">
							<Col xl={15} lg={24}>
								<Typography.Title level={3}>What Would You Like to Do?</Typography.Title>
								<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint dolore placeat aperiam in fugiat vel assumenda temporibus recusandae omnis non maxime necessitatibus possimus cupiditate rerum, error doloremque natus dolorem? Dolor!</p>
								<Form.Item name="wwyltd">
									<Select
										showSearch
										style={{ width: 200 }}
										placeholder="Choose an Option"
										optionFilterProp="children"
										onChange={onChange}
										filterOption={(input, option: any) =>
											option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
										}
									>
										<Option value="0">Prepare for Registration</Option>
										<Option value="1">Register for Classes</Option>
										<Option value="2">Plan Ahead</Option>
										<Option value="3">Browse Classes</Option>
										<Option value="4">View Registration Information</Option>
										<Option value="5">Browse Course Catalog</Option>
									</Select>
								</Form.Item>
							</Col>
						</Row>

					</Col>
					<Col lg={24} xl={12} style={{ padding: '25px' }}>
						<Row justify="center">
							<Col lg={24} xl={15}>
								<Typography.Title level={3}>{selectedWWYLTD.title}</Typography.Title>
								<p>{selectedWWYLTD.desc}</p>

								<Form.Item name="term">
									<Select
										showSearch
										style={{ width: 200, marginRight: "10px" }}
										placeholder="Choose an Option"
										optionFilterProp="children"
										filterOption={(input, option: any) =>
											option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
										}
									>
										{selectedWWYLTD.options.map((item : any) => {
											return (<Option value={item.title}>{item.title}</Option>)
										})}
									</Select>
								</Form.Item>
								<Form.Item>
									<Button type="primary" htmlType={'submit'}>
										Submit
									</Button>
								</Form.Item>

							</Col>
						</Row>
					</Col>
				</Row>
			</Form>
		</>
	);
}

export default TermsRegistration;