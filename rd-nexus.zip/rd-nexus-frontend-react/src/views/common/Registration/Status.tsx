import React, {useEffect, useState} from 'react';

import {PageHeader, Typography, Divider, Table, Checkbox, Button, Menu, Dropdown } from "antd";
import { DownOutlined } from '@ant-design/icons';
import {regApi} from "../../../App";
// import { RegistrationDates } from "../../../models/registration/date

// const registrationService = RegistrationService.getService();
const routes = [
	{
	  path: 'index',
	  breadcrumbName: 'TTU',
	},
    {
		path: 'index',
		breadcrumbName: 'Term Selection',
	},
	{
		path: 'index',
		breadcrumbName: 'Registration Status',
	},
  ];

const dataSource = [
    {
      key: '1',
      from: 'Apr 20, 2021',
      //begintime: '03:00 pm',
      to: 'Aug 4, 2021',
      //endtime: '11:59 pm',
    },

    {
      key: '2',
      from: 'Apr 28, 2021',
      to: 'Aug 4, 2021',
    }
  ];

const menu = (
  <Menu>
    <Menu.Item key="1">
      Senior
    </Menu.Item>
    <Menu.Item key="2">
      Junior
    </Menu.Item>
    <Menu.Item key="3">
      Sophmore
    </Menu.Item>
    <Menu.Item key="4">
      Freshman
    </Menu.Item>
  </Menu>
);
  
 
const Status = () => {
  const [senior, setSenior] = useState<any>();
  //const [junior, setJunior] = useState<RegistrationDates>();
  //const [sophmore, setSophomre] = useState<RegistrationDates>();
  //const [freshman, setFreshman] = useState<RegistrationDates>();

  const dates = () => {
  
		regApi.get(`registrationDates`)
			.then((response) => {
        console.log(response.data);
				setSenior(response.data);
      
			// 	setIsUserLoading(false);
			// })
			// .catch(() => {
			// 	message.error('Could not load user information at this time. Please try again later. If this error persists, please submit a ticket.');

			// 	setIsUserLoading(false);
		 });

	}
  // function onChange(value: any) {
	// 	setSenior(menu.key);
	// }

  useEffect(() => {
		dates();
	}, [])

	return (
    <PageHeader
      title="Registration Status"
      breadcrumb={{ routes }}
    >
      <Typography.Title level={4} style={{padding: '16px'}}>You may register during the following times</Typography.Title>
      <Checkbox style={{padding: '16px'}} defaultChecked disabled>You have no holds which prevent registration</Checkbox>
      <Table columns = {[
    {
      title: 'From',
      dataIndex:'senior',
    //  key: 'from',
    },

    {
      title: 'To',
      dataIndex: 'endDate',
     // key: 'endtime',
    },
  ]}
      pagination={false} dataSource={senior}/>
      {/* dataSource={senior} */}
    </PageHeader>
	);
}

export default Status;