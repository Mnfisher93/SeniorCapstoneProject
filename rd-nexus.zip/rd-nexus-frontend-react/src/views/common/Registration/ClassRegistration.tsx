import { useEffect, useState } from 'react';
import Scheduler from './Scheduler'
import DetailedTable from './DetailedTable'
import { registrationData, showModal } from './registrationData'
import AuthService from "../../../services/AuthService";
import { notification, Table, Divider, PageHeader, Typography, Form, Select, Input, Button, Row, Col } from "antd";
import {regApi} from "../../../App";
const { Option } = Select;
const { Column, ColumnGroup } = Table
const layout = {
	labelCol: {
		span: 8,
	},
	wrapperCol: {
		span: 16,
	},
};
const routes = [
	{
		path: 'index',
		breadcrumbName: 'Registration',
	},
	{
		path: 'first',
		breadcrumbName: 'Term Selection',
	},
	{
		path: 'first',
		breadcrumbName: 'Register for Classes',
	},
];
const dummyDataFromAPICall = [
	{
		id: "611fcd612cec2947ae2693b0",
		title: 'Mathematical Computing',
		times: [{day:"T",start:930,end:1050},{day:"R",start:930,end:1050}],
		details: "MATH 4392 001",
		hours: '3',
		crn: '12312',
		courseType: "Lecture",
		registrationStatus: 'Registered',
	},
	{
		id: "611fcd612cec2947ae2693b0",
		title: "Mathematical Statistics for Engineers and Scientists",
		times: [{day:"T",start:1100,end:1220},{day:"R",start:1100,end:1220}],
		details: "MATH 3342 022",
		hours: '3',
		crn: '12345',
		courseType: "Lecture",
		registrationStatus: 'Not Registered',
	},
	{
		id: "611fcd612cec2947ae2693b0",
		title: "Senior Capstone Project",
		times: [{day:"M",start:1500,end:1550},{day:"W",start:1500,end:1550},{day:"F", start:1500, end:1550}],
		details: "CS 4366 001",
		hours: '3',
		crn: '32452',
		courseType: "Lecture",
		registrationStatus: 'Registered',
	},
	{
		id: "611fcd612cec2947ae2693b0",
		title: 'Computer Networks',
		times: [{day:"M",start:1700,end:1750},{day:"W",start:1700,end:1750},{day:"F", start:1700, end:1750}],
		details: "CS 4392 001",
		hours: '3',
		crn: '54213',
		courseType: "Lecture",
		registrationStatus: 'Registered',
	}
]
const ClassRegistration = () => {
	const currentUser : any = AuthService.getDecodedAccessToken();
	const [registrationForm] = Form.useForm();
	const [showSummary, setShowSummary] = useState(true);
	const [showScheduler, setShowScheduler] = useState(false);
	const [showTable, setShowTable] = useState(false);
	const [registrationClasses, setRegistrationClasses] = useState(registrationData);
	const [userClassesData, setUserClassesData] = useState<any[]>([]);
	const [windowSize, setWindowSize] = useState({ width: 0, height: 0 });
	const UpdateData = () =>{
		regApi.get(`RegistrationClasses/${currentUser.userId}`).then((response)=>{
			setUserClassesData(response.data);
		}).catch((e)=>{
			console.log(e)
		})
	}
	const toggleSchedule = () => {
		setShowScheduler(!showScheduler);
		setShowSummary(false);
	}
	const toggleSumarry = () => {
		setShowScheduler(false);
		setShowSummary(!showSummary);
	}
	const onReset = () => {
		registrationForm.resetFields();
	};
	const handleOnSearch = (values: any) => {
		if(values.crn) {
			setRegistrationClasses(registrationData.filter((item)=> item.crn === values.crn));
		}
		if(values.course && values.subject) {
			setRegistrationClasses(registrationData.filter((item)=> item.courseNumber === values.course && item.subjectDescription === values.subject));
		} else if (values.course) {
			setRegistrationClasses(registrationData.filter((item)=> item.courseNumber === values.course));
		} else if (values.subject) {
			setRegistrationClasses(registrationData.filter((item)=> item.subjectDescription === values.subject));
		}
		setShowTable(true)
	}
	const handleAddClass = (classId: any) => {
		let [selectedClass] = registrationData.filter((item) => item.id === classId);
		if (userClassesData.filter(item => item.meetingId == selectedClass.meetingId).length > 0) {
			openErrorNotification("Error: Duplicate Class", "You already have this class in your selected classes.");
			return;
		}

		let major = "Computer Science";
		let minor = "Math";
		if(selectedClass.subjectDescription !== major && selectedClass.subjectDescription !== minor){
			openErrorNotification("Error: Major/Minor Error", "You do not have an " +selectedClass.subjectDescription+ " major or minor.");
			return;
		}

		let newClass = {
			id: selectedClass.id,
			userId:currentUser.userId,
			title: selectedClass.title,
			times: selectedClass.time,
			details: selectedClass.subjectDescriptionAbbr +" "+ selectedClass.courseNumber +" "+ selectedClass.section,
			hours: selectedClass.hours,
			crn: selectedClass.crn,
			meetingId: selectedClass.meetingId,
			courseType: selectedClass.scheduleType,
			registrationStatus: "Not Registered"
		}

		regApi.post('RegistrationClasses',newClass).then(()=>{
			openSuccNotification('Success: Class Added', selectedClass.title + " has been added to your schedule.");
			setUserClassesData((setUserClassesData: any) => [...setUserClassesData, newClass]);
		}).catch((e)=>{
			openErrorNotification("Error: Unable to Add Class", "There was an error when adding the requested class.");
		})
		
		
	}
	const detailedProps = {
		showModal,
		innerWidth: windowSize.width,
		innerHeight: windowSize.height,
		data: userClassesData,
		currentUserId:currentUser.userId,
		updateData: UpdateData
	}

	const openErrorNotification = (title: any, desc: any) => {
		notification['error']({
			message: title,
			description: desc,
		});
	};
	const openSuccNotification = (title: any, desc: any) => {
		notification['success']({
			message: title,
			description: desc,
		});
	};
	useEffect(() => {
		function handleResize() {
			setWindowSize({
				width: window.innerWidth,
				height: window.innerHeight,
			})
		}
		window.addEventListener("resize", handleResize);
		handleResize();
		regApi.get(`RegistrationClasses/${currentUser.userId}`).then((response)=>{
			console.log(response.data)
			setUserClassesData(response.data);
			console.log(userClassesData)
		}).catch((e)=>{
			console.log(e)
		})
		return () => window.removeEventListener("resize", handleResize);
	}, [])
	return (
		<>
			<PageHeader
				className="site-page-header"
				title="Register for Classes"
				breadcrumb={{ routes }}
			/>
			<div style={{ backgroundColor: "white", padding: "15px" }}>
				<Form hidden={windowSize.width > 1200}>
					<Form.Item className="item" >
						<Button style={{ marginRight: "5px" }} type="primary">
							Search
						</Button>
						<Button style={{ marginRight: "5px" }} type={showSummary ? 'primary' : 'default'} onClick={toggleSumarry}>
							Summary
						</Button>
						<Button type={showScheduler ? 'primary' : 'default'} htmlType="button" onClick={toggleSchedule}>
							Schedule
						</Button>
					</Form.Item>
				</Form>
				<Typography.Title level={5} style={{ display: "inline-block", marginBottom: 0 }}>Enter your search criteria</Typography.Title>	<p style={{ display: "inline-block", marginBottom: 0 }}> - Term Fall 2021 TTU</p>
			</div>
			<Row style={{ backgroundColor: "white", padding: "0px 15px 15px 15px" }}>
				<Col hidden={showTable} span={24}>
					<Form
						name="create"
						autoComplete="off"
						labelCol={{ span: 4 }}
						wrapperCol={{ span: 16 }}
						initialValues={{ times: [undefined] }}
						form={registrationForm}
						onFinish={handleOnSearch}
					>
						<Form.Item label="Subject" name="subject">
							<Select
								showSearch
								optionFilterProp="campuses"
								filterOption={(input, option: any) =>
									option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
								}
							>
								<Option value="Computer Science">Computer Science</Option>
								<Option value="Math">Math</Option>
								<Option value="Accounting">Accounting</Option>
							</Select>
						</Form.Item>

						<Form.Item label="Course Number" name="course">
							<Input
								placeholder="Course Number"
							>
							</Input>
						</Form.Item>
						<Form.Item label="CRN" name="crn">
							<Input
								placeholder="CRN Number"
							>
							</Input>
						</Form.Item>
						<Form.Item wrapperCol={{ ...layout.wrapperCol, offset: 0, lg: { offset: 4 } }}>
							<Button type="primary" style={{ marginRight: "15px" }} htmlType={'submit'}>
								Submit
							</Button>
							<Button htmlType="button" onClick={onReset}>
								Clear
							</Button>
						</Form.Item>
					</Form>

				</Col>
				<Col hidden={!showTable} span={24}>
					<Button onClick={() => setShowTable(false)} style={{ marginBottom: "15px" }}>
						Search Again
					</Button>
					<Table

						dataSource={registrationClasses}
						scroll={{ y: 240, x: 914 }}
						size="small"
						bordered={true}
					>
						<Column
							title="Title"
							key="title"
							dataIndex="title"
							sorter={(a: any, b: any) => (a.title.length - b.title.length)}
							render={(text: any) => (<a onClick={showModal}>{text}</a>)}
						/>
						<Column
							title="Subject Desc."
							key="subjectDescription"
							dataIndex="subjectDescription"
							sorter={(a: any, b: any) => (a.subjectDescription.length - b.subjectDescription.length)}
						/>
						<Column
							title="Course Number"
							key="courseNumber"
							dataIndex="courseNumber"
						/>
						<Column
							title="Section"
							key="section"
							dataIndex="section"
						/>
						<Column
							title="Hours"
							key="hours"
							dataIndex="hours"
						/>
						<Column
							title="CRN"
							key="crn"
							dataIndex="crn"
							sorter={(a: any, b: any) => (a.crn - b.crn)}
						/>
						<Column
							title="Instructor"
							key="instructor"
							dataIndex="instructor"
						/>
						<Column
							title="Meeting Times"
							key="meetingTimes"
							dataIndex="meetingTimes"
						/>
						<Column
							title="Campus"
							key="campus"
							dataIndex="campus"
						/>
						<Column
							title="Status"
							key="status"
							dataIndex="status"
						/>
						<Column
							title="Attribute"
							key="attribute"
							dataIndex="attribute"
						/>
						<Column
							title="Linked Sections"
							key="linkedSections"
							dataIndex="linkedSections"
						/>
						<Column title="Add" key="add" render={(item: any) => (
							<Button data-classID={item?.id} onClick={() => handleAddClass(item?.id)}>Add</Button>
						)} />
					</Table>
				</Col>
			</Row>
			<Divider style={{ margin: 0 }} />
			<Row>
				<Col lg={24} xl={11} hidden={!showScheduler && windowSize.width < 1200}>
					<Scheduler {...detailedProps} />
				</Col>
				<Col lg={24} xl={13} hidden={!showSummary && windowSize.width < 1200}>
					<DetailedTable {...detailedProps} />
				</Col>
			</Row>
		</>
	);
}

export default ClassRegistration;