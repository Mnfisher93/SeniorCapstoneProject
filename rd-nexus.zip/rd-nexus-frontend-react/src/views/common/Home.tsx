import React, {useEffect} from 'react';

import {PageHeader, Typography} from "antd";

const routes = [
	{
	  path: 'index',
	  breadcrumbName: 'TTU',
	},
	{
		path: 'index',
		breadcrumbName: 'Home',
	},
  ];
const Home = () => {
	return (
		<>
			<PageHeader
    			className="site-page-header"
    			title="Home"
    			breadcrumb={{ routes }}
  				/>
			<Typography.Title level={4}>Home page coming soon to a Nexus near you!</Typography.Title>
		</>
	);
}

export default Home;