import React, {useState, useEffect} from 'react';

import axios from "axios";

import {Card, Typography, Form, Table, Input, Button, Select} from "antd";

const {Column} = Table;
const {Option} = Select;

const ViewCampus = () => {
    return (
        <>
            <Card style={{ width: '99%' }}>
			  <Typography.Title level={4}>Campuses</Typography.Title>
        		<Form
                  name="searchCampus"
                  labelCol={{ span: 4 }}
        		  wrapperCol={{ span: 8 }}
        		  labelAlign={ 'left' }
        		  layout={ 'horizontal' }
        		>
          			<Form.Item 
                      name="campus"
                      label="Campus Name"
                      rules={[{ required: true, message: "Choose a Campus"}]}
                    >
                        <Select
                            showSearch
                            optionFilterProp="campuses"
                            filterOption={(input, option: any) =>
                                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >
                            {/*campuses.map((item, index) => (
                                <Option key={index} value={item}>
                                    {}
                                </Option>
                            ))  */}
                        </Select>
                    </Form.Item>

          			<Form.Item label=" " colon={false} wrapperCol={{ offset: 6 }}> 
            			<Button type="primary" htmlType="submit">
              				Search
            			</Button>
          			</Form.Item>
        		</Form>
				<Table 
					//dataSource={} 
					scroll={{ y: 240, x: 914 }}
					size="small"
					bordered={true}
					style={{ width: '99%' }}
				>
					<Column
						title="Name"
						dataIndex="name"
						key="name"
						sorter={(a: any, b: any) => (a.name.length - b.name.length)}
					/>
					<Column
						title="Street Address"
						dataIndex="streetAddress"
						key="streetAddress"
						sorter={(a: any, b: any) => (a.streetAddress.length - b.streetAddress.length)}
					/>
					<Column
						title="City"
						dataIndex="city"
						key="city"
					/>
					<Column
						title="State"
						dataIndex="state"
						key="state"
					/>
                    <Column
						title="Zip Code"
						dataIndex="zip"
						key="zip"
					/>
                    <Column
						title="Country"
						dataIndex="country"
						key="country"
                        sorter={(a: any, b: any) => (a.country.length - b.country.length)}
					/>
				</Table>
			</Card>
        </>
    );
};

export default ViewCampus;