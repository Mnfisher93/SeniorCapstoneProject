import React, {useEffect} from 'react';

import {Breadcrumb, Menu} from "antd";

import ViewCampus from './ViewCampus';
import CreateCampus from './CreateCampus';
import UpdateCampus from './UpdateCampus';

const Campus = () => {

    const [page, setPage] = React.useState(1);
	const [path, setPath] = React.useState("");

	function handleClick(value : any) {
		switch(value.key){
			case "view":
				setPage(1);
				setPath("View Campuses")
				break;
			case "create":
				setPage(2);
				setPath("Create New")
				break;
			case "update":
				setPage(3);
				setPath("Update Information")
				break;
			default:
				setPage(1);
				setPath("View Courses")
		};
	};

    return (
        <>
            <Breadcrumb style={{margin: '16px 0'}}>
                <Breadcrumb.Item>Campus</Breadcrumb.Item>
                {page === 1 ? (
                    <Breadcrumb.Item>View Campuses</Breadcrumb.Item>
                ) : (page === 2 ? (
                    <Breadcrumb.Item>Create New</Breadcrumb.Item>
                ) : (page === 3 ? (
                    <Breadcrumb.Item>Update Information</Breadcrumb.Item>
                ) : (
                    <></>
                )))}			
            </Breadcrumb>
        
            <Menu mode="horizontal" defaultSelectedKeys={[ 'view' ]} style={{ width: '99%' }} onClick={handleClick}>
                <Menu.Item key="view">
                    View Campuses
                </Menu.Item>
                <Menu.Item key="create">
                    Create New
                </Menu.Item>
                <Menu.Item key="update">
                    Update Information
                </Menu.Item>
            </Menu>
        
            {page === 1 ? (
                <ViewCampus />
            ) : (page === 2 ? (
                <CreateCampus />
            ) : (
                <UpdateCampus />
            ))}
        </>
    );
}

export default Campus;