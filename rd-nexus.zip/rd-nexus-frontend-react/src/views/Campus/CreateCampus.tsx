import React, { useEffect, useState } from "react";

import {Card, Form, Input, InputNumber, Button} from 'antd';

const CreateCampus = () => {
    return (
        <>
            <Card style={{ width: '99%' }}>
                <Form
                    name="createCampus"
                    labelCol={{ span: 4 }}
                    wrapperCol={{ span: 8 }}
                    labelAlign={ 'left' }
                    layout={ 'horizontal' }
                >
                    <Form.Item 
                        name="name" 
                        label="Campus Name"
                        rules={[{ required: true, message: "Enter a Name for the Campus"}]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item 
                        name="address" 
                        label="Street Address"
                        rules={[{ required: true, message: "Enter an Address"}]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item 
                        name="city" 
                        label="City"
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item 
                        name="state" 
                        label="State"
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item 
                        name="zip" 
                        label="Zip Code"
                        rules={[{ required: true, message: "Enter a Zip Code"}]}
                    >
                        <InputNumber />
                    </Form.Item>

                    <Form.Item 
                        name="country" 
                        label="Country"
                        rules={[{ required: true, message: "Enter a Country"}]}
                    >
                        <Input />
                    </Form.Item>

                    <Form.Item label="" colon={false} wrapperCol={{ offset: 10 }}>
                        <Button type="primary" htmlType="submit">
                            Submit
                        </Button>
                    </Form.Item>
                </Form>
            </Card>
        </>
    );
};

export default CreateCampus;