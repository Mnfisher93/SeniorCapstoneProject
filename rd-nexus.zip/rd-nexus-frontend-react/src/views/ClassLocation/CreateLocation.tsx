import React, { useEffect, useState } from "react";

import {Card, Form, Select, Divider, Input, InputNumber, Button} from 'antd';
import { PlusOutlined } from "@ant-design/icons";
import {courseApi} from "../../App";

const {Option} = Select;

const CreateLocation = () => {
  const [campuses, setCampuses] = useState([]);
  const [location, setLocation] = useState([]);
  
  const [buildings, setBuildings] = useState<any>([]);
  const [building, setBuilding] = useState("");

  const [buildingCodes, setBuildingCodes] = useState<any>([]);
  const [buildingCode, setBuildingCode] = useState("");

  const [rooms, setRooms] = useState<any>([]);
  const [room, setRoom] = useState("");

  const onFinish = (values: any) => {
    console.log("Create Location: ", values);

    const term = {
      buildingName: values.building,
      buildingCode: values.buildingCode,
      room: values.room
    };
    //console.log(term);
    courseApi
      .post("Term", location)
      .then((response) => {
        // Notify sucess
        console.log(response);
      })
      .catch((e) =>
        // notify error
        console.log(e)
      );
  };

  useEffect(() => {
    courseApi
      .get("Term")
      .then((response) => {
        setLocation(response.data);
        console.log(location);
      })
      .catch((err) => console.log("Building create error"));
  }, []);

  useEffect(() => {
    const buildings = location
      .map((course: any) => course.building)
      .filter(
        (value: any, index: any, array: any) => array.indexOf(value) === index
      );
    const buildingCodes = location
      .map((course: any) => course.buildingCode)
      .filter(
          (value: any, index: any, array: any) => array.indexOf(value) === index
      );
    const rooms = location
      .map((course: any) => course.room)
      .filter(
          (value: any, index: any, array: any) => array.indexOf(value) === index
      );
    setBuildings(buildings);
    setBuildingCodes(buildingCodes);
    setRooms(rooms);
    console.log(buildings, buildingCodes, rooms);
  }, [location]);

  const addBuilding = () => {
    setBuildings([...buildings, building]);
    setBuilding("");
  };

  const addCode = () => {
      setBuildingCodes([...buildingCodes, buildingCode]);
      setBuildingCode("");
  };

  const addRoom = () => {
      setRooms([...rooms, room]);
      setRoom("");
  };

    return (
        <>
            <Card style={{ width: '99%' }}>
                <Form
                    name="createLocation"
                    labelCol={{ span: 4 }}
                    wrapperCol={{ span: 8 }}
                    labelAlign={ 'left' }
                    layout={ 'horizontal' }
                >

                    <Form.Item
                        name="campus"
                        label="Campus"
                        rules={[{ required: true, message: "Select the Campus"}]}
                    >
                        <Select
                            showSearch
                            optionFilterProp="campuses"
                            filterOption={(input, option: any) =>
                                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >
                            {campuses.map((item, index) => (
                                <Option key={index} value={item}>
                                    {}
                                </Option>
                            ))}
                        </Select>
                    </Form.Item>
                    
                    <Form.Item
                        name="building"
                        label = "Building Name"
                        rules={[{ required: true, message: "Select the Building" }]}
                    >
                        <Select
                          showSearch
                          optionFilterProp="building"
                          filterOption={(input, option: any) =>
                            option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                          }
                          dropdownRender={(menu) => (
                            <div>
                              {menu}
                              <Divider style={{ margin: "4px 0" }} />
                              <div
                                style={{
                                  display: "flex",
                                  flexWrap: "nowrap",
                                  padding: 8,
                                }}
                              >
                                <Input
                                  style={{ flex: "auto" }}
                                  value={building}
                                  onChange={(e) => setBuilding(e.target.value)}
                                />
                                <a
                                  style={{
                                    flex: "none",
                                    padding: "8px",
                                    display: "block",
                                    cursor: "pointer",
                                  }}
                                  onClick={addBuilding}
                                >
                                  <PlusOutlined /> Add item
                                </a>
                              </div>
                            </div>
                          )}
                        >
                          {buildings.map((item: any, index: any) => (
                            <Option key={index} value={item}>
                              {item}
                            </Option>
                          ))}
                        </Select>
                      </Form.Item>

                      <Form.Item
                        name="buildingCode"
                        label = "Building Code"
                        rules={[{ required: true, message: "Select the Building Code" }]}
                      >
                        <Select
                          showSearch
                          optionFilterProp="buildingCode"
                          filterOption={(input, option: any) =>
                            option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                          }
                          dropdownRender={(menu) => (
                            <div>
                              {menu}
                              <Divider style={{ margin: "4px 0" }} />
                              <div
                                style={{
                                  display: "flex",
                                  flexWrap: "nowrap",
                                  padding: 8,
                                }}
                              >
                                <Input
                                  style={{ flex: "auto" }}
                                  value={buildingCode}
                                  onChange={(e) => setBuildingCode(e.target.value)}
                                />
                                <a
                                  style={{
                                    flex: "none",
                                    padding: "8px",
                                    display: "block",
                                    cursor: "pointer",
                                  }}
                                  onClick={addCode}
                                >
                                  <PlusOutlined /> Add item
                                </a>
                              </div>
                            </div>
                          )}
                        >
                          {buildingCodes.map((item: any, index: any) => (
                            <Option key={index} value={item}>
                              {item}
                            </Option>
                          ))}
                        </Select>
                      </Form.Item>

                      <Form.Item
                        name="room"
                        label = "Room Number"
                        rules={[{ required: true, message: "Select the Room Number" }]}
                    >
                        <Select
                          showSearch
                          optionFilterProp="room"
                          filterOption={(input, option: any) =>
                            option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                          }
                          dropdownRender={(menu) => (
                            <div>
                              {menu}
                              <Divider style={{ margin: "4px 0" }} />
                              <div
                                style={{
                                  display: "flex",
                                  flexWrap: "nowrap",
                                  padding: 8,
                                }}
                              >
                                <Input
                                  style={{ flex: "auto" }}
                                  value={room}
                                  onChange={(e) => setRoom(e.target.value)}
                                />
                                <a
                                  style={{
                                    flex: "none",
                                    padding: "8px",
                                    display: "block",
                                    cursor: "pointer",
                                  }}
                                  onClick={addRoom}
                                >
                                  <PlusOutlined /> Add item
                                </a>
                              </div>
                            </div>
                          )}
                        >
                          {rooms.map((item: any, index: any) => (
                            <Option key={index} value={item}>
                              {item}
                            </Option>
                          ))}
                        </Select>
                      </Form.Item>

                    <Form.Item label="" colon={false} wrapperCol={{ offset: 10 }}>
                        <Button type="primary" htmlType="submit">
                            Submit
                        </Button>
                    </Form.Item>
                </Form>
            </Card>
        </>
    );
};

export default CreateLocation;