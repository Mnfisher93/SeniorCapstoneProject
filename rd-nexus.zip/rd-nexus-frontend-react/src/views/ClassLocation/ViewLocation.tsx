import React, {useState, useEffect} from 'react';

import {Card, Typography, Form, Table, Input, Button, Select} from "antd";

const {Column} = Table;
const {Option} = Select;

const ViewLocation = () => {
    return (
        <>
            <Card style={{ width: '99%' }}>
			  <Typography.Title level={4}>Class Locations</Typography.Title>
        		<Form
                  name="searchLocation"
                  labelCol={{ span: 4 }}
        		  wrapperCol={{ span: 8 }}
        		  labelAlign={ 'left' }
        		  layout={ 'horizontal' }
        		>
                    <Form.Item 
                      name="campus"
                      label="Campus Name"
                      //rules={[{ required: true, message: "Choose a Campus"}]}
                    >
                        <Select
                            showSearch
                            optionFilterProp="campuses"
                            filterOption={(input, option: any) =>
                                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >
                            {/*campuses.map((item, index) => (
                                <Option key={index} value={item}>
                                    {}
                                </Option>
                            ))  */}
                        </Select>
                    </Form.Item>

          			<Form.Item 
                      name="building"
                      label="Building"
                      //rules={[{ required: true, message: "Choose a Building"}]}
                    >
                        <Select
                            showSearch
                            optionFilterProp="buildings"
                            filterOption={(input, option: any) =>
                                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >
                            {/*locations.map((item, index) => (
                                <Option key={index} value={item.buildingName}>
                                    {}
                                </Option>
                            ))  */}
                        </Select>
                    </Form.Item>

          			<Form.Item label=" " colon={false} wrapperCol={{ offset: 6 }}> 
            			<Button type="primary" htmlType="submit">
              				Search
            			</Button>
          			</Form.Item>
        		</Form>
				<Table 
					//dataSource={} 
					scroll={{ y: 240, x: 914 }}
					size="small"
					bordered={true}
					style={{ width: '99%' }}
				>
					<Column
						title="Campus"
						dataIndex="campus"
						key="campus"
						sorter={(a: any, b: any) => (a.campus.length - b.campus.length)}
					/>
					<Column
						title="Building Name"
						dataIndex="buildingName"
						key="buildingCode"
						sorter={(a: any, b: any) => (a.building.length - b.building.length)}
					/>
					<Column
						title="Building Code"
						dataIndex="buildingCode"
						key="buildingCode"
					/>
					<Column
						title="Room Number"
						dataIndex="room"
						key="room"
					/>
				</Table>
			</Card>
        </>
    );
};

export default ViewLocation;