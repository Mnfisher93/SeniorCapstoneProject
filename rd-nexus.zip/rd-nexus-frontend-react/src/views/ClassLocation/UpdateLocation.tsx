import React, { useEffect, useState } from "react";

import {Card, Form, Select, Table, Button} from 'antd';

const {Option} = Select;
const {Column} = Table;

const UpdateLocation = () => {
  const [campuses, setCampuses] = useState([]);
  const [location, setLocation] = useState([]);
  const [buildings, setBuildings] = useState([]);
  const [buildingCodes, setBuildingCodes] = useState([]);
  const [rooms, setRooms] = useState([]);

  const [form] = Form.useForm();

  const [searched, setSearched] = useState(false);
  const handleSearch = () => {
    setSearched(true);
  };

  const onSelectSec = (values: any) => {
    form.setFieldsValue({
        //room: location[0].roomNumber
    });
  };
  
    return (
        <>
            <Card style={{ width: '99%' }}>
                <Form
                    name="searchLocation"
                    labelCol={{ span: 4 }}
                    wrapperCol={{ span: 8 }}
                    labelAlign={ 'left' }
                    layout={ 'horizontal' }
                >
                    <Form.Item
                        name="campus"
                        label="Campus"
                        rules={[{ required: true, message: "Select the Campus"}]}
                    >
                        <Select
                            showSearch
                            optionFilterProp="campuses"
                            filterOption={(input, option: any) =>
                                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >
                            {campuses.map((item, index) => (
                                <Option key={index} value={item}>
                                    {}
                                </Option>
                            ))}
                        </Select>
                    </Form.Item>
                    
                    <Form.Item
                        name="building"
                        label="Building Name"
                        rules={[{ required: true, message: "Select the Building Name"}]}
                    >
                        <Select
                            showSearch
                            optionFilterProp="buildings"
                            filterOption={(input, option: any) =>
                                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >
                            {buildings.map((item, index) => (
                                <Option key={index} value={item}>
                                    {}
                                </Option>
                            ))}
                        </Select>
                    </Form.Item>

                    <Form.Item label="" colon={false} wrapperCol={{ offset: 10 }}>
                        <Button type="primary" htmlType="submit" onClick={handleSearch}>
                            Search
                        </Button>
                    </Form.Item>
                </Form>

                {searched ? (
                    <Table 
                      //dataSource={} 
                      scroll={{ y: 240, x: 914 }} 
                      size="small"
                      bordered={true}
                      style={{ width: '99%'}}
                    >
                      <Column 
                        title="Building"
                        key="building"
                        dataIndex="buildingName"
                      />
                      <Column 
                        title="Room Number"
                        key="roomNumber"
                        dataIndex="roomNumber"
                      />
                      <Column 
                        title="Update"
                        key="update"
                        render={(item: any) => (
                            <Button data-classID={item?.id} onClick={() => onSelectSec(item?.id)}>Update</Button>
                        )}
                      />
                    </Table>
                ) : (
                    <></>
                )}
            </Card>

            <Card style={{ width: '99%' }}>
                <Form
                    name="updateLocation"
                    labelCol={{ span: 4 }}
                    wrapperCol={{ span: 8 }}
                    labelAlign={ 'left' }
                    layout={ 'horizontal' }
                    form={form}
                >
                    <Form.Item
                        name="room"
                        label="Room Number"
                        rules={[{ required: true, message: "Select the Room Number"}]}
                    >
                        <Select
                            showSearch
                            optionFilterProp="rooms"
                            filterOption={(input, option: any) =>
                                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                            }
                        >
                            {rooms.map((item, index) => (
                                <Option key={index} value={item}>
                                    {}
                                </Option>
                            ))}
                        </Select>
                    </Form.Item>
                    
                    <Form.Item label="" colon={false} wrapperCol={{ offset: 10 }}>
                        <Button type="primary" htmlType="submit">
                            Submit
                        </Button>

                        <Button type="dashed" htmlType="submit">
                            Delete
                        </Button>
                    </Form.Item>

                </Form>
            </Card>
        </>
    );
};

export default UpdateLocation;