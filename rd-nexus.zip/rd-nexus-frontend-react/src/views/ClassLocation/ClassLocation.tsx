import React, {useEffect} from 'react';

import {Breadcrumb, Menu} from "antd";

import ViewLocation from './ViewLocation';
import CreateLocation from './CreateLocation';
import UpdateLocation from './UpdateLocation';

const ClassLocation = () => {

    const [page, setPage] = React.useState(1);
	const [path, setPath] = React.useState("");

	function handleClick(value : any) {
		switch(value.key){
			case "view":
				setPage(1);
				setPath("View Class Locations")
				break;
			case "create":
				setPage(2);
				setPath("Create New")
				break;
			case "update":
				setPage(3);
				setPath("Update Information")
				break;
			default:
				setPage(1);
				setPath("View Courses")
		};
	};

    return (
        <>
            <Breadcrumb style={{margin: '16px 0'}}>
                <Breadcrumb.Item>Class Location</Breadcrumb.Item>
                {page === 1 ? (
                    <Breadcrumb.Item>View Locations</Breadcrumb.Item>
                ) : (page === 2 ? (
                    <Breadcrumb.Item>Create New</Breadcrumb.Item>
                ) : (page === 3 ? (
                    <Breadcrumb.Item>Update Information</Breadcrumb.Item>
                ) : (
                    <></>
                )))}			
            </Breadcrumb>
        
            <Menu mode="horizontal" defaultSelectedKeys={[ 'view' ]} style={{ width: '99%' }} onClick={handleClick}>
                <Menu.Item key="view">
                    View Locations
                </Menu.Item>
                <Menu.Item key="create">
                    Create New
                </Menu.Item>
                <Menu.Item key="update">
                    Update Information
                </Menu.Item>
            </Menu>
        
            {page === 1 ? (
                <ViewLocation />
            ) : (page === 2 ? (
                <CreateLocation />
            ) : (
                <UpdateLocation />
            ))}
        </>
    );
}

export default ClassLocation;