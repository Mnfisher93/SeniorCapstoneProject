import React, { useEffect, useState } from "react";

import {
  Form,
  Space,
  Card,
  Select,
  Input,
  InputNumber,
  Button,
  Checkbox,
  TimePicker,
  Table
} from "antd";
import { MinusCircleOutlined, PlusOutlined } from "@ant-design/icons";

import { testMeetings } from "./testData";
import {courseApi} from "../../App";

const { Option } = Select;
const { Column, ColumnGroup } = Table;


const UpdateSection = () => {
  const [courses, setCourse] = useState([]);
  const [sections, setSection] = useState(testMeetings);
  const [terms, setTerm] = useState([]);
  const [campuses, setCampus] = useState([]);
  const [instructors, setInstructor] = useState([]);
  const [locations, setLocation] = useState([]);

  const [subjects, setSubject] = useState<any>([]);

  const [chosenSubject, setChosenSubject] = useState("");
  const [chosenCourse, setChosenCourse] = useState<any>({});
  const [searchedSection, setSearchedSection] = useState([]);
  const [sectionID, setSectionID] = useState("");
  const [chosenSemester, setChosenSemester] = useState("");
  const [chosenBuilding, setChosenBuilding] = useState("");

  const [searched, setSearched] = useState(false);
  const [form] = Form.useForm();

  const onSearch = (values: any) => {
    setSearched(true);
    console.log("Search Sections: ", values);
    console.log(sections[0]);
    if(values.campus){
      const section: any = sections.filter((section: any) => section.campus === values.campus);
      setSearchedSection(section);
    }else if(values.course){
      const section: any = sections.filter((section: any) => section.course === values.course);
      setSearchedSection(section);
    }else if(values.crn){
      const section: any = sections.filter((section: any) => section.crn === values.crn);
      setSearchedSection(section);
    }else if(values.term){
      console.log("BY TERM")
      const section: any = sections.filter((section: any) => section.term === values.term);
      setSearchedSection(section);
    }
    console.log(searchedSection);
    // if (!values.crn) {
    //   const course: any = courses.filter(
    //     (course: any) => course.subject === values.course.subject
    //   );
    //   setChosenCourse(course[0]);
	  // console.log("Found course: ", chosenCourse);
	  // const courseSections = sections.filter((section: any) => section.course === chosenCourse.id );
	  // console.log(courseSections);
	  
    // } else {
    //   const section: any = sections.filter(
    //     (section: any) => section.crn === values.crn
    //   );
    //   setChosenSection(section[0]);
    //   setSectionID(section[0].id);
    // }
  };

  const onSelectSec = (values: any) => {
    //values holds the id of the sections chosen
    form.setFieldsValue({
      seats: sections[0].seatsAvailable,
      //times: sections[0].times,
      instructor: sections[0].instructor,
      ta: sections[0].teachingAssistant,
      location: sections[0].location,
      altLocation: sections[0].alternateLocation,
      gradeMode: sections[0].gradeMode,
      method: sections[0].method
    });
  };

  const onUpdate = (values: any) => {
    console.log("Update Section: ", values);

    var formattedTime: any = [];
    values.times.map((time: any) => {
      time.day.map((d: any) => {
        let st = time.start._d.toString();
        let ed = time.end._d.toString();
        formattedTime.push({
          day: d,
          start: st
            .substring(st.indexOf(":") - 2, st.indexOf(":") + 3)
            .replace(":", ""),
          end: ed
            .substring(ed.indexOf(":") - 2, ed.indexOf(":") + 3)
            .replace(":", ""),
        });
      });
    });
    formattedTime = formattedTime.splice(1);

    const section = {
      crn: values.crn,
      course: values.course,
      sectionNum: values.sectgionNum,
      gradeMode: values.gradeMode,
      campus: values.campus,
      method: values.method,
      term: values.term,
      instructor: values.instructor,
      teachingAssistant: values.teachingAssistant,
      times: formattedTime,
      location: values.location,
      alternateLocation: values.alternateLocation,
      seatsAvailable: values.seatsAvailable,
      waitList: chosenCourse.waitList,
    };

    console.log(section);

    //   courseApi.put("Meeting", section)
    //   .then((response) => {
    // 	  console.log(response);
    // 	  // success
    //   } )
    //   .catch((error) => {
    // 	  console.log(error);
    // 	  // failed
    //   })
  };

  useEffect(() => {

    courseApi
      .get("Course/")
      .then((res) => {
        setCourse(res.data);
        console.log("Coures: ", res.data);
      })
      .catch((e) => console.log(e));

      var temp: any = [];
      courseApi
        .get("Meeting")
        .then((res) => {
          temp = res.data;
          console.log(res.data);
          const timeformat =
            res.data[0].times[0].day[0] +
            " " +
            res.data[0].times[0].start +
            " - " +
            res.data[0].times[0].end;
          console.log(timeformat);
          temp.map((section: any) => {
            section.instructor = "Mallory";
            section.teachingAssistant = "Hardik";
            section.times =
              section.times[0].day[0] +
              " " +
              section.times[0].start +
              " - " +
              section.times[0].end;
            courseApi
              .get(`Term/${section.term}`)
              .then((res) => {
                section.term = res.data.semester + " " + res.data.year;
              })
              .catch((e) => (section.term = "----"));
            courseApi
              .get(`Campus/${section.campus}`)
              .then((res) => {
                section.campus = res.data.campusName;
              })
              .catch((e) => (section.campus = "----"));
            courseApi
              .get(`Course/${section.course}`)
              .then((res) => {
                section.course = res.data.subject + "-" + res.data.courseNum;
              })
              .catch((e) => (section.course = "----"));
            courseApi
              .get(`ClassLocation/${section.location}`)
              .then((res) => {
                section.location =
                  res.data.buildingName +
                  " " +
                  res.data.buildingCode +
                  "-" +
                  res.data.room;
              })
              .catch((e) => (section.location = "----"));
            courseApi
              .get(`ClassLocation/${section.alternateLocation}`)
              .then((res) => {
                section.alternateLocation =
                  res.data.buildingName +
                  " " +
                  res.data.buildingCode +
                  "-" +
                  res.data.room;
              })
              .catch((e) => (section.alternateLocation = "----"));
          });
        })
        .finally(() => {
          setSection(temp);
          setSearchedSection(temp);
        });
    courseApi
      .get("Term")
      .then((res) => {
        setTerm(res.data);
      })
      .catch((e) => console.log(e));

    courseApi.get("Campus").then(
		(res)=>{
			setCampus(res.data);
		}
	).catch((e) => console.log(e));
    courseApi.get("ClassLocation").then(
		(res)=>{
			setLocation(res.data);
		}
	).catch((e) => console.log(e));
	
  }, []);

  useEffect(() => {
    setSubject(
      courses
        .map((course: any) => course.subject)
        .filter(
          (value: any, index: any, array: any) => array.indexOf(value) === index
        )
    );
  }, [courses]);

  return (
    <>
      <Card style={{ width: "99%" }}>
        <Form
          name="searchSection"
          autoComplete="off"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 8 }}
          labelAlign={'left'}
          layout={'horizontal'}
          onFinish={onSearch}
        >
          <Form.Item
            name="term"
            label="Term"
            style={{ display: "inline-list-item" }}
           // rules={[{ required: true }]}
          >
            
          
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Semester"
                  optionFilterProp="semesters"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  onSelect={(value: any) => setChosenSemester(value)}
                >
                  {terms.map((item : any, index) => (
                    <Option key={item.id} value={item.semester+ " " +item.year}>
                      {item.semester+ " " +item.year}
                    </Option>
                  ))}
                </Select>
        

              {/* <Form.Item
                name={["fullSemester", "year"]}
                noStyle
                rules={[{ required: true, message: "Enter the Year" }]}
              >
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Year"
                  optionFilterProp="years"
                  filterOption={(input, option: any) =>
                    option.value.indexOf(input) >= 0
                  }
                >
                  {terms
                    .filter((term: any) => term.semester === chosenSemester)
                    .map((term: any, index) => (
                      <Option key={index} value={term.year}>
                        {term.year}{" "}
                      </Option>
                    ))}
                </Select>
              </Form.Item> */}
        
          </Form.Item>

          <Form.Item
            name="campus"
            label="Campus"
           // rules={[{ required: true, message: "Enter a Campus" }]}
          >
            <Select
              showSearch
              optionFilterProp="campuses"
              filterOption={(input, option: any) =>
                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              {campuses.map((item : any, index) => (
                <Option key={index} value={item.campusName}>
                  {item.campusName}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item label="Course" name="course">
            <Input.Group compact>
              <Form.Item name={["course", "subject"]} noStyle>
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Subject"
                  optionFilterProp="subjects"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  onSelect={(value: any) => setChosenSubject(value)}
                >
                  {subjects.map((item: any, index:any) => (
                    <Option key={index} value={item}>
                      {item}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item name={["course", "number"]} noStyle>
                <Select
                  showSearch
                  placeholder="Number"
                  optionFilterProp="number"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  style={{ width: "50%" }}
                >
                  {courses
                    .filter((course: any) => course.subject === chosenSubject)
                    .map((item: any, index) => (
                      <Option key={index} value={item.courseNum}>
                        {" "}
                        {item.courseNum}{" "}
                      </Option>
                    ))}
                </Select>
              </Form.Item>
            </Input.Group>
          </Form.Item>

          <Form.Item name="crn" label="CRN Number">
            <Input />
          </Form.Item>

          <Form.Item label=" " colon={false}>
            <Button type="primary" htmlType="submit">
              Search
            </Button>
          </Form.Item>
        </Form>
      </Card>

      {searchedSection.length !== 0 ? (
        <Table 
          dataSource={searchedSection} 
          scroll={{ y: 240, x: 914 }} 
          size="small"
          bordered={true}
          style={{ width: '99%'}}
        >
          <Column 
            title="Course Subject"
            key="courseSubject"
            dataIndex="course"
          />
          
          <Column
            title="CRN"
            key="crn"
            dataIndex="crn"
            sorter={(a: any, b: any) => (a.crn - b.crn)}
          />
          <Column
            title="Section"
            key="sectionNum"
            dataIndex="sectionNum"
          />
          <Column
            title="Instructor"
            key="instructor"
            dataIndex="instructor"
          />
          {/*<Column
            title="Meeting Times"
            key="times"
            dataIndex="times"
          />*/}
          <Column 
            title="Update"
            key="update"
            render={(item: any) => (
              <Button data-classID={item?.id} onClick={() => onSelectSec(item?.id)}>Update</Button>
            )}
          />
        </Table>
      ) : (
        <></>
      )}

      <Card style={{ width: "99%" }}>
        <Form
          name="updateSec"
          autoComplete="off"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 8 }}
          labelAlign={'left'}
          layout={'horizontal'}
          initialValues={{ times: [undefined] }}
          onFinish={onUpdate}
          form={form}
        >
          <Form.Item label="Section Seats Available" name="seats">
            <InputNumber min={1} />
          </Form.Item>

          <Form.List name="times">
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, fieldKey, ...restField }) => (
                  <Space
                    key={key}
                    style={{ display: "flex", marginBottom: 8 }}
                    align="baseline"
                  >
                    <Form.Item
                      label=" "
                      colon={false}
                      {...restField}
                      name={[name, "day"]}
                      fieldKey={[fieldKey, "day"]}
                      rules={[{ required: true, message: "Pick a Day" }]}
                      labelCol={{ span: 30 }}
                      wrapperCol={{ span: 30 }}
                    >
                      <Checkbox.Group
                        options={[
                          "Monday",
                          "Tuesday",
                          "Wednesday",
                          "Thursday",
                          "Friday",
                        ]}
                      />
                    </Form.Item>

                    <Form.Item
                      {...restField}
                      name={[name, "start"]}
                      fieldKey={[fieldKey, "start"]}
                      label="Start"
                      rules={[{ required: true, message: "Pick a Start Time" }]}
                      labelCol={{ span: 30 }}
                      wrapperCol={{ span: 30 }}
                    >
                      <TimePicker use12Hours format="h:mm A" />
                    </Form.Item>

                    <Form.Item
                      {...restField}
                      name={[name, "end"]}
                      fieldKey={[fieldKey, "end"]}
                      label="End"
                      labelCol={{ span: 30 }}
                      wrapperCol={{ span: 30 }}
                    >
                      <TimePicker use12Hours format="h:mm A" />
                    </Form.Item>
                    <MinusCircleOutlined onClick={() => remove(name)} />
                  </Space>
                ))}
                <Form.Item wrapperCol={{ offset: 3, span: 10 }}>
                  <Button
                    type="dashed"
                    onClick={() => add()}
                    block
                    icon={<PlusOutlined />}
                  >
                    Add Day and Time
                  </Button>
                </Form.Item>
              </>
            )}
          </Form.List>

          <Form.Item
            label="Instructor"
            name="instructor"
            rules={[{ required: true, message: "Enter an Instructor" }]}
          >
            <Select
              showSearch
              optionFilterProp="instructors"
              filterOption={(input, option: any) =>
                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              {instructors.map((instructor: any, index) => (
                <Option
                  key={index}
                  value={instructor.firstName + " " + instructor.lastName}
                >
                  {" "}
                  {instructor.firstName + " " + instructor.lastName}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item
            label="Teaching Assistant"
            name="ta"
          >
            <Select
              showSearch
              optionFilterProp="tas"
              filterOption={(input, option: any) =>
                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              {instructors.map((instructor: any, index) => (
                <Option
                  key={index}
                  value={instructor.firstName + " " + instructor.lastName}
                >
                  {" "}
                  {instructor.firstName + " " + instructor.lastName}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item label="Location" name="location">
            <Input.Group compact>
              <Form.Item name={["location", "building"]} noStyle>
                <Select
                  showSearch
                  placeholder="Building"
                  optionFilterProp="buildings"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  style={{ width: "50%" }}
				  onSelect = {(value:any) => setChosenBuilding(value)}
                >
                  {locations.map((location : any, index) => (
                    <Option key={index} value={location.buildingName}>{location.buildingName}</Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item name={["location", "roomNumber"]} noStyle>
                <Select
                  showSearch
                  placeholder="Room Number"
                  optionFilterProp="rooms"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  style={{ width: "50%" }}
                >
				{locations.filter((location: any) => location.buildingName === chosenBuilding).map((location : any, index) => (
                    <Option key={index} value={location.room}>{location.room}</Option>
                  ))}
                </Select>
              </Form.Item>
            </Input.Group>
          </Form.Item>

          <Form.Item label="Alternate Location" name="altLocation">
            <Input.Group compact>
              <Form.Item name={["altLocation", "building"]} noStyle>
                <Select
                  showSearch
                  placeholder="Building"
                  optionFilterProp="buildings"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  style={{ width: "50%" }}
				  onSelect = {(value:any) => setChosenBuilding(value)}
                >
                  {locations.map((location : any, index) => (
                    <Option key={index} value={location.buildingName}>{location.buildingName}</Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item name={["altLocation", "roomNumber"]} noStyle>
                <Select
                  showSearch
                  placeholder="Room Number"
                  optionFilterProp="rooms"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  style={{ width: "50%" }}
                >
				{locations.filter((location: any) => location.buildingName === chosenBuilding).map((location : any, index) => (
                    <Option key={index} value={location.room}>{location.room}</Option>
                  ))}
                </Select>
              </Form.Item>
            </Input.Group>
          </Form.Item>

          <Form.Item label="Grademode" name="gradeMode">
            <Select placeholder="Grademode" defaultValue="standard">
              <Option value="standard">Standard Grading</Option>
              <Option value="other">Other</Option>
            </Select>
          </Form.Item>

          <Form.Item label="Method" name="method">
            <Select placeholder="method" defaultValue="face">
              <Option value="face">Face-to-Face</Option>
              <Option value="online">Online</Option>
              <Option value="hybrid">Hybrid</Option>
            </Select>
          </Form.Item>

          <Form.Item
            name="submit"
            wrapperCol={{ offset: 20, span: 16 }}
            style={{ margin: 3 }}
          >
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
            <Button htmlType="button">Reset</Button>
          </Form.Item>
        </Form>
      </Card>
    </>
  );
};

export default UpdateSection;
