export const testCourses = [
    {
        id: "123",
        department: "Computer Science",
        subject: "CS",
        courseNum: 1411,
        name: "Intro to Programming I",
        hours: 4,
        courseType: "Lecture",
        preRequisites: ["abc","def"],
        coRequisites: []
    },
    {
        id: "456",
        department: "Computer Science",
        subject: "CS",
        courseNum: 1412,
        name: "Intro to Programming II",
        hours: 4,
        courseType: "Lecture",
        preRequisites: [],
        coRequisites: []
    },
    {
        id: "789",
        department: "Computer Science",
        subject: "CS",
        courseNum: 1362,
        name: "Assembly Language",
        hours: 4,
        courseType: "Lecture",
        preRequisites: [],
        coRequisites: []
    },
    {
        id: "135",
        department: "Mathematics",
        subject: "MATH",
        courseNum: 1452,
        name: "Calculus I",
        hours: 4,
        courseType: "Lecture",
        preRequisites: [],
        coRequisites: []
    },
    {
        id: "790",
        department: "Mathematics",
        subject: "MATH",
        courseNum: 1453,
        name: "Calculus II",
        hours: 4,
        courseType: "Lecture",
        preRequisites: [],
        coRequisites: []
    },
    {
        id: "024",
        department: "Mathematics",
        subject: "MATH",
        courseNum: 2443,
        name: "Calculus III",
        hours: 4,
        courseType: "Lecture",
        preRequisites: [],
        coRequisites: []
    },
    {
        id: "687",
        department: "Physics",
        subject: "PHYS",
        courseNum: 1456,
        name: "Physics I",
        hours: 4,
        courseType: "Lecture",
        preRequisites: [],
        coRequisites: []
    },
    {
        id: "148",
        department: "Physics",
        subject: "PHYS",
        courseNum: 2490,
        name: "Physics II",
        hours: 4,
        courseType: "Lecture",
        preRequisites: [],
        coRequisites: []
    },
];

export const testMeetings = [
    {
        id: "123",
        crn: "12345",
        sectionNum: "001",
        gradeMode: "Standard Grading",
        campus: "Lubbock TTU",
        method: "Face-to-Face",
        term: "Spring 2020",
        instructor: "Borshir Morshed",
        teachingAssistant: "",
        times: [
            {
                day: "Monday",
                start: "1500",
                end: "1550"
            }
        ],
        location: "ECE 151",
        alternateLocation: "",
        seatsAvailable: 50,
        waitList: 0
    },
    {
        id: "123",
        crn: "67890",
        sectionNum: "002",
        gradeMode: "Standard Grading",
        campus: "Lubbock TTU",
        method: "Face-to-Face",
        term: "Spring 2020",
        instructor: "Borshir Morshed",
        teachingAssistant: null,
        times: [
            {
                day: "Monday",
                start: "1500",
                end: "1550"
            }
        ],
        location: "ECE 151",
        alternateLocation: null,
        seatsAvailable: 50,
        waitList: 0
    },
    {
        id: "135",
        crn: "13579",
        sectionNum: "001",
        gradeMode: "Standard Grading",
        campus: "Lubbock TTU",
        method: "Face-to-Face",
        term: "Spring 2020",
        instructor: "Susan Mengel",
        teachingAssistant: null,
        times: [
            {
                day: "Monday",
                start: "1500",
                end: "1550"
            }
        ],
        location: "MATH 113",
        alternateLocation: null,
        seatsAvailable: 50,
        waitList: 0
    },
    {
        id: "246",
        crn: "24680",
        sectionNum: "001",
        gradeMode: "Standard Grading",
        campus: "Lubbock TTU",
        method: "Face-to-Face",
        term: "Spring 2020",
        instructor: "Yualin Zhang",
        teachingAssistant: null,
        times: [
            {
                day: "Monday",
                start: "1500",
                end: "1550"
            }
        ],
        location: "PHYS 121",
        alternateLocation: null,
        seatsAvailable: 50,
        waitList: 0
    }
]

export const testTerm = [
    {
        id: 123,
        semester: "fall",
        year: 2021,
        start: "",
        end: ""
    },
    {
        id: 456,
        semester: "spring",
        year: 2021,
        start: "",
        end: ""
    },
    {
        id: 789,
        semester: "Summer I",
        year: 2019,
        start: "",
        end: ""
    }
]

export const testCampus = [
    {
        id: 123,
        campusName: "Lubbock TTU"
    },
    {
        id: 123,
        campusName: "Costa Rica TTU"
    }
]

export const testInstructor = [
    {
        id: "615d456df6019bf193c1134d",
        firstName: "Mallory",
        lastName: "Rasco"
    },
    {
        id: "615q456df6012bf193c1434b",
        firstName: "Hardik",
        lastName: "Poudel"
    }
]


//export const testLocation
