import React, {useEffect} from 'react';

import {Breadcrumb, Menu} from "antd";

import ViewCourses from './ViewCourses';
import CreateCourse from './CreateCourse';
import CreateSection from './CreateSection';
import UpdateCourse from './UpdateCourse';
import UpdateSection from './UpdateSection';

const { SubMenu } = Menu;

const CourseDirectory = () => {
	const [page, setPage] = React.useState(1);
	const [path, setPath] = React.useState("");

	function handleClick(value : any) {
		switch(value.key){
			case "view":
				setPage(1);
				setPath("View Courses")
				break;
			case "newCourse":
				setPage(2);
				setPath("New Course")
				break;
			case "newSection":
				setPage(3);
				setPath("New Section")
				break;
			case "updateCourse":
				setPage(4);
				setPath("Update Course")
				break;
			case "updateSection":
				setPage(5);
				setPath("Update Section")
				break;
			default:
				setPage(1);
				setPath("View Courses")
		};
	};

	return (
		<>
			<Breadcrumb style={{margin: '16px 0'}}>
				<Breadcrumb.Item>Course Directory</Breadcrumb.Item>
				{page === 1 ? (
					<Breadcrumb.Item>View Courses</Breadcrumb.Item>
				) : (page === 2 || page === 3 ? (
					<Breadcrumb.Item>Create New</Breadcrumb.Item>
				) : (page === 4 || page === 5 ? (
					<Breadcrumb.Item>Update Information</Breadcrumb.Item>
				) : (
					<></>
				)))}
				{page === 2 ? (
					<Breadcrumb.Item>New Course</Breadcrumb.Item>
				) : (page === 3 ? (
					<Breadcrumb.Item>New Section</Breadcrumb.Item>
				) : (page === 4 ? (
					<Breadcrumb.Item>Update Course</Breadcrumb.Item>
				) : (page === 5 ? (
					<Breadcrumb.Item>Update Section</Breadcrumb.Item>
				) : (
					<></>
				))))}				
			</Breadcrumb>
			
			<Menu mode="horizontal" defaultSelectedKeys={[ 'view' ]} style={{ width: '99%' }} onClick={handleClick}>
				<Menu.Item key="view">
					View Courses
				</Menu.Item>
				<SubMenu key="create" title="Create New">
					<Menu.Item key="newCourse">
						New Course
					</Menu.Item>
					<Menu.Item key="newSection">
						New Section
					</Menu.Item>
				</SubMenu>
				<SubMenu key="update" title="Update Information">
					<Menu.Item key="updateCourse">
						Update Course
					</Menu.Item>
					<Menu.Item key="updateSection">
						Update Section
					</Menu.Item>
				</SubMenu>
			</Menu>
			
			{page === 1 ? (
				<ViewCourses />
			) : (page === 2 ? (
				<CreateCourse />
			) : (page === 3 ? (
				<CreateSection />
			) : (page === 4 ? (
				<UpdateCourse />
			) : (
				<UpdateSection />
			))))}
		</>
	);
}

export default CourseDirectory;