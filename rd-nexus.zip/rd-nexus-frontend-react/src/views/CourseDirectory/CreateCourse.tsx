import React, { useEffect, useState } from "react";

import {
  Card,
  Form,
  Input,
  InputNumber,
  Select,
  Divider,
  Space,
  Button,
  Alert,
} from "antd";
import { MinusCircleOutlined, PlusOutlined } from "@ant-design/icons";

import { testCourses } from "./testData";
import { courseApi } from "../../App";

const { Option } = Select;

const CreateCourse = () => {
  const [courses, setCourse] = useState([]);
  const [subject, setSubject] = useState("");
  const [subjects, setSubjects] = useState<any>([]);
  const [chosenSubject, setChosenSubject] = useState("");

  const [searchForm] = Form.useForm();

  const onFinish = (values: any) => {
    console.log("Create Course: ", values);

    const course = {
      department: values.course.department,
      subject: values.subject,
      courseNum: values.course.number,
      name: values.name,
      hours: values.hours,
      courseType: values.courseType,
      preRequisites: values.preRequisites,
      coRequisites: values.coRequisites,
    };

    courseApi
      .post("Course", course)
      .then((response) => {
        // Notify sucess
        console.log(response);
      })
      .catch((e) =>
        // notify error
        console.log(e)
      );
  };

  useEffect(() => {
    courseApi
      .get("Course")
      .then((response) => {
        setCourse(response.data);
      })
      .catch((err) => console.log("Course create error"));
  }, []);

  useEffect(() => {
    const sub = courses
      .map((course: any) => course.department)
      .filter(
        (value: any, index: any, array: any) => array.indexOf(value) === index
      );
    setSubjects(sub);
  }, [courses]);

  const addItem = () => {
    setSubjects([...subjects, subject]);
    setSubject("");
  };

  return (
    <>
      <Card style={{ width: "99%" }}>
        <Form
          name="createCourse"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 8 }}
          labelAlign={"left"}
          layout={"horizontal"}
          onFinish={onFinish}
          form={searchForm}
        >
          <Form.Item
            label="Course Subject"
            name="course"
            rules={[{ required: true }]}
          >
            <Input.Group compact>
              <Form.Item
                name={["course", "department"]}
                noStyle
                rules={[{ required: true, message: "Enter the Subject" }]}
              >
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Subject"
                  optionFilterProp="subjects"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  dropdownRender={(menu) => (
                    <div>
                      {menu}
                      <Divider style={{ margin: "4px 0" }} />
                      <div
                        style={{
                          display: "flex",
                          flexWrap: "nowrap",
                          padding: 8,
                        }}
                      >
                        <Input
                          style={{ flex: "auto" }}
                          value={subject}
                          onChange={(e) => setSubject(e.target.value)}
                        />
                        <a
                          style={{
                            flex: "none",
                            padding: "8px",
                            display: "block",
                            cursor: "pointer",
                          }}
                          onClick={addItem}
                        >
                          <PlusOutlined /> Add item
                        </a>
                      </div>
                    </div>
                  )}
                >
                  {subjects.map((item: any, index: any) => (
                    <Option key={index} value={item}>
                      {item}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item
                name={["course", "number"]}
                noStyle
                rules={[{ required: true, message: "Enter the Number" }]}
              >
                <Input style={{ width: "50%" }} placeholder="Number" />
              </Form.Item>
            </Input.Group>
          </Form.Item>

          <Form.Item
            label="Abbreviation"
            name="subject"
            rules={[
              { required: true, message: "Enter the Course Abbreviation" },
            ]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            label="Name"
            name="name"
            rules={[{ required: true, message: "Enter the Course Name" }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            name="hours"
            label="Hours Worth"
            rules={[{ required: true, message: "Enter Hours" }]}
          >
            <InputNumber min={1} />
          </Form.Item>

          <Form.Item
            name="courseType"
            label="Course Type"
            rules={[{ required: true, message: "Enter a Course Type" }]}
          >
            <Select>
              <Option value="lecture">Lecture</Option>
              <Option value="lab">Lab</Option>
              <Option value="discussion">Discussion</Option>
            </Select>
          </Form.Item>

          <Form.List name="preRequisites">
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, fieldKey, ...restField }) => (
                  <Space
                    key={key}
                    style={{ offset: 8, display: "flex", marginBottom: 8 }}
                    align="baseline"
                  >
                    <Form.Item
                      label=" "
                      colon={false}
                      name={[name, "course"]}
                      wrapperCol={{ offset: 30, span: 30 }}
                    >
                      <Input.Group compact>
                        <Form.Item
                          {...restField}
                          name={["course", "subject"]}
                          fieldKey={[fieldKey, "subject"]}
                          noStyle
                        >
                          <Select
                            style={{ width: "50%" }}
                            placeholder="Subject"
                            showSearch
                            optionFilterProp="departments"
                            filterOption={(input, option: any) =>
                              option.value
                                .toLowerCase()
                                .indexOf(input.toLowerCase()) >= 0
                            }
                            onSelect={(value: any) => {
                              setChosenSubject(value);

                            }}
                          >
                            {courses.map((item: any, index: any) => (
                              <Option key={index} value={item.department}>
                                {item.subject}
                              </Option>
                            ))}
                          </Select>
                        </Form.Item>

                        <Form.Item
                          {...restField}
                          name={["course", "number"]}
                          fieldKey={[fieldKey, "number"]}
                          noStyle
                        >
                          <Select
                            style={{ width: "50%" }}
                            showSearch
                            placeholder="Number"
                            optionFilterProp="number"
                            filterOption={(input, option: any) =>
                              option.value
                                .toLowerCase()
                                .indexOf(input.toLowerCase()) >= 0
                            }
                          >
                            {courses
                              .filter(
                                (course: any) =>
                                  course.department === chosenSubject
                              )
                              .map((item: any, index) => (
                                <Option key={index} value={item.courseNum}>
                                  {item.courseNum}
                                </Option>
                              ))}
                          </Select>
                        </Form.Item>
                      </Input.Group>
                    </Form.Item>
                    <MinusCircleOutlined onClick={() => remove(name)} />
                  </Space>
                ))}
                <Form.Item wrapperCol={{ offset: 4, span: 8 }}>
                  <Button
                    type="dashed"
                    onClick={() => add()}
                    block
                    icon={<PlusOutlined />}
                  >
                    Add Pre-Requisite
                  </Button>
                </Form.Item>
              </>
            )}
          </Form.List>

          <Form.List name="coRequisites">
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, fieldKey, ...restField }) => (
                  <Space
                    key={key}
                    style={{ offset: 8, display: "flex", marginBottom: 8 }}
                    align="baseline"
                  >
                    <Form.Item label=" " colon={false} name={[name, "course"]}>
                      <Input.Group compact>
                        <Form.Item
                          {...restField}
                          name={[name, "subject"]}
                          fieldKey={[fieldKey, "subject"]}
                          noStyle
                          rules={[
                            { required: true, message: "Enter the Subject" },
                          ]}
                        >
                          <Select
                            style={{ width: "50%" }}
                            placeholder="Subject"
                            showSearch
                            optionFilterProp="departments"
                            filterOption={(input, option: any) =>
                              option.value
                                .toLowerCase()
                                .indexOf(input.toLowerCase()) >= 0
                            }
                          >
                            <Option value="computer science">
                              Computer Science
                            </Option>
                            <Option value="mathematics">Mathematics</Option>
                            <Option value="physics">Physics</Option>
                          </Select>
                        </Form.Item>

                        <Form.Item
                          {...restField}
                          name={[name, "number"]}
                          fieldKey={[fieldKey, "number"]}
                          noStyle
                          rules={[
                            { required: true, message: "Enter the Number" },
                          ]}
                        >
                          <InputNumber
                            style={{ width: "50%" }}
                            min={1100}
                            placeholder="Number"
                          />
                        </Form.Item>
                      </Input.Group>
                    </Form.Item>
                    <MinusCircleOutlined onClick={() => remove(name)} />
                  </Space>
                ))}
                <Form.Item wrapperCol={{ offset: 4, span: 8 }}>
                  <Button
                    type="dashed"
                    onClick={() => add()}
                    block
                    icon={<PlusOutlined />}
                  >
                    Add Co-Requisite
                  </Button>
                </Form.Item>
              </>
            )}
          </Form.List>

          <Form.Item label=" " colon={false} wrapperCol={{ offset: 6 }}>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </>
  );
};

export default CreateCourse;
