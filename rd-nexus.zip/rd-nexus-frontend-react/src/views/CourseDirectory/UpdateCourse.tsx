import React, { useState, useEffect } from "react";
import {
  Card,
  Form,
  Input,
  InputNumber,
  Select,
  Space,
  Button,
  Alert,
} from "antd";
import { MinusCircleOutlined, PlusOutlined } from "@ant-design/icons";
import {courseApi} from "../../App";


const { Option } = Select;

const UpdateCourse = () => {
  const [courses, setCourse] = useState([]);
  const [courseID, setCourseID] = useState("");
  const [subjects, setSubject] = useState<any>([]);
  const [chosenCourse, setChosenCourse] = useState<any>({});
  const [form] = Form.useForm();

  const onSearch = (values: any) => {
    const course : any = courses.filter(
      (course: any) =>
        course.subject === values.course.subject &&
        course.courseNum === values.course.number
    );
    setChosenCourse(course[0]);
    setCourseID(course[0].id);
    form.setFieldsValue({
      name: course[0].name,
      hours: course[0].hours,
      courseType: course[0].courseType,
      preReq: course[0].preRequisites,
      coReq: course[0].coRequisites,
    });
  };

  const onUpdate = (value: any) => {
    const course = {
      department: chosenCourse.department,
      subject: chosenCourse.subject,
      courseNum: chosenCourse.courseNum,
      name: value.name,
      hours: value.hours,
      courseType: value.courseType,
      preRequisites: value.preReq,
      coRequisites: value.coReq,
    };
    courseApi
      .put(`Course/${courseID}`, course)
      .then((response) => {
        console.log(response);
      })
      .catch((error) => {
        console.log("ERROR", error);
      });
  };

  useEffect(() => {
    courseApi
      .get("Course")
      .then((res) => {
        setCourse(res.data);
      })
      .catch((e) => console.log(e));
  }, []);

  useEffect(() => {
    setSubject(
      courses
        .map((course: any) => course.subject)
        .filter(
          (value: any, index: any, array: any) => array.indexOf(value) === index
        )
    );
  }, [courses]);

  return (
    <>
      <Card style={{ width: "99%" }}>
        <Form
          name="searchCourse"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 8 }}
          labelAlign={ 'left' }
          layout={ 'horizontal' }
          onFinish={onSearch}
        >
          <Form.Item
            label="Course Number"
            name="course"
            rules={[{ required: true }]}
          >
            <Input.Group compact>
              <Form.Item
                name={["course", "subject"]}
                noStyle
                rules={[{ required: true, message: "Enter the Subject" }]}
              >
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Subject"
                  optionFilterProp="subjects"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  onSelect={(value: any) => setChosenCourse(value)}
                >
                  {subjects.map((item: any, index: any) => (
                    <Option key={index} value={item}>
                      {item}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item
                name={["course", "number"]}
                noStyle
                rules={[{ required: true, message: "Enter the Number" }]}
              >
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Number"
                  optionFilterProp="number"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {courses
                    .filter((course:any) => course.subject === chosenCourse)
                    .map((item:any, index) => (
                      <Option key={index} value={item.courseNum}>
                        {item.courseNum}
                      </Option>
                    ))}
                </Select>
              </Form.Item>
            </Input.Group>
          </Form.Item>

          <Form.Item label=" " colon={false}>
            <Button type="primary" htmlType="submit">
              Search
            </Button>
          </Form.Item>
        </Form>
      </Card>

      <Card style={{ width: "99%" }}>
        <Form
          name="updateCourse"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 8 }}
          labelAlign={'left'}
          layout={'horizontal'}
          onFinish={onUpdate}
          form={form}
        >
          <Form.Item
            label="Name"
            name="name"
            rules={[{ required: true, message: "Enter the Course Name" }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            name="hours"
            label="Hours Worth"
            rules={[{ required: true, message: "Enter Hours" }]}
          >
            <InputNumber min={1} />
          </Form.Item>

          <Form.Item
            name="courseType"
            label="Course Type"
            rules={[{ required: true, message: "Enter a Course Type" }]}
          >
            <Select>
              <Option value="lecture">Lecture</Option>
              <Option value="lab">Lab</Option>
              <Option value="discussion">Discussion</Option>
            </Select>
          </Form.Item>

          <Form.List name="preRequisites">
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, fieldKey, ...restField }) => (
                  <Space
                    key={key}
                    style={{ offset: 8, display: "flex", marginBottom: 8 }}
                    align="baseline"
                  >
                    <Form.Item
                      label=" "
                      colon={false}
                      name={[name, "course"]}
                      wrapperCol={{ offset: 200 }}
                    >
                      <Input.Group compact>
                        <Form.Item
                          {...restField}
                          name={[name, "subject"]}
                          fieldKey={[fieldKey, "subject"]}
                          noStyle
                          rules={[
                            { required: true, message: "Enter the Subject" },
                          ]}
                        >
                          <Select
                            style={{ width: "50%" }}
                            placeholder="Subject"
                            showSearch
                            optionFilterProp="departments"
                            filterOption={(input, option: any) =>
                              option.value
                                .toLowerCase()
                                .indexOf(input.toLowerCase()) >= 0
                            }
                          >
                            <Option value="computer science">
                              Computer Science
                            </Option>
                            <Option value="mathematics">Mathematics</Option>
                            <Option value="physics">Physics</Option>
                          </Select>
                        </Form.Item>

                        <Form.Item
                          {...restField}
                          name={[name, "number"]}
                          fieldKey={[fieldKey, "number"]}
                          noStyle
                          rules={[
                            { required: true, message: "Enter the Number" },
                          ]}
                        >
                          <InputNumber
                            style={{ width: "50%" }}
                            min={1100}
                            placeholder="Number"
                          />
                        </Form.Item>
                      </Input.Group>
                    </Form.Item>
                    <MinusCircleOutlined onClick={() => remove(name)} />
                  </Space>
                ))}
                <Form.Item wrapperCol={{ offset: 4, span: 8 }}>
                  <Button
                    type="dashed"
                    onClick={() => add()}
                    block
                    icon={<PlusOutlined />}
                  >
                    Add Pre-Requisite
                  </Button>
                </Form.Item>
              </>
            )}
          </Form.List>

          <Form.List name="coRequisites">
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, fieldKey, ...restField }) => (
                  <Space
                    key={key}
                    style={{ offset: 8, display: "flex", marginBottom: 8 }}
                    align="baseline"
                  >
                    <Form.Item
                      label=" "
                      colon={false}
                      name={[name, "course"]}
                      wrapperCol={{ offset: 200 }}
                    >
                      <Input.Group compact>
                        <Form.Item
                          {...restField}
                          name={[name, "subject"]}
                          fieldKey={[fieldKey, "subject"]}
                          noStyle
                          rules={[
                            { required: true, message: "Enter the Subject" },
                          ]}
                        >
                          <Select
                            style={{ width: "50%" }}
                            placeholder="Subject"
                            showSearch
                            optionFilterProp="departments"
                            filterOption={(input, option: any) =>
                              option.value
                                .toLowerCase()
                                .indexOf(input.toLowerCase()) >= 0
                            }
                          >
                            <Option value="computer science">
                              Computer Science
                            </Option>
                            <Option value="mathematics">Mathematics</Option>
                            <Option value="physics">Physics</Option>
                          </Select>
                        </Form.Item>

                        <Form.Item
                          {...restField}
                          name={[name, "number"]}
                          fieldKey={[fieldKey, "number"]}
                          noStyle
                          rules={[
                            { required: true, message: "Enter the Number" },
                          ]}
                        >
                          <InputNumber
                            style={{ width: "50%" }}
                            min={1100}
                            placeholder="Number"
                          />
                        </Form.Item>
                      </Input.Group>
                    </Form.Item>
                    <MinusCircleOutlined onClick={() => remove(name)} />
                  </Space>
                ))}
                <Form.Item wrapperCol={{ offset: 4, span: 8 }}>
                  <Button
                    type="dashed"
                    onClick={() => add()}
                    block
                    icon={<PlusOutlined />}
                  >
                    Add Co-Requisite
                  </Button>
                </Form.Item>
              </>
            )}
          </Form.List>

          <Form.Item label=" " colon={false} wrapperCol={{ offset: 6 }}>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </>
  );
};

export default UpdateCourse;
