import React, { useState, useEffect } from "react";

import {
  PageHeader,
  Typography,
  Card,
  Table,
  Form,
  Button,
  Select,
  Input,
} from "antd";

import { testCourses, testMeetings } from "./testData";
import { courseApi } from "../../App";
import { values } from "lodash";
import { time } from "console";

const { Column } = Table;
const { Option } = Select;

const ViewCourses = () => {
  const [courses, setCourses] = useState([]);
  const [sections, setSection] = useState([]);
  const [subjects, setSubject] = useState<any>([]);
  const [terms, setTerm] = useState([]);
  const [campuses, setCampus] = useState([]);
  const [chosenCourse, setChosenCourse] = useState<any>({});
  const [chosenSubject, setChosenSubject] = useState("");
  const [chosenSemester, setChosenSemester] = useState("");
  const [searchedCourse, setSearchedCourse] = useState([]);
  const [searchedSection, setSearchedSection] = useState([]);

  const [searchForm] = Form.useForm();
  

  const onSelectSec = (values: any) => {
    const ss = sections.filter((section: any) => section.course === values);
    setSearchedSection(ss);
  };

  const onSearch = (values: any) => {
    console.log(values);
    console.log(sections[0]);
    if (values.course) {
      console.log("By course")
      if(!values.course.number){
        console.log("sub")
        const course: any = courses.filter(
          (course: any) =>
            course.subject === values.course.subject
        );
        setSearchedCourse(course);
      }else{
        const course: any = courses.filter(
          (course: any) =>
            course.subject === values.course.subject && course.courseNum === values.course.number
        );
        setSearchedCourse(course);
      }
    }else if(values.campus){
      const section: any = sections.filter((section: any) => section.campus === values.campus);
      setSearchedSection(section);
    }else if(values.term) {
      if(values.term.crn) {
        const section: any = sections.filter((section: any) => section.crn === values.term.crn);
        setSearchedSection(section);
      }else{
        const section: any = sections.filter((section: any) => section.term === values.term.semester);
        setSearchedSection(section);
      }
    }
     else {
      const course: any = courses.filter(
        (course: any) => course.subject === values.course.subject
      );
      setSearchedCourse(course);
    }
  };

  useEffect(() => {
    courseApi
      .get("Course")
      .then((res) => {
        console.log(res.data);
        setCourses(res.data);
        setSearchedCourse(res.data);
      })
      .catch((err) => console.log(err));

    var temp: any = [];
    courseApi
      .get("Meeting")
      .then((res) => {
        temp = res.data;
        console.log(res.data);
        const timeformat =
          res.data[0].times[0].day[0] +
          " " +
          res.data[0].times[0].start +
          " - " +
          res.data[0].times[0].end;
        console.log(timeformat);
        temp.map((section: any) => {
          section.instructor = "Mallory";
          section.teachingAssistant = "Hardik";
          section.times =
            section.times[0].day[0] +
            " " +
            section.times[0].start +
            " - " +
            section.times[0].end;
          courseApi
            .get(`Term/${section.term}`)
            .then((res) => {
              section.term = res.data.semester + " " + res.data.year;
            })
            .catch((e) => (section.term = "----"));
          courseApi
            .get(`Campus/${section.campus}`)
            .then((res) => {
              section.campus = res.data.campusName;
            })
            .catch((e) => (section.campus = "----"));
          // courseApi
          //   .get(`Course/${section.course}`)
          //   .then((res) => {
          //     section.course = res.data.subject + "-" + res.data.courseNum;
          //   })
          //   .catch((e) => (section.course = "----"));
          courseApi
            .get(`ClassLocation/${section.location}`)
            .then((res) => {
              section.location =
                res.data.buildingName +
                " " +
                res.data.buildingCode +
                "-" +
                res.data.room;
            })
            .catch((e) => (section.location = "----"));
          courseApi
            .get(`ClassLocation/${section.alternateLocation}`)
            .then((res) => {
              section.alternateLocation =
                res.data.buildingName +
                " " +
                res.data.buildingCode +
                "-" +
                res.data.room;
            })
            .catch((e) => (section.alternateLocation = "----"));
        });
      })
      .finally(() => setSection(temp));

    courseApi.get("Term").then((res) => setTerm(res.data));
    courseApi.get("Campus").then((res) => {
      console.log(res.data);
      setCampus(res.data)
      
    });
  }, []);

  useEffect(() => {
    setSubject(
      courses
        .map((course: any) => course.subject)
        .filter(
          (value: any, index: any, array: any) => array.indexOf(value) === index
        )
    );
  }, [courses, searchedSection]);

  return (
    <>
      <Card style={{ width: "99%" }}>
        <Typography.Title level={4}>Courses</Typography.Title>
        <Form
          name="searchCourse"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 8 }}
          labelAlign={"left"}
          layout={"horizontal"}
          onFinish={onSearch}
          form={searchForm}
        >
          <Form.Item label="Course Number" name="course">
            <Input.Group compact>
              <Form.Item
                name={["course", "subject"]}
                rules={[{ required: true, message: "Enter a Course Subject" }]}
                noStyle
              >
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Subject"
                  optionFilterProp="subjects"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  onSelect={(value: any) => {
                    setChosenSubject(value);
                    searchForm.setFieldsValue({ course: { number: "" } });
                  }}
                >
                  {subjects.map((item: any, index: any) => (
                    <Option key={index} value={item}>
                      {item}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item name={["course", "number"]} noStyle>
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Number"
                  optionFilterProp="number"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {courses
                    .filter((course: any) => course.subject === chosenSubject)
                    .map((item: any, index) => (
                      <Option key={index} value={item.courseNum}>
                        {item.courseNum}
                      </Option>
                    ))}
                </Select>
              </Form.Item>
            </Input.Group>
          </Form.Item>
       
          <Form.Item label=" " colon={false}>
            <Button type="primary" htmlType="submit">
              Search
            </Button>
          </Form.Item>
          {/* <Form.Item label=" " colon={false}>
            <Button >
              View All
            </Button>
          </Form.Item> */}
        </Form>
        <Table
          dataSource={searchedCourse}
          scroll={{ y: 240, x: 914 }}
          size="small"
          bordered={true}
          style={{ width: "99%" }}
        >
          <Column
            title="Subject"
            dataIndex="department"
            key="subject"
            sorter={(a: any, b: any) =>
              a.department.length - b.department.length
            }
          />
          <Column title="Number" dataIndex="courseNum" key="number" />
          <Column title="Name" dataIndex="name" key="name" />
          <Column title="Hours" dataIndex="hours" key="hours" />
          <Column title="Course Type" dataIndex="courseType" key="type" />
          <Column
            title="Pre-Requisites"
            dataIndex="preRequisites"
            key="preRequisites"
          />
          <Column
            title="Co-Requisites"
            dataIndex="coRequisites"
            key="coRequisites"
          />
          <Column
            title="Action"
            key="action"
            render={(item: any) => (
              <Button
                data-classID={item?.id}
                onClick={() => onSelectSec(item?.id)}
              >
                View Sections
              </Button>
            )}
          />
        </Table>
      </Card>
     
        <Card style={{ width: "99%" }}>
          <Typography.Title level={4}>Sections</Typography.Title>
          {searchedSection.length !== 0 ? (
          <Table
            dataSource={searchedSection}
            scroll={{ y: 240, x: 914 }}
            size="small"
            bordered={true}
            style={{ width: "99%" }}
          >
            <Column title="Term" dataIndex="term" key="term" />
            <Column title="Campus" dataIndex="campus" key="campus" />
            {/* <Column title="Course" dataIndex="" key="course" /> */}
            <Column
              title="Section Number"
              dataIndex="sectionNum"
              key="sectionNum"
            />
            <Column
              title="Section Seats Available"
              dataIndex="seatsAvailable"
              key="seatsAvailable"
            />
            <Column title="Meeting Times" dataIndex="times" key="times" />
            <Column title="crn" dataIndex="crn" key="crn" />
            <Column
              title="Instructor"
              dataIndex="instructor"
              key="instructor"
            />
            <Column
              title="Teaching Assistant"
              dataIndex="teachingAssistant"
              key="teachingAssistant"
            />
            <Column title="Location" dataIndex="location" key="location" />
            <Column
              title="Alternate Location"
              dataIndex="alternateLocation"
              key="location"
            />
            <Column title="Grademode" dataIndex="gradeMode" key="gradeMode" />
            <Column title="Method" dataIndex="method" key="method" />
          </Table>
              ) : null}
          <Form
            name="searchSection"
            autoComplete="off"
            labelCol={{ span: 4 }}
            wrapperCol={{ span: 8 }}
            labelAlign={"left"}
            layout={"horizontal"}
            onFinish={onSearch}
          >
            <Form.Item
              name="term"
              label="Term"
              style={{ display: "inline-list-item" }}
              // rules={[{ required: true }]}
            >
              <Input.Group compact>
                <Form.Item
                  name={["term", "semester"]}
                  noStyle
                  
                >
                  <Select
                    style={{ width: "50%" }}
                    showSearch
                    placeholder="Semester"
                    optionFilterProp="semesters"
                    filterOption={(input, option: any) =>
                      option.value.toLowerCase().indexOf(input.toLowerCase()) >=
                      0
                    }
                    onSelect={(value: any) => setChosenSemester(value)}
                  >
                    {terms.map((term: any, index) => (
                      <Option key={index} value={term.semester + " " + term.year}>
                        {term.semester + " " + term.year}
                      </Option>
                    ))}
                  </Select>
                </Form.Item>

                
              </Input.Group>
            </Form.Item>

            <Form.Item
              name="campus"
              label="Campus"
             
            >
              <Select
                showSearch
                optionFilterProp="campuses"
                filterOption={(input, option: any) =>
                  option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
                defaultValue={chosenCourse.campus}
              >
                {campuses.map((campus: any, index) => (
                  <Option key={index} value={campus.campusName}>
                    {" "}
                    {campus.campusName}{" "}
                  </Option>
                ))}
              </Select>
            </Form.Item>

        

            <Form.Item name="crn" label="CRN Number">
              <Input />
            </Form.Item>

            <Form.Item label=" " colon={false}>
              <Button type="primary" htmlType="submit">
                Search
              </Button>
            </Form.Item>
          </Form>
        </Card>
  
    </>
  );
};

export default ViewCourses;
