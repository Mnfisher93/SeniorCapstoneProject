import React, { useEffect, useState } from "react";

import {
  Form,
  Space,
  Card,
  Select,
  Input,
  InputNumber,
  Button,
  Checkbox,
  TimePicker,
} from "antd";
import { MinusCircleOutlined, PlusOutlined } from "@ant-design/icons";
import { forEach } from "lodash";

import { testCourses, testTerm, testCampus, testInstructor } from "./testData";
import {courseApi} from "../../App";

const { Option } = Select;

const CreateSection = () => {
  const [campuses, setCampus] = useState([]);
  const [terms, setTerm] = useState([]);
  const [courses, setCourses] = useState([]);
  const [instructors, setInstructor] = useState(testInstructor);
  const [teachingAssistants, setTeachingAssistant] = useState(testInstructor);
  const [locations, setLocation] = useState([]);

  const [chosenCourse, setChosenCourse] = useState();
  const [chosenBuilding, setChosenBuilding] = useState();
  const [chosenSemester, setChosenSemester] = useState();

  const onFinish = (values: any) => {
    console.log("Create Section: ", values);

    const course : any = courses.filter(
      (course: any) =>
        course.subject === values.course.subject &&
        course.courseNum === values.course.number
    );
    const campus : any  = campuses.filter(
      (campus: any) => campus.campusName === values.campus
    );
    const term : any  = terms.filter(
      (term: any) =>
        term.semester + " " + term.year === values.terms.semester
    );
    const location: any = locations.filter(
      (location: any) =>
        location.buildingName === values.location.building &&
        location.room === values.location.room
    );
    const altLocation: any = locations.filter(
      (location: any) =>
        location.buildingName === values.altLocation.building &&
        location.room === values.altLocation.room
    );
    console.log("Course: ", course, "\nCampus: ", campus, "\nTerm: ", term);

    var courseID = course[0].id;
    var campusID = campus[0].id;
    var termID = term[0].id;
    var instructorID = instructors[0].id;
    var taID = instructorID;
    var times: any = [];
    var locationID = location[0].id;
    var alternateLocationID = altLocation[0].id;

    values.times.map((time: any) => {
      time.day.map((d: any) => {
        let st = time.start._d.toString();
        let ed = time.end._d.toString();
        times.push({
          day: d,
          start: st
            .substring(st.indexOf(":") - 2, st.indexOf(":") + 3)
            .replace(":", ""),
          end: ed
            .substring(ed.indexOf(":") - 2, ed.indexOf(":") + 3)
            .replace(":", ""),
        });
      });
    });
    values.times = times.splice(1);

    const section = {
      crn: values.crn,
      course: courseID,
      sectionNum: values.section,
      gradeMode: values.grademode,
      campus: campusID,
      method: values.method,
      term: termID,
      instructor: instructorID,
      teachingAssistant: taID,
      times: times,
      location: locationID,
      alternateLocation: alternateLocationID,
      seatsAvailable: values.seats,
      waitList: 0,
    };

    console.log(section);

    courseApi.post("Meeting", section).then(
    	(data) =>
    	{
    		console.log(data);
    	}
    ).catch(
    	(e) => {
    		console.log("ERROR", e);
    	}
    )
  };

  useEffect(() => {
    // campus
    courseApi
      .get("Campus")
      .then((response) => {
        setCampus(response.data);
      })
      .catch((err) => console.log("Campus fetch error"));

    // courses
    courseApi
      .get("Course")
      .then((response) => {
        setCourses(response.data);
      })
      .catch((err) => console.log("Courses fetch error"));

    // term
    courseApi
      .get("Term")
      .then((response) => {
        setTerm(response.data);
        console.log(terms);
      })
      .catch((err) => console.log("Term fetch error"));

    // // instructor
    // axios.get("")
    // .then((response) => {
    // 	console.log(response.data);
    // 	//setInstructor(response.data);
    // })
    // .catch((err) => console.log("Instructor fetch error"));

    // // teaching assistant
    // axios.get("")
    // .then((response) => {
    // 	console.log(response.data);
    // 	//setTeachingAssistant(response.data);
    // })
    // .catch((err) => console.log("TA fetch error"));

    //location
    courseApi
      .get("ClassLocation")
      .then((response) => {
        console.log("Class Location: ", response.data);
        setLocation(response.data);
      })
      .catch((err) => console.log("classLocation fetch error"));

  }, []);

  return (
    <>
      <Card style={{ width: "99%" }}>
        <Form
          name="createSec"
          autoComplete="off"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 8 }}
          labelAlign={'left'}
          layout={'horizontal'}
          initialValues={{ times: [undefined] }}
          onFinish={onFinish}
        >
          <Form.Item name="terms" label="Term" rules={[{ required: true }]}>
            <Input.Group compact>
              <Form.Item
                noStyle
                name={["terms", "semester"]}
                rules={[{ required: true, message: "Enter a Semester Term" }]}
              >
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Semester"
                  optionFilterProp="semesters"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  onSelect={(value: any) => setChosenSemester(value)}
                >
                  {terms.map((item : any, index) => (
                    <Option key={item.id} value={item.semester+ " " +item.year}>
                      {item.semester+ " " +item.year}
                    </Option>
                  ))}
                </Select>
              </Form.Item>

              {/* <Form.Item
								noStyle
								name={['terms','year']}
								rules={[{ required: true, message: "Enter a Year"}]}
							>
								<Select
									style={{ width: '50%' }}
									showSearch
									placeholder="Year"
									optionFilterProp="years"
									filterOption={(input, option : any) => 
										option.value.indexOf(input) >= 0
									}
								>
									{terms.map((item : any, index) =>
										<Option key={index} value={item.year}>
											{item.year}
										</Option>
									)}
								</Select>
							</Form.Item> */}
            </Input.Group>
          </Form.Item>

          <Form.Item
            name="campus"
            label="Campus"
            rules={[{ required: true, message: "Enter a Campus" }]}
          >
            <Select
              showSearch
              optionFilterProp="campuses"
              filterOption={(input, option: any) =>
                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              {campuses.map((item : any, index) => (
                <Option key={index} value={item.campusName}>
                  {item.campusName}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item name="course" label="Course" rules={[{ required: true }]}>
            <Input.Group compact>
              <Form.Item
                noStyle
                name={["course", "subject"]}
                rules={[{ required: true, message: "Enter a Subject" }]}
              >
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Subject"
                  optionFilterProp="subjects"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  onChange={(value: any) => setChosenCourse(value)}
                >
                  {courses.map((item:any, index) => (
                    <Option key={index} value={item.subject}>
                      {item.subject}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item
                noStyle
                name={["course", "number"]}
                rules={[{ required: true, message: "Enter a Course Number" }]}
              >
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Number"
                  optionFilterProp="number"
                  filterOption={(input, option: any) =>
                    option.value.indexOf(input) >= 0
                  }
                >
                  {courses
                    .filter((course: any) => course.subject === chosenCourse)
                    .map((item : any, index) => (
                      <Option key={index} value={item.courseNum}>
                        {item.courseNum}
                      </Option>
                    ))}
                </Select>
              </Form.Item>
            </Input.Group>
          </Form.Item>

          <Form.Item
            name="crn"
            label="CRN Number"
            rules={[{ required: true, message: "Enter a CRN Number" }]}
          >
            <Input />
          </Form.Item>

          <Form.Item
            name="section"
            label="Section Number"
            rules={[{ required: true, message: "Enter a Section Number" }]}
          >
            <Input/>
          </Form.Item>

          <Form.Item label="Section Seats Available" name="seats">
            <InputNumber min={1} />
          </Form.Item>

          <Form.List name="times">
            {(fields, { add, remove }) => (
              <>
                {fields.map(({ key, name, fieldKey, ...restField }) => (
                  <Space
                    key={key}
                    style={{ display: "flex", marginBottom: 8 }}
                    align="baseline"
                  >
                    <Form.Item
                      label=" "
                      colon={false}
                      {...restField}
                      name={[name, "day"]}
                      fieldKey={[fieldKey, "day"]}
                      rules={[{ required: true, message: "Pick a Day" }]}
                      labelCol={{ span: 30 }}
                      wrapperCol={{ span: 30 }}
                    >
                      <Checkbox.Group
                        options={[
                          "Monday",
                          "Tuesday",
                          "Wednesday",
                          "Thursday",
                          "Friday",
                        ]}
                      />
                    </Form.Item>
                    <Form.Item
                      {...restField}
                      name={[name, "start"]}
                      fieldKey={[fieldKey, "start"]}
                      label="Start"
                      rules={[{ required: true, message: "Pick a Start Time" }]}
                      labelCol={{ span: 30 }}
                      wrapperCol={{ span: 30 }}
                    >
                      <TimePicker format="hh:mm" />
                    </Form.Item>
                    <Form.Item
                      {...restField}
                      name={[name, "end"]}
                      fieldKey={[fieldKey, "end"]}
                      label="End"
                      labelCol={{ span: 30 }}
                      wrapperCol={{ span: 30 }}
                    >
                      <TimePicker format="hh:mm" />
                    </Form.Item>
                    <MinusCircleOutlined onClick={() => remove(name)} />
                  </Space>
                ))}
                <Form.Item wrapperCol={{ offset: 3, span: 10 }}>
                  <Button
                    type="dashed"
                    onClick={() => add()}
                    block
                    icon={<PlusOutlined />}
                  >
                    Add Day and Time
                  </Button>
                </Form.Item>
              </>
            )}
          </Form.List>

          <Form.Item name="instructor" label="Instructor">
            <Select
              showSearch
              optionFilterProp="instructors"
              filterOption={(input, option: any) =>
                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              {instructors.map((d) => (
                <Option key={d.id} value={d.firstName}>
                  {d.firstName+" "+d.lastName}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item name="ta" label="Teaching Assistant">
            <Select
              showSearch
              optionFilterProp="tas"
              filterOption={(input, option: any) =>
                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
            >
              {instructors.map((d) => (
                <Option key={d.id} value={d.firstName}>
                  {d.firstName+" "+d.lastName}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item name="location" label="Location">
            <Input.Group compact>
              <Form.Item noStyle name={["location", "building"]}>
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Building"
                  optionFilterProp="buildings"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) > 0
                  }
                  onSelect={(value: any) => setChosenBuilding(value)}
                >
                  {locations.map((item: any, index) => (
                    <Option key={index} value={item.buildingName}>
                      {item.buildingName}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item noStyle name={["location", "room"]}>
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Room Number"
                  optionFilterProp="rooms"
                  filterOption={(input, option: any) =>
                    option.value.indexOf(input) >= 0
                  }
                >
                  {locations.map((item: any, index) => (
                    <Option key={index} value={item.room}>
                      {item.room}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Input.Group>
          </Form.Item>

          <Form.Item name="altLocation" label="Alternate Location">
            <Input.Group compact>
              <Form.Item noStyle name={["altLocation", "building"]}>
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Building"
                  optionFilterProp="buildings"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) > 0
                  }
                  onSelect={(value: any) => setChosenBuilding(value)}
                >
                  {locations.map((item: any, index) => (
                    <Option key={index} value={item.buildingName}>
                      {item.buildingName}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
              <Form.Item noStyle name={["altLocation", "room"]}>
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Room Number"
                  optionFilterProp="rooms"
                  filterOption={(input, option: any) =>
                    option.value.indexOf(input) >= 0
                  }
                >
                  {locations.map((item: any, index) => (
                    <Option key={index} value={item.room}>
                      {item.room}
                    </Option>
                  ))}
                </Select>
              </Form.Item>
            </Input.Group>
          </Form.Item>

          <Form.Item name="grademode" label="Grademode">
            <Select defaultValue="standard">
              <Option value="standard">Standard Grading</Option>
              <Option value="other">Other</Option>
            </Select>
          </Form.Item>

          <Form.Item name="method" label="Method">
            <Select defaultValue="face">
              <Option value="face">Face-to-Face</Option>
              <Option value="online">Online</Option>
              <Option value="hybrid">Hybrid</Option>
            </Select>
          </Form.Item>

          <Form.Item
            name="submit"
            wrapperCol={{ offset: 20, span: 16 }}
            style={{ margin: 3 }}
          >
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
            <Button htmlType="button">Reset</Button>
          </Form.Item>
        </Form>
      </Card>
    </>
  );
};

export default CreateSection;
