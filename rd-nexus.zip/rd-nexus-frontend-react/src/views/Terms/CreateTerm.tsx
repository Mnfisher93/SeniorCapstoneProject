import React, { useEffect, useState } from "react";

import {
  Card,
  Form,
  Input,
  InputNumber,
  Select,
  Divider,
  Space,
  Button,
  Alert,
  DatePicker,
} from "antd";
import { MinusCircleOutlined, PlusOutlined } from "@ant-design/icons";
import moment from "moment";

import { courseApi } from "../../App";

const { Option } = Select;
const { RangePicker } = DatePicker;
const dateFormat = "YYYY/MM/DD";
const weekFormat = "MM/DD";
const monthFormat = "YYYY/MM";

const dateFormatList = ["DD/MM/YYYY", "DD/MM/YY"];

const months = ["", "Jan", "Feb", "Mar","Apr","May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];


const CreateTerm = () => {
  const [terms, setTerm] = useState([]);
  const [semesters, setSemesters] = useState<any>([]);
  const [semester, setSemester] = useState("");

  const [start, setStart] = useState("");
  const [end, setEnd] = useState("");

  const onFinish = (values: any) => {
    console.log("Create Term: ", values);
    // const start = (values.duration[0]._d).toString().split(' ');
    // const end = (values.duration[1]._d).toString().split(' ');

     const term = {
      semester: values.semester,
      year: start[3],
      start: values.duration[0]._d,
      end: values.duration[0]._d
    };
    console.log(term);
    courseApi
      .post("Term", term)
      .then((response) => {
        // Notify sucess
        console.log(response);
      })
      .catch((e) =>
        // notify error
        console.log(e)
      );
  };

  useEffect(() => {
    courseApi
      .get("Term")
      .then((response) => {
        setTerm(response.data);
      })
      .catch((err) => console.log("Semester create error"));
  }, []);

  useEffect(() => {
    const semesters = terms
      .map((course: any) => course.semester)
      .filter(
        (value: any, index: any, array: any) => array.indexOf(value) === index
      );
    setSemesters(semesters);
  }, [terms]);

  const addItem = () => {
    setSemesters([...semesters, semester]);
    setSemester("");
  };

  return (
    <>
      <Card style={{ width: "99%" }}>
        <Form
          name="createTerm"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 8 }}
          labelAlign={"left"}
          layout={"horizontal"}
          onFinish={onFinish}
        >
          <Form.Item
            name="semester"
            label="Semester"
            rules={[{ required: true, message: "Select the semester" }]}
          >
            <Select
              showSearch
              optionFilterProp="semester"
              filterOption={(input, option: any) =>
                option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
              }
              dropdownRender={(menu) => (
                <div>
                  {menu}
                  <Divider style={{ margin: "4px 0" }} />
                  <div
                    style={{
                      display: "flex",
                      flexWrap: "nowrap",
                      padding: 8,
                    }}
                  >
                    <Input
                      style={{ flex: "auto" }}
                      value={semester}
                      onChange={(e) => setSemester(e.target.value)}
                    />
                    <a
                      style={{
                        flex: "none",
                        padding: "8px",
                        display: "block",
                        cursor: "pointer",
                      }}
                      onClick={addItem}
                    >
                      <PlusOutlined /> Add item
                    </a>
                  </div>
                </div>
              )}
            >
              {semesters.map((item: any, index: any) => (
                <Option key={index} value={item}>
                  {item}
                </Option>
              ))}
            </Select>
          </Form.Item>

          <Form.Item
            name="duration"
            label="Duration"
            rules={[{ required: true, message: "Enter Duration" }]}
          >
            <RangePicker
             
              format={dateFormat}
              onChange={(value: any, dateFormat: any) => setStart(dateFormat)}
            />
            
          </Form.Item>

          {/* <Form.Item
            name="end"
            label="End date"
            rules={[{ required: true, message: "Enter End date" }]}
          >
            <DatePicker
              onChange={(value: any, dateFormat: any) => setEnd(dateFormat)}
            />
          </Form.Item> */}

          <Form.Item label="" colon={false} wrapperCol={{ offset: 10 }}>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </>
  );
};

export default CreateTerm;
