import React, {useEffect} from 'react';

import {Breadcrumb, Menu} from "antd";

import ViewTerm from './ViewTerm';
import CreateTerm from './CreateTerm';
import UpdateTerm from './UpdateTerm';

const Terms = () => {

    const [page, setPage] = React.useState(1);
	const [path, setPath] = React.useState("");

	function handleClick(value : any) {
		switch(value.key){
			case "view":
				setPage(1);
				setPath("View Terms")
				break;
			case "create":
				setPage(2);
				setPath("Create New")
				break;
			case "update":
				setPage(3);
				setPath("Update Information")
				break;
			default:
				setPage(1);
				setPath("View Terms")
		};
	};

    return (
        <>
            <Breadcrumb style={{margin: '16px 0'}}>
                <Breadcrumb.Item>Terms</Breadcrumb.Item>
                {page === 1 ? (
                    <Breadcrumb.Item>View Terms</Breadcrumb.Item>
                ) : (page === 2 ? (
                    <Breadcrumb.Item>Create New</Breadcrumb.Item>
                ) : (page === 3 ? (
                    <Breadcrumb.Item>Update Information</Breadcrumb.Item>
                ) : (
                    <></>
                )))}			
            </Breadcrumb>
        
            <Menu mode="horizontal" defaultSelectedKeys={[ 'view' ]} style={{ width: '99%' }} onClick={handleClick}>
                <Menu.Item key="view">
                    View Terms
                </Menu.Item>
                <Menu.Item key="create">
                    Create New
                </Menu.Item>
                <Menu.Item key="update">
                    Update Information
                </Menu.Item>
            </Menu>
        
            {page === 1 ? (
                <ViewTerm />
            ) : (page === 2 ? (
                <CreateTerm />
            ) : (
                <UpdateTerm />
            ))}
        </>
    );
}

export default Terms;