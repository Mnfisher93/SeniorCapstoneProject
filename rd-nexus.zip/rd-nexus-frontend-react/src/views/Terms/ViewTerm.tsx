import React, {useState, useEffect} from 'react';

import {Card, Typography, Form, Table, Input, Button, Select} from "antd";
import {courseApi} from "../../App";

const {Column} = Table;
const {Option} = Select;

const ViewTerm = () => {	
	const [terms, setTerms] = useState([]);
	const [searchedTerms, setSearchedTerm] = useState([]);
	const [years, setYears] = useState([]);

	const onFinish = (values: any) => {
		const t = terms.filter((term: any) => term.year === values.terms.semester );
		setSearchedTerm(t);
	}

	useEffect( () => {
		courseApi.get("Term").then((res) => {
			setTerms(res.data);
			setSearchedTerm(res.data);
			const y:any = res.data.map((t:any) => t.year).filter((v:any,i:any,a:any) => a.indexOf(v) === i).sort();
			setYears(y);
			console.log(years);
		}).catch((err) => console.log(err));

	
	}, [])


	return (
		<>
			<Card style={{ width: '99%' }}>
				<Typography.Title level={4}>Terms</Typography.Title>
        		<Form
        		  name="searchTerm"
         		  labelCol={{ span: 4 }}
        		  wrapperCol={{ span: 8 }}
        		  labelAlign={ 'left' }
        		  layout={ 'horizontal' }
				  onFinish = {onFinish}
        		>
          			<Form.Item name="terms" label="Year" rules={[{ required: true }]}>
        			    <Input.Group compact>
        			      <Form.Item
        			        noStyle
        			        name={["terms", "semester"]}
        			        rules={[{ required: true, message: "Enter a Semester Term" }]}
        			      >
        			        <Select
        			          style={{ width: "50%" }}
        			          showSearch
        			          placeholder="Semester"
        			          optionFilterProp="semesters"
        			          filterOption={(input, option: any) =>
        			            option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
        			          }
        			        >
								{years.map((item: any, index)=> <Option key = {index} value = {item} name={item}> {item} </Option>)}
                  
        			        </Select>
        			      </Form.Item>

        			      {/* <Form.Item
							noStyle
							name={['term','year']}
							rules={[{ required: true, message: "Enter a Year"}]}
	  					  >
							<Select
								style={{ width: '50%' }}
								showSearch
								placeholder="Year"
								optionFilterProp="years"
								filterOption={(input, option : any) => 
									option.value.indexOf(input) >= 0
								}
							>
							</Select>
						  </Form.Item> */}
            			</Input.Group>
        			  </Form.Item>

          			<Form.Item label=" " colon={false} wrapperCol={{ offset: 6 }}> 
            			<Button type="primary" htmlType="submit">
              				Search
            			</Button>
          			</Form.Item>
        		</Form>
				<Table 
					dataSource={searchedTerms} 
					scroll={{ y: 240, x: 914 }}
					size="small"
					bordered={true}
					style={{ width: '99%' }}
				>
					<Column
						title="Semester"
						dataIndex="semester"
						key="semester"
						sorter={(a: any, b: any) => (a.semester.length - b.semester.length)}
					/>
					<Column
						title="Year"
						dataIndex="year"
						key="year"
						sorter={(a: any, b: any) => (a.year - b.year)}
					/>
					<Column
						title="Start Date"
						dataIndex="start"
						key="start"
					/>
					<Column
						title="End Date"
						dataIndex="end"
						key="end"
					/>
				</Table>
			</Card>
		</>
	);
}

export default ViewTerm;