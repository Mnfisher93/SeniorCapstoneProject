import React, { useState, useEffect } from "react";

import {
  Card,
  Form,
  Input,
  InputNumber,
  Select,
  Divider,
  Space,
  Button,
  Alert,
  DatePicker,
} from "antd";
import {courseApi} from "../../App";
import moment from "moment";

const { Option } = Select;
const { RangePicker } = DatePicker;
const dateFormat = "YYYY/MM/DD";
const weekFormat = "MM/DD";
const monthFormat = "YYYY/MM";

const dateFormatList = ["DD/MM/YYYY", "DD/MM/YY"];

const months = ["", "Jan", "Feb", "Mar","Apr","May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];


const UpdateTerm = () => {
  const [terms, setTerms] = useState([]);
  const [chosenTerm , setChosenTerm ] = useState<any>([]);
  const [form] = Form.useForm();


  const onFinish = (values: any) => {
    console.log(values);
    const term = {
      semester: chosenTerm[0].semester,
      year: chosenTerm[0].year,
      start: values.duration[0]._d,
      end: values.duration[1]._d,
    }
    console.log(chosenTerm[0].semester,term);
    courseApi.post(`Term/${chosenTerm[0].id}`, term).then((res) => console.log(res));
    // form.setFieldsValue({duration: [cTerm.start, cTerm.end]})
    // console.log(form);
  };

  const onSearch = (values:any) => {
   
    console.log(values);
    const cTerm : any = terms.filter((term: any) =>  (term.semester + "-" + term.year)  === values.terms);
    setChosenTerm(cTerm);
   
    console.log(cTerm, chosenTerm);
  }


  useEffect(() => {
    courseApi
      .get("Term")
      .then((res) => {
        setTerms(res.data);
      })
      .catch((err) => console.log(err));
  }, []);

  return (
    <>
      <Card style={{ width: '99%' }}>
        <Form
          name="searchTerm"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 8 }}
          labelAlign={ 'left' }
          layout={ 'horizontal' }
          onFinish = {onSearch}
        >
          <Form.Item name="terms" label="Term" rules={[{ required: true }]}>
           
                <Select
                  style={{ width: "50%" }}
                  showSearch
                  placeholder="Semester"
                  optionFilterProp="semesters"
                  filterOption={(input, option: any) =>
                    option.value.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                >
                  {terms.map((item: any, index) => <Option key={index} value={ item.semester + "-" + item.year } name = {item.semester + "-" + item.year } > {item.semester + "-" + item.year } </Option> )}
                </Select>
              </Form.Item>
        

          <Form.Item label="" colon={false} wrapperCol={{ offset: 10 }}>
            <Button type="primary" htmlType="submit">
              Search
            </Button>
          </Form.Item>
        </Form>
      </Card>

      <Card style={{ width: "99%" }}>
        <Form
          name="updateTerm"
          labelCol={{ span: 4 }}
          wrapperCol={{ span: 8 }}
          labelAlign={'left'}
          layout={'horizontal'}
          onFinish={onFinish}
          form = {form}
        >
          <Form.Item
            name="duration"
            label="Start date"
            rules={[{ required: true, message: "Enter Start date" }]}
          >
            <RangePicker
              defaultValue={[
                moment(chosenTerm.start),
                moment(chosenTerm.end),
              ]}
             
              format={"MM-DD-YYYY"}
             
            />
          </Form.Item>

          {/* <Form.Item
            name="end"
            label="End date"
            rules={[{ required: true, message: "Enter End date" }]}
          >
            <DatePicker
              //onChange={(value: any, dateFormat: any) => setEnd(dateFormat)}
            />
          </Form.Item> */}

          <Form.Item label="" colon={false} wrapperCol={{ offset: 10 }}>
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </Form.Item>
        </Form>
      </Card>
    </>
  );
};

export default UpdateTerm;
