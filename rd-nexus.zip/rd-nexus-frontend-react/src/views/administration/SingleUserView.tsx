import { CloseOutlined, EditOutlined, FilterFilled } from "@ant-design/icons";
import {Button, Card, Form, Input, message, PageHeader, Space, Spin, Table, Typography } from "antd";
import {useEffect, useState } from "react";
import { Link, useParams } from "react-router-dom";
import {authApi} from "../../App";
import { User } from "../../models/auth/User";
import BasicInfo from "../../components/administration/singleUser/BasicInfo";
import AuthService from "../../services/AuthService";
import PhoneNumbers from "../../components/administration/singleUser/PhoneNumbers";
import Emails from "../../components/administration/singleUser/Emails";

const authService = AuthService.getService();

const bcRoutes = [
	{path: '/', breadcrumbName: 'Home'},
	{path: 'admin', breadcrumbName: 'Administration'},
	{path: 'users', breadcrumbName: 'Users'},
	{path: 'users', breadcrumbName: 'View Users'},
];

interface ViewSingleUserParams {
	userId: string
}

const SingleUserView = () => {
	let {userId} = useParams<ViewSingleUserParams>();

	const [loadedUser, setLoadedUser] = useState<User>();
	const [isUserLoading, setIsUserLoading] = useState(true);

	const loadUser = () => {
		setIsUserLoading(true);

		authApi.get(`/user/${userId}`)
			.then((response) => {
				setLoadedUser(response.data);

				setIsUserLoading(false);
			})
			.catch(() => {
				message.error('Could not load user information at this time. Please try again later. If this error persists, please submit a ticket.');

				setIsUserLoading(false);
			});
	}

	useEffect(() => {
		loadUser();
	}, [])

	return (
		<PageHeader
			title={'View User'}
			breadcrumb={{ routes: bcRoutes }}
		>
			<Space direction={'vertical'} style={{width: '100%'}}>
				<BasicInfo user={loadedUser} isLoading={isUserLoading} isEditable={authService.checkAccess('userMgr')} handleUpdate={loadUser}/>
				<PhoneNumbers user={loadedUser} isLoading={isUserLoading} isEditable={authService.checkAccess('userMgr')} handleUpdate={loadUser}/>
				<Emails user={loadedUser} isLoading={isUserLoading} isEditable={authService.checkAccess('userMgr')} handleUpdate={loadUser}/>
			</Space>
		</PageHeader>
	);
}

export default SingleUserView;