import {Button, Card, Checkbox, Form, Input, message, PageHeader, Radio, Select, Space, Tag, Typography} from "antd";
import React, {ReactElement, useEffect, useState} from "react";
import {LockOutlined} from "@ant-design/icons";
import {Classification} from "../../models/auth/Classification";
import {FieldOfStudy} from "../../models/degree/FieldOfStudy";
import {authApi, degreeApi} from "../../App";
import { useHistory } from "react-router-dom";

const bcRoutes = [
	{path: '/', breadcrumbName: 'Home'},
	{path: 'admin', breadcrumbName: 'Administration'},
	{path: 'newuser', breadcrumbName: 'New User'},
];

const NewUserView = () => {
	let history = useHistory();

	const [newUserForm] = Form.useForm();
	const [isNewUserSaving, setIsNewUserSaving] = useState(false);

	const [isClassificationsLoading, setIsClassificationsLoading] = useState<boolean>(true);
	const [classifications, setClassifications] = useState<Classification[]>([]);

	const [isMajorsLoading, setIsMajorsLoading] = useState<boolean>(true);
	const [majors, setMajors] = useState<FieldOfStudy[]>([]);

	const [isMinorsLoading, setIsMinorsLoading] = useState<boolean>(true);
	const [minors, setMinors] = useState<FieldOfStudy[]>([]);

	const loadClassifications = () => {
		setIsClassificationsLoading(true);

		authApi.get(`/classification`)
			.then((response) => {
				setClassifications(response.data);
				setIsClassificationsLoading(false);

				loadMajors();
				loadMinors();
			})
			.catch(() => {
				setIsClassificationsLoading(false);
				message.error('Error loading classifications. Please try again later. If this error persists, please submit a ticket.');
			});
	}

	const loadMajors = () => {
		setIsMajorsLoading(true);

		degreeApi.get(`/FieldOfStudy/majors`)
			.then((response) => {
				setMajors(response.data);
				setIsMajorsLoading(false);
			})
			.catch(() => {
				setIsMajorsLoading(false);
				message.error('Error loading majors. Please try again later. If this error persists, please submit a ticket.');
			});
	}

	const loadMinors = () => {
		setIsMinorsLoading(true);

		degreeApi.get(`/FieldOfStudy/minors`)
			.then((response) => {
				setMinors(response.data);
				setIsMinorsLoading(false);
			})
			.catch(() => {
				setIsMinorsLoading(false);
				message.error('Error loading minors. Please try again later. If this error persists, please submit a ticket.');
			});
	}

	const handleSaveNewUser = (values: any) => {
		setIsNewUserSaving(true);

		authApi.post(`/user`, values)
			.then((response) => {
				setIsNewUserSaving(false);
				message.success('Successfully created new user!');
				if(values.addAnother) {
					newUserForm.resetFields();
				} else {
					history.push(`/users/${response.data.id}`);
				}
			})
			.catch(() => {
				setIsNewUserSaving(false);
				message.error('Error creating new user. Please try again later. If this error persists, please submit a ticket.');
			})
	}

	// Things to do on the initial component mount
	useEffect(() => {
		loadClassifications();
	}, []);

	return (
		<PageHeader
			title={'New User'}
			breadcrumb={{ routes: bcRoutes }}
		>
			<Card>
				<Form
					form={newUserForm}
					onFinish={handleSaveNewUser}
					labelCol={{ span: 4 }}
					wrapperCol={{ span: 8 }}
					labelAlign={'left'}
					layout={'horizontal'}
					initialValues={{
						userType: 'student',
						status: 'Registration Required'
					}}
				>
					<fieldset disabled={isNewUserSaving}>
						<Form.Item
							label={'User ID'}
							name={'userId'}
							rules={[{required: true, message: 'A User ID is required'}]}
							tooltip={'Manual User ID entry is required. Automatic User ID generation has not been configured on this Nexus instance.'}
						>
							<Input/>
						</Form.Item>

						<Form.Item
							label={'Username'}
							name={'username'}
							rules={[{required: true, message: 'A Username is required'}]}
						>
							<Input/>
						</Form.Item>

						<Form.Item
							label={'Legal First Name'}
							name={'firstName'}
							rules={[{required: true, message: 'First name is required'}]}
						>
							<Input/>
						</Form.Item>

						<Form.Item
							label={'Legal Last Name'}
							name={'lastName'}
							rules={[{required: true, message: 'Last name is required'}]}
						>
							<Input/>
						</Form.Item>

						<Form.Item
							label={'Classification'}
							name={'classifications'}
							rules={[{required: true, message: 'At least one classification must be provided'}]}
						>
							<Select
								mode={'multiple'}
								filterOption={(input: string, option: any) => option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0}
								options={classifications.map((element: Classification) => {
									return {label: element.name, value: element.id}
								})}
								loading={isClassificationsLoading}
							/>
						</Form.Item>

						<Form.Item
							label={'Major(s)'}
							name={'majors'}
							rules={[{required: true, message: 'At least one major must be provided'}]}
						>
							<Select
								mode={'multiple'}
								filterOption={(input: string, option: any) => option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0}
								options={majors.map((element: FieldOfStudy) => {
									return {label: element.name, value: element.id}
								})}
								loading={isMajorsLoading}
							/>
						</Form.Item>

						<Form.Item
							label={'Minor(s)'}
							name={'minors'}
						>
							<Select
								mode={'multiple'}
								filterOption={(input: string, option: any) => option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0}
								options={minors.map((element: FieldOfStudy) => {
									return {label: element.name, value: element.id}
								})}
								loading={isMinorsLoading}
							/>
						</Form.Item>

						<Form.Item
							label={<span>Status <LockOutlined style={{color: '#CC0000'}}/></span>}
							tooltip={'This is the default status and cannot be changed.'}
							name={'status'}
						>
							<Input readOnly={true}/>
						</Form.Item>
					</fieldset>

					<Form.Item name={'addAnother'} valuePropName={'checked'}>
						<Checkbox>Add another?</Checkbox>
					</Form.Item>

					<Form.Item>
						<Space>
							<Button type={'primary'} htmlType={'submit'} loading={isNewUserSaving}>Save New User</Button>
							<Button htmlType={'reset'} loading={isNewUserSaving}>Clear</Button>
						</Space>
					</Form.Item>
				</Form>
			</Card>
		</PageHeader>
	);
}

export default NewUserView;