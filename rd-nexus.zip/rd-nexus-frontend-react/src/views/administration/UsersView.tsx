import { CloseOutlined, FilterFilled } from "@ant-design/icons";
import {Button, Input, message, PageHeader, Space, Table, Typography } from "antd";
import {useEffect, useState } from "react";
import { Link } from "react-router-dom";
import {authApi} from "../../App";

const bcRoutes = [
	{path: '/', breadcrumbName: 'Home'},
	{path: 'admin', breadcrumbName: 'Administration'},
	{path: 'users', breadcrumbName: 'Users'},
];

const UsersView = () => {
	const [users, setUsers] = useState<any>();
	const [isUsersLoading, setIsUsersLoading] = useState(true);
	const [usersPagination, setUsersPagination] = useState({current: 1, pageSize: 10});
	const [filters, setFilters] = useState<any>({});

	const loadUsers = (pagination: any, sorter: any) => {
		setIsUsersLoading(true);

		authApi.get(`/user/paginated`, {
			params: {
				pageIndex: pagination.current - 1,
				pageSize: pagination.pageSize,
				orderBy: sorter.field,
				isAscending: sorter.order === 'ascend' ? true : false,
				...filters,
			}
		})
			.then((response) => {
				setUsers(response.data.data);
				setUsersPagination({...pagination, total: response.data.count});

				setIsUsersLoading(false);
			})
			.catch(() => {
				message.error('Could not load users at this time. Please try again later. If this error persists, please submit a ticket.');

				setIsUsersLoading(false);
			})
	}

	useEffect(() => {
		const delay = setTimeout(() => {
			loadUsers(usersPagination, {order: 'ascend', field: 'lastName'});
		}, 350);

		return () => clearTimeout(delay);
	}, [filters])

	const getColSearchProps = (dataIndex: string) => {
		let searchInput: any;

		return (
			{
				filterDropdown: () => (
					<div style={{padding: 8}}>
						<Space direction={'horizontal'}>
							<Input
								ref={node => {
									searchInput = node;
								}}
								onChange={(e: any) => {
									let newFilters: any = filters;

									newFilters[dataIndex] = e.target.value;
									setFilters({...newFilters});
								}}
								value={filters[dataIndex]}
							/>
							<Button
								icon={<CloseOutlined/>}
								title={'Clear'}
								onClick={() => {
									let newFilters: any = filters;

									newFilters[dataIndex] = '';
									setFilters({...newFilters});
								}}
							/>
						</Space>
					</div>
				),
				onFilterDropdownVisibleChange: (visible: boolean) => {
					if (visible) {
						setTimeout(() => searchInput.select(), 100);
					}
				},
				filterIcon: <FilterFilled style={{color: filters[dataIndex] ? '#CC0000' : undefined}} />
			}
		)
	}

	return (
		<PageHeader
			title={'Users'}
			breadcrumb={{ routes: bcRoutes }}
		>
			<Space direction={'vertical'} style={{width: '100%'}}>
				<Button
					onClick={() => {setFilters({})}}
					style={{float: 'left'}}
				>
					Clear Filters
				</Button>

				<Table
					columns={[
						{
							render: (record: any) => (
								<Typography.Text>
									<Link to={`/users/${record.id}`}>Open</Link>
								</Typography.Text>
							)
						},
						{title: 'User ID', dataIndex: 'userId', sorter: true, ...getColSearchProps('userId')},
						{title: 'Last Name', dataIndex: 'lastName', sorter: true, ...getColSearchProps('lastName')},
						{title: 'First Name', dataIndex: 'firstName', sorter: true, ...getColSearchProps('firstName')},
						{title: 'Username', dataIndex: 'username', sorter: true, ...getColSearchProps('username')},
						{title: 'Status', dataIndex: 'status', sorter: true, ...getColSearchProps('status')},
					]}
					rowKey={record => record.id}
					dataSource={users}
					loading={isUsersLoading}
					pagination={usersPagination}
					onChange={loadUsers}
				/>
			</Space>
		</PageHeader>
	);
}

export default UsersView;