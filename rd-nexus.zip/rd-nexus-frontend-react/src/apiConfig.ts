export const AUTH_API_ROOT: string = 'http://ubuntu-svr-001.mpadgett.net/api/auth/api';
export const DEGREE_API_ROOT: string = 'http://ubuntu-svr-001.mpadgett.net/api/degree/api';
export const REG_API_ROOT: string = 'http://ubuntu-svr-001.mpadgett.net/api/reg/api';
export const COURSE_API_ROOT: string = 'http://ubuntu-svr-001.mpadgett.net/api/course/api';
// export const COURSE_API_ROOT: string = 'http://localhost:41186/api';