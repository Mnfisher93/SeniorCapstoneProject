import React, {useState} from 'react';
import {Switch, NavLink, useLocation} from 'react-router-dom';

import NexusRoute from '../components/routing/NexusRoute';
import { RouteDefinition, RouteGroup, routeGroups } from '../routes';

import logo from '../assets/png/nexus-logo-2.png';
import {Col, Layout, Menu, Row, Typography, Image, message} from "antd";
import {LogoutOutlined} from '@ant-design/icons';
import AuthService from "../services/AuthService";

const authService = AuthService.getService();

const SidebarLayout = () => {
	const currentLocation = useLocation();

	const [isSidebarCollapsed, setIsSidebarCollaped] = useState(false);
	const rootSubmenuKeys = routeGroups.map((item) => item.key);
	const [openKeys, setOpenKeys] = useState(['0']);
	const handleLogout = () => {
		message.success('You have successfully logged out.');

		authService.clearTokens();
	}

	const onCollapse = (collapsed: boolean) => {
		setIsSidebarCollaped(collapsed);
	};
	
	const onOpenChange = (keys: Array<any>) => {
		const latestOpenKey = keys.find((key: any) => openKeys.indexOf(key) === -1);
		if (rootSubmenuKeys.indexOf(latestOpenKey) === -1) {
		  setOpenKeys(keys);
		} else {
		  setOpenKeys(latestOpenKey ? [latestOpenKey] : []);
		}
	  };

	// @ts-ignore
	return (
		<Layout style={{height: '100vh'}}>
			<Layout.Sider collapsible collapsed={isSidebarCollapsed} onCollapse={onCollapse}>
				<div style={{textAlign: 'center', padding: '10px'}}>
					<Image
						src={logo}
						height={64}
						preview={false}
					/>
				</div>
				<Menu
					theme={'dark'}
					defaultSelectedKeys={['1']}
					mode={'inline'}
					selectedKeys={[currentLocation.pathname]}
					onOpenChange={onOpenChange}
					openKeys={openKeys}
					style={{overflowY: 'auto', height: '90%'}}
				>
					{
						[...routeGroups]
							.sort((a: RouteGroup, b: RouteGroup) => (a.orderInMenu > b.orderInMenu) ? 1 : -1)
							.map((group: RouteGroup, key: any) =>
						{
							if(group.displayAsGroup) {
								return (
									<Menu.SubMenu
										key={key}
										icon={group.icon || null}
										title={group.name}
									>
										{
											group.routes
												.filter((route: RouteDefinition) => route.visibleInMenu)
												.sort((a: RouteDefinition, b: RouteDefinition) => (a.orderInGroup > b.orderInGroup) ? 1 : -1)
												.map((route: RouteDefinition) =>
											{
												if(route.permissionKey) {
													if(authService.checkAccess(route.permissionKey)) {
														return (
															<Menu.Item
																key={route.path}
																icon={route.icon || null}
																title={route.name}
															>
																<NavLink to={route.path}>{route.name}</NavLink>
															</Menu.Item>
														);
													}
												} else {
													return (
														<Menu.Item
															key={route.path}
															icon={route.icon || null}
															title={route.name}
														>
															<NavLink to={route.path}>{route.name}</NavLink>
														</Menu.Item>
													);
												}
											})
										}
									</Menu.SubMenu>
								);
							} else {
								return (
									<>
										{
											group.routes
												.filter((route: RouteDefinition) => route.visibleInMenu)
												.sort((a: RouteDefinition, b: RouteDefinition) => (a.orderInGroup > b.orderInGroup) ? 1 : -1)
												.map((route: RouteDefinition) =>
											{
												if(route.permissionKey) {
													if(authService.checkAccess(route.permissionKey)) {
														return (
															<Menu.Item
																key={route.path}
																icon={route.icon || null}
																title={route.name}
															>
																<NavLink to={route.path}>{route.name}</NavLink>
															</Menu.Item>
														);
													}
												} else {
													return (
														<Menu.Item
															key={route.path}
															icon={route.icon || null}
															title={route.name}
														>
															<NavLink to={route.path}>{route.name}</NavLink>
														</Menu.Item>
													);
												}
											})
										}
									</>
								);
							}
						})
					}

					<Menu.Item
						key='Logout'
						icon={<LogoutOutlined />}
						onClick={handleLogout}
					>
						Log out
					</Menu.Item>
				</Menu>
			</Layout.Sider>
			<Layout>
				<Layout.Header style={{padding: '15px 16px'}}>
					<Typography.Title level={3} style={{color: '#FFFFFF'}}>Texas Tech University</Typography.Title>
				</Layout.Header>
				<Layout.Content>
					<div style={{minHeight: '360px', height: '100%', overflow: 'auto'}}>
						<Switch>
							{
								[...routeGroups].map((group: RouteGroup) =>
									group.routes.map((route: RouteDefinition, key) => {
										if(route.permissionKey) {
											if(authService.checkAccess(route.permissionKey)) {
													return (
														<NexusRoute
															path={route.path}
															component={route.component}
															key={key}
														/>
													);
											}
										} else {
												return (
													<NexusRoute
														path={route.path}
														component={route.component}
														key={key}
													/>
												);

										}
									})
								)
							}
						</Switch>
					</div>
				</Layout.Content>
				<Layout.Footer>
					<Row justify={'space-between'}>
						<Col>
							<Typography.Text>
							© 2000-2016 Nexus. All rights reserved
							</Typography.Text>
						</Col>
						<Col>
							<Typography.Text>
								Powered by NEXUS
							</Typography.Text>
						</Col>
					</Row>
				</Layout.Footer>
			</Layout>
		</Layout>
	);
}

export default SidebarLayout;