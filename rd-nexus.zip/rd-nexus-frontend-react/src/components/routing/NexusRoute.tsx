import React from 'react';
import { Route } from 'react-router-dom';

export interface NexusRouteProps {
	path: string;
	component: any;
}

const NexusRoute = (props: NexusRouteProps) => {
	let { component: Component, ...rest } = props;

	return (
		<Route
			{ ...rest }
			render={props => {
				return <Component {...props} />;
			}}
		/>
	);
}

export default NexusRoute;