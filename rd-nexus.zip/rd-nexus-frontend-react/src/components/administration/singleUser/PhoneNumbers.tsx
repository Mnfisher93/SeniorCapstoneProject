import {PhoneNumberEntry, User} from "../../../models/auth/User";
import {Button, Card, Form, Input, InputNumber, message, Modal, Popconfirm, Space, Switch, Table, Tooltip, Typography} from "antd";
import {DeleteOutlined, HeartOutlined, PlusOutlined} from "@ant-design/icons";
import { useState } from "react";
import {authApi} from "../../../App";

const validateMessages = {
	required: '${label} is required!',
	string: {
		range: '${label} must be between ${min} and ${max} numbers',
	},
	pattern: {
		mismatch: '${label} can only contain numbers'
	}
};

export interface PhoneNumbersProps {
	user: User | undefined;
	isEditable: boolean;
	isLoading: boolean;
	handleUpdate: () => void;
}

const PhoneNumbers = (props: PhoneNumbersProps) => {
	const [isNewNumberModalVisible, setIsNewNumberModalVisible] = useState<boolean>(false);
	const [isNewNumberSaving, setIsNewNumberSaving] = useState<boolean>(false);

	const [isChangeSaving, setIsChangeSaving] = useState<boolean>(false);

	const [form] = Form.useForm();

	const handleAdd = (values: any) => {
		setIsNewNumberSaving(true);

		if(props.user?.phoneNumbers && props.user?.phoneNumbers.filter(e => e.phoneNumber === values.phoneNumber).length > 0) {
			message.error('This phone number already exists!');
			return;
		} else {
			authApi.post(`/user/${props.user?.id}/phone/add`, values)
				.then(() => {
					setIsNewNumberSaving(false);
					setIsNewNumberModalVisible(false);
					form.resetFields();
					props.handleUpdate();

					message.success('Successfully added new number!');
				})
				.catch(() => {
					setIsNewNumberSaving(false);
					message.error('Could not add new number. Please try again later. If this error persists, please submit a ticket.');
				})
		}
	}

	const handleRemove = (phoneNumber: string) => {
		setIsChangeSaving(true);

		authApi.post(`/user/${props.user?.id}/phone/remove/${phoneNumber}`)
			.then(() => {
				setIsChangeSaving(false);
				props.handleUpdate();

				message.success('Successfully removed number!');
			})
			.catch(() => {
				setIsChangeSaving(false);
				message.error('Could not remove number. Please try again later. If this error persists, please submit a ticket.');
			})
	}

	const handleMakePrimary = (phoneNumber: string) => {
		setIsChangeSaving(true);

		authApi.put(`/user/${props.user?.id}/phone/setPrimary/${phoneNumber}`)
			.then(() => {
				setIsChangeSaving(false);
				props.handleUpdate();

				message.success('Successfully set primary number!');
			})
			.catch(() => {
				setIsChangeSaving(false);
				message.error('Could not set primary number. Please try again later. If this error persists, please submit a ticket.');
			})
	}

	return (
		<Card
			title={'Phone Numbers'}
			extra={
				props.isEditable &&
					<Button icon={<PlusOutlined/>} type={'primary'} onClick={() => setIsNewNumberModalVisible(true)}>New</Button>
			}
		>
			<Table
				columns={[
					{title: 'Country Code', dataIndex: 'countryCode', width: 150},
					{
						title: 'Phone Number',
						dataIndex: 'phoneNumber',
						render: (text: string) => {
							if(text.length === 10) {
								let match = text.match(/^(\d{3})(\d{3})(\d{4})$/);

								if(match) {
									return '(' + match[1] + ') ' + match[2] + '-' + match[3];
								}
							}

							return text;
						}
					},
					{title: 'Primary', dataIndex: 'primaryFlag', render: (_, record: PhoneNumberEntry) => record.primaryFlag ? 'Yes' : 'No'},
					{title: 'Verified', dataIndex: 'verifiedFlag', render: (_, record: PhoneNumberEntry) => record.verifiedFlag ? 'Yes' : 'No'},
					... props.isEditable ? [{
						title: 'Actions',
						width: 100,
						render: (record: PhoneNumberEntry) => (
							<Space>
								<Popconfirm
									title={'Are you sure you want to make this the primary phone number?'}
									onConfirm={() => handleMakePrimary(record.phoneNumber)}
									okText={'Yes'}
									disabled={record.primaryFlag || !record.verifiedFlag}
								>
									<Tooltip title={record.primaryFlag ? 'This is already the primary phone number' : !record.verifiedFlag ? 'Phone number must be verified to be the primary phone number' : 'Set as primary phone number'}>
										<Button icon={<HeartOutlined/>} type={'default'} disabled={record.primaryFlag || !record.verifiedFlag}/>
									</Tooltip>
								</Popconfirm>
								<Popconfirm
									title={'Are you sure you want to delete this phone number?'}
									onConfirm={() => handleRemove(record.phoneNumber)}
									okText={'Yes'}
									disabled={record.primaryFlag}
								>
									<Tooltip title={record.primaryFlag ? 'You cannot remove the primary phone number' : 'Remove phone number from user'}>
										<Button icon={<DeleteOutlined/>} type={'dashed'} disabled={record.primaryFlag}/>
									</Tooltip>
								</Popconfirm>
							</Space>
						)
					}] : []
				]}
				rowKey={record => record.phoneNumber}
				loading={props.isLoading || isChangeSaving}
				dataSource={props.user?.phoneNumbers}
				pagination={false}
			/>

			<Modal
				title={'New Phone Number'}
				visible={isNewNumberModalVisible}
				okText={'Add Phone Number'}
				okButtonProps={{loading: isNewNumberSaving}}
				onOk={() => {
					form
						.validateFields()
						.then((values: any) => {
							handleAdd(values);
						})
						.catch(() => {});
				}}
				onCancel={() => {
					setIsNewNumberModalVisible(false);
					form.resetFields();
				}}
			>
				<Form
					form={form}
					layout={'vertical'}
					requiredMark={false}
					validateMessages={validateMessages}
				>
					<Form.Item
						name={'countryCode'}
						label={'Country Code'}
						rules={[{required: true, min: 1, max: 3, pattern: /^\d+$/}]}
					>
						<Input/>
					</Form.Item>
					<Form.Item
						name={'phoneNumber'}
						label={'Phone Number'}
						rules={[{required: true, min: 1, max: 15, pattern: /^\d+$/}]}
					>
						<Input/>
					</Form.Item>
					<Form.Item
						name={'primaryFlag'}
						label={'Make Primary?'}
						valuePropName={'checked'}
					>
						<Switch/>
					</Form.Item>
				</Form>
			</Modal>
		</Card>
	)
}

export default PhoneNumbers;