import {User} from "../../../models/auth/User";
import {Button, Card, Col, Form, Input, message, Row, Select, Space, Spin, Typography} from "antd";
import {CloseOutlined, EditOutlined, LockOutlined, SaveOutlined} from "@ant-design/icons";
import {useEffect, useState} from "react";
import {authApi, degreeApi} from "../../../App";
import { Classification } from "../../../models/auth/Classification";
import {FieldOfStudy} from "../../../models/degree/FieldOfStudy";

export interface BasicInfoProps {
	user: User | undefined;
	isEditable: boolean;
	isLoading: boolean;
	handleUpdate: () => void;
}

const BasicInfo = (props: BasicInfoProps) => {
	const [form] = Form.useForm();
	const [isSavingChanges, setIsSavingChanges] = useState<boolean>(false);
	const [isEditMode, setIsEditMode] = useState<boolean>(false);

	const [isClassificationsLoading, setIsClassificationsLoading] = useState<boolean>(true);
	const [classifications, setClassifications] = useState<Classification[]>([]);

	const [isMajorsLoading, setIsMajorsLoading] = useState<boolean>(true);
	const [majors, setMajors] = useState<FieldOfStudy[]>([]);

	const [isMinorsLoading, setIsMinorsLoading] = useState<boolean>(true);
	const [minors, setMinors] = useState<FieldOfStudy[]>([]);

	const loadClassifications = () => {
		setIsClassificationsLoading(true);

		authApi.get(`/classification`)
			.then((response) => {
				setClassifications(response.data);
				setIsClassificationsLoading(false);

				loadMajors();
				loadMinors();
			})
			.catch(() => {
				setIsClassificationsLoading(false);
				message.error('Error loading classifications. Please try again later. If this error persists, please submit a ticket.');
			});
	}

	const loadMajors = () => {
		setIsMajorsLoading(true);

		degreeApi.get(`/FieldOfStudy/majors`)
			.then((response) => {
				setMajors(response.data);
				setIsMajorsLoading(false);
			})
			.catch(() => {
				setIsMajorsLoading(false);
				message.error('Error loading majors. Please try again later. If this error persists, please submit a ticket.');
			});
	}

	const loadMinors = () => {
		setIsMinorsLoading(true);

		degreeApi.get(`/FieldOfStudy/minors`)
			.then((response) => {
				setMinors(response.data);
				setIsMinorsLoading(false);
			})
			.catch(() => {
				setIsMinorsLoading(false);
				message.error('Error loading minors. Please try again later. If this error persists, please submit a ticket.');
			});
	}

	const handleSave = (values: any) => {
		if(!form.isFieldsTouched()) {
			message.info('Make some changes first!');
			return;
		} else {
			setIsSavingChanges(true);

			if(props.user) {
				let user = props.user;

				user.userId = values.userId;
				user.username = values.username;
				user.lastName = values.lastName;
				user.firstName = values.firstName;
				user.classifications = values.classifications;
				user.majors = values.majors;
				user.minors = values.minors;

				authApi.put(`/user/${props.user?.id}`, user)
					.then(() => {
						setIsSavingChanges(false);
						props.handleUpdate();
						setIsEditMode(false);

						message.success('Successfully saved basic information!');
					})
					.catch(() => {
						setIsSavingChanges(false);
						message.error('Could not save basic information. Please try again later. If this error persists, please submit a ticket.');
					})
			} else {
				message.error('Could not save basic information. Please try again later. If this error persists, please submit a ticket.');
			}
		}
	}

	const handleCancel = () => {
		setIsEditMode(false);
		form.resetFields();
	}

	const handleEdit = () => {
		setIsEditMode(true);
	}

	useEffect(() => {
		form.resetFields();
	}, [props.user]);

	useEffect(() => {
		loadClassifications();
	}, []);

	return (
		<Card
			title={'Basic Information'}
			extra={
				props.isEditable ?
					!isEditMode ?
						<Button icon={<EditOutlined/>} type={'primary'} onClick={handleEdit}>Edit</Button>
					:
						<Typography style={{lineHeight: '32px', fontSize: '12pt', fontStyle: 'italic'}}>Editing</Typography>
				:
					null
			}
		>
			<Spin spinning={props.isLoading || isSavingChanges}>
				<fieldset disabled={!isEditMode}>
					<Form
						form={form}
						onFinish={handleSave}
						requiredMark={false}
						layout={'vertical'}
						initialValues={{
							userId: props.user?.userId,
							lastName: props.user?.lastName,
							firstName: props.user?.firstName,
							username: props.user?.username,
							classifications: props.user?.classifications,
							majors: props.user?.majors,
							minors: props.user?.minors,
							status: props.user?.status
						}}
					>
						<Row gutter={16} justify={'space-between'}>
							<Col style={{width: '50%'}}>
								<Form.Item
									name={'userId'}
									label={<span>User ID <LockOutlined style={{color: '#CC0000'}}/></span>}
									rules={[{required: true, message: 'A user ID is required'}]}
									tooltip={'User ID cannot be changed after user creation'}
								>
									<Input readOnly={true}/>
								</Form.Item>
							</Col>
							<Col style={{width: '50%'}}>
								<Form.Item
									name={'username'}
									label={'Username'}
									rules={[{required: true, message: 'A username is required', max: 15}]}
								>
									<Input/>
								</Form.Item>
							</Col>
						</Row>
						<Row gutter={16} justify={'space-between'}>
							<Col style={{width: '50%'}}>
								<Form.Item
									name={'lastName'}
									label={'Last Name'}
									rules={[{required: true, message: 'A last name is required', max: 100}]}
								>
									<Input/>
								</Form.Item>
							</Col>
							<Col style={{width: '50%'}}>
								<Form.Item
									name={'firstName'}
									label={'First Name'}
									rules={[{required: true, message: 'A last name is required', max: 100}]}
								>
									<Input/>
								</Form.Item>
							</Col>
						</Row>
						<Row gutter={16} justify={'space-between'}>
							<Col style={{width: '50%'}}>
								<Form.Item
									name={'classifications'}
									label={'Classifications'}
								>
									<Select
										mode={'multiple'}
										filterOption={(input: string, option: any) => option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0}
										options={classifications.map((element: Classification) => {
											return {label: element.name, value: element.id}
										})}
										loading={isClassificationsLoading}
										disabled={!isEditMode}
									/>
								</Form.Item>
							</Col>
							<Col style={{width: '50%'}}>
								<Form.Item
									name={'majors'}
									label={'Majors'}
									tooltip={'If the user is an instructor, these are the classes they can teach.'}
								>
									<Select
										mode={'multiple'}
										filterOption={(input: string, option: any) => option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0}
										options={majors.map((element: FieldOfStudy) => {
											return {label: element.name, value: element.id}
										})}
										loading={isMajorsLoading}
										disabled={!isEditMode}
									/>
								</Form.Item>
							</Col>
						</Row>

						<Row gutter={16} justify={'space-between'}>
							<Col style={{width: '50%'}}>
								<Form.Item
									name={'minors'}
									label={'Minors'}
								>
									<Select
										mode={'multiple'}
										filterOption={(input: string, option: any) => option.label.toLowerCase().indexOf(input.toLowerCase()) >= 0}
										options={minors.map((element: FieldOfStudy) => {
											return {label: element.name, value: element.id}
										})}
										loading={isMinorsLoading}
										disabled={!isEditMode}
									/>
								</Form.Item>
							</Col>
							<Col style={{width: '50%'}}>
								<Form.Item
									name={'status'}
									label={<span>Status <LockOutlined style={{color: '#CC0000'}}/></span>}
									tooltip={'Status cannot be modified in this preview version'}
								>
									<Input readOnly={true}/>
								</Form.Item>
							</Col>
						</Row>

						{
							isEditMode &&
								<Form.Item style={{float: 'right'}}>
									<Space>
										<Button icon={<CloseOutlined/>} onClick={handleCancel}>Cancel</Button>
										<Button icon={<SaveOutlined/>} type={'primary'} onClick={form.submit} loading={isSavingChanges}>Save Changes</Button>
									</Space>
								</Form.Item>
						}
					</Form>
				</fieldset>
			</Spin>
		</Card>
	);
}

export default BasicInfo;