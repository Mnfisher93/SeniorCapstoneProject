import {EmailEntry, User} from "../../../models/auth/User";
import {Button, Card, Form, Input, InputNumber, message, Modal, Popconfirm, Space, Switch, Table, Tooltip, Typography} from "antd";
import {DeleteOutlined, HeartOutlined, PlusOutlined} from "@ant-design/icons";
import { useState } from "react";
import {authApi} from "../../../App";

const validateMessages = {
	required: '${label} is required!'
};

export interface EmailProps {
	user: User | undefined;
	isEditable: boolean;
	isLoading: boolean;
	handleUpdate: () => void;
}

const Emails = (props: EmailProps) => {
	const [isNewEmailModalVisible, setIsNewEmailModalVisible] = useState<boolean>(false);
	const [isNewEmailSaving, setIsNewEmailSaving] = useState<boolean>(false);

	const [isChangeSaving, setIsChangeSaving] = useState<boolean>(false);

	const [form] = Form.useForm();

	const handleAdd = (values: any) => {
		setIsNewEmailSaving(true);

		if(props.user?.emails && props.user?.emails.filter(e => e.email === values.email).length > 0) {
			message.error('This email already exists!');
			return;
		} else {
			authApi.post(`/user/${props.user?.id}/email/add`, values)
				.then(() => {
					setIsNewEmailSaving(false);
					setIsNewEmailModalVisible(false);
					form.resetFields();
					props.handleUpdate();

					message.success('Successfully added new email!');
				})
				.catch(() => {
					setIsNewEmailSaving(false);
					message.error('Could not add new email. Please try again later. If this error persists, please submit a ticket.');
				})
		}
	}

	const handleRemove = (email: string) => {
		setIsChangeSaving(true);

		authApi.post(`/user/${props.user?.id}/email/remove/${email}`)
			.then(() => {
				setIsChangeSaving(false);
				props.handleUpdate();

				message.success('Successfully removed email!');
			})
			.catch(() => {
				setIsChangeSaving(false);
				message.error('Could not remove email. Please try again later. If this error persists, please submit a ticket.');
			})
	}

	const handleMakePrimary = (email: string) => {
		setIsChangeSaving(true);

		authApi.put(`/user/${props.user?.id}/email/setPrimary/${email}`)
			.then(() => {
				setIsChangeSaving(false);
				props.handleUpdate();

				message.success('Successfully set primary email!');
			})
			.catch(() => {
				setIsChangeSaving(false);
				message.error('Could not set primary email. Please try again later. If this error persists, please submit a ticket.');
			})
	}

	return (
		<Card
			title={'Email Addresses'}
			extra={
				props.isEditable &&
				<Button icon={<PlusOutlined/>} type={'primary'} onClick={() => setIsNewEmailModalVisible(true)}>New</Button>
			}
		>
			<Table
				columns={[
					{title: 'Email Address', dataIndex: 'email'},
					{title: 'Primary', dataIndex: 'primaryFlag', render: (_, record: EmailEntry) => record.primaryFlag ? 'Yes' : 'No'},
					{title: 'Verified', dataIndex: 'verifiedFlag', render: (_, record: EmailEntry) => record.verifiedFlag ? 'Yes' : 'No'},
					... props.isEditable ? [{
						title: 'Actions',
						width: 100,
						render: (record: EmailEntry) => (
							<Space>
								<Popconfirm
									title={'Are you sure you want to make this the primary email?'}
									onConfirm={() => handleMakePrimary(record.email)}
									okText={'Yes'}
									disabled={record.primaryFlag || !record.verifiedFlag}
								>
									<Tooltip title={record.primaryFlag ? 'This is already the primary email' : !record.verifiedFlag ? 'Email must be verified to be the primary email' : 'Set as primary email'}>
										<Button icon={<HeartOutlined/>} type={'default'} disabled={record.primaryFlag || !record.verifiedFlag}/>
									</Tooltip>
								</Popconfirm>
								<Popconfirm
									title={'Are you sure you want to delete this email?'}
									onConfirm={() => handleRemove(record.email)}
									okText={'Yes'}
									disabled={record.primaryFlag}
								>
									<Tooltip title={record.primaryFlag ? 'You cannot remove the primary email' : 'Remove email from user'}>
										<Button icon={<DeleteOutlined/>} type={'dashed'} disabled={record.primaryFlag}/>
									</Tooltip>
								</Popconfirm>
							</Space>
						)
					}] : []
				]}
				rowKey={record => record.email}
				loading={props.isLoading || isChangeSaving}
				dataSource={props.user?.emails}
				pagination={false}
			/>

			<Modal
				title={'New Email'}
				visible={isNewEmailModalVisible}
				okText={'Add Email'}
				okButtonProps={{loading: isNewEmailSaving}}
				onOk={() => {
					form
						.validateFields()
						.then((values: any) => {
							handleAdd(values);
						})
						.catch(() => {});
				}}
				onCancel={() => {
					setIsNewEmailModalVisible(false);
					form.resetFields();
				}}
			>
				<Form
					form={form}
					layout={'vertical'}
					requiredMark={false}
					validateMessages={validateMessages}
				>
					<Form.Item
						name={'email'}
						label={'Email Address'}
						rules={[{required: true}]}
					>
						<Input/>
					</Form.Item>
					<Form.Item
						name={'primaryFlag'}
						label={'Make Primary?'}
						valuePropName={'checked'}
					>
						<Switch/>
					</Form.Item>
				</Form>
			</Modal>
		</Card>
	)
}

export default Emails;