export interface FieldOfStudy {
	id: string;
	name: string;
	abbreviation: string;
	type: string;
	availableDegrees: string[];
}