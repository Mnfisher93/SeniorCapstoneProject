export interface User {
	id: string;
	userId: string;
	lastName: string;
	firstName: string;
	username: string;
	password: string;
	classifications: string[];
	emails: EmailEntry[];
	phoneNumbers: PhoneNumberEntry[];
	roles: string[];
	permissions: string[];
	majors: string[];
	minors: string[];
	status: string;
}

export interface PhoneNumberEntry {
	countryCode: string;
	phoneNumber: string;
	primaryFlag: boolean;
	verifiedFlag: boolean;
	verificationCode: string;
}

export interface EmailEntry {
	email: string;
	primaryFlag: boolean;
	verifiedFlag: boolean;
	verificationCode: string;
}