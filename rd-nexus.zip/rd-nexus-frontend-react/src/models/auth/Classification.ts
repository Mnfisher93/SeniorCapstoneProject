export interface Classification {
	id: string;
	name: string
}