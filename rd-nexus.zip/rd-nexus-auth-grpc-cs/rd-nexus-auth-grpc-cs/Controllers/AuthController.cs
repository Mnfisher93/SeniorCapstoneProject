﻿using Grpc.Core;
using rd_nexus_auth_grpc_cs.Helpers;
using rd_nexus_auth_grpc_cs.Protos.auth;
using rd_nexus_auth_grpc_cs.Services.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_grpc_cs.GrpcServices
{
    public class AuthController : GrpcAuthService.GrpcAuthServiceBase
    {
        private readonly AuthenticationService _authenticationService;

        public AuthController(AuthenticationService authenticationService)
        {
            _authenticationService = authenticationService;
        }

        public async override Task<CheckAccessResponse> CheckAccess(CheckAccessRequest request, ServerCallContext context)
        {
            return new CheckAccessResponse
            {
                AccessGranted = await _authenticationService.CheckAccess(request.Token, request.PermissionKey)
            };
        }
    }
}
