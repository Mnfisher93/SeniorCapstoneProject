﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_grpc_cs.Models.Authentication
{
    public class User
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("userId")]
        public string UserId { get; set; }

        [BsonElement("lastName")]
        public string LastName { get; set; }

        [BsonElement("firstName")]
        public string FirstName { get; set; }

        [BsonElement("username")]
        public string Username { get; set; }

        [BsonElement("password")]
        public string Password { get; set; }

        [BsonElement("classifications")]
        [BsonRepresentation(BsonType.ObjectId)]
        public List<string> Classifications { get; set; }

        [BsonElement("emails")]
        public List<EmailEntry> Emails { get; set; }

        [BsonElement("phoneNumbers")]
        public List<PhoneNumberEntry> PhoneNumbers { get; set; }

        [BsonElement("roles")]
        [BsonRepresentation(BsonType.ObjectId)]
        public List<string> Roles { get; set; }

        [BsonElement("permissions")]
        [BsonRepresentation(BsonType.ObjectId)]
        public List<string> Permissions { get; set; }

        [BsonElement("majors")]
        [BsonRepresentation(BsonType.ObjectId)]
        public List<string> Majors { get; set; }

        [BsonElement("minors")]
        [BsonRepresentation(BsonType.ObjectId)]
        public List<string> Minors { get; set; }

        [BsonElement("status")]
        public string Status { get; set; }

        public User(string id, string userId, string lastName, string firstName, string username, string password, List<string> classifications, List<EmailEntry> emails, List<PhoneNumberEntry> phoneNumbers, List<string> roles, List<string> permissions, List<string> majors, List<string> minors, string status)
        {
            Id = id;
            UserId = userId;
            LastName = lastName;
            FirstName = firstName;
            Username = username;
            Password = password;
            Classifications = classifications;
            Emails = emails;
            PhoneNumbers = phoneNumbers;
            Roles = roles;
            Permissions = permissions;
            Majors = majors;
            Minors = minors;
            Status = status;
        }

        public static User FromCreate(UserCreate create)
        {
            return new User(
                null,
                create.UserId,
                create.LastName,
                create.FirstName,
                create.Username,
                create.Password,
                create.Classifications,
                new List<EmailEntry> { EmailEntry.FromCreate(create.Email) },
                new List<PhoneNumberEntry> { PhoneNumberEntry.FromCreate(create.PhoneNumber) },
                create.Roles,
                create.Permissions,
                create.Majors,
                create.Minors,
                create.Status
            );
        }

        public static User FromUpdate(User original, UserUpdate update)
        {
            return new User(
                original.Id,
                original.UserId,
                update.LastName,
                update.FirstName,
                update.Username,
                update.Password,
                update.Classifications,
                original.Emails,
                original.PhoneNumbers,
                update.Roles,
                update.Permissions,
                update.Majors,
                update.Minors,
                update.Status
            );
        }
    }

    public class UserCreate
    {
        public string UserId { get; set; }

        public string LastName { get; set; }

        public string FirstName { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }

        public List<string> Classifications { get; set; }

        public EmailEntryCreate Email { get; set; }

        public PhoneNumberEntryCreate PhoneNumber { get; set; }

        public List<string> Roles { get; set; }

        public List<string> Permissions { get; set; }

        public List<string> Majors { get; set; }

        public List<string> Minors { get; set; }

        public string Status { get; set; }
    }

    public class UserUpdate
    {
        public string LastName { get; set; }

        public string FirstName { get; set; }

        public string Username { get; set; }

        public string Password { get; set; }

        public List<string> Classifications { get; set; }

        public List<string> Roles { get; set; }

        public List<string> Permissions { get; set; }

        public List<string> Majors { get; set; }

        public List<string> Minors { get; set; }

        public string Status { get; set; }
    }
}
