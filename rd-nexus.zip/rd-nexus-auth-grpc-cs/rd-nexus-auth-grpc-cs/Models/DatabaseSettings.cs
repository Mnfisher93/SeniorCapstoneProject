﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_grpc_cs.Models
{
    public class DatabaseSettings : IDatabaseSettings
    {
        public string UsersCollectionName { get; set; }
        public string PermissionsCollectionName { get; set; }
        public string RolesCollectionName { get; set; }
        public string DatabaseName { get; set; }
    }

    public interface IDatabaseSettings
    {
        string UsersCollectionName { get; set; }
        string PermissionsCollectionName { get; set; }
        string RolesCollectionName { get; set; }
        string DatabaseName { get; set; }
    }
}
