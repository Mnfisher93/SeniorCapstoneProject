﻿using System;
namespace rd_nexus_course_cs.Helpers.Courses
{
    public class CourseHelpers
    {
        
    }
}
