using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_course_cs.Models.Courses
{
    public class ClassLocation
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("campus")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Campus { get; set; }

        [BsonElement("buildingName")]
        public string BuildingName { get; set; }

        [BsonElement("buildingCode")]
        public string BuildingCode { get; set; }

        [BsonElement("room")]
        public string Room { get; set; }

        public ClassLocation(string id, string campus, string buildingName, string buildingCode, string room)
        {
            Id = id;
            Campus = campus;
            BuildingName = buildingName;
            BuildingCode = buildingCode;
            Room = room;
        }

        public static ClassLocation FromCreate(ClassLocationCreate create)
        {
            return new ClassLocation(
                null,
                create.Campus,
                create.BuildingName,
                create.BuildingCode,
                create.Room
            ); 
        }

        public static ClassLocation FromUpdate(string id , ClassLocationUpdate update)
        {
            return new ClassLocation(
                id,
                update.Campus,
                update.BuildingName,
                update.BuildingCode,
                update.Room
            );
        }
    }

    public class ClassLocationCreate
    {
        public string Campus { get; set; }
        public string BuildingName { get; set; }
        public string BuildingCode { get; set; }
        public string Room { get; set; }
    }

    public class ClassLocationUpdate
    {
        public string Campus { get; set; }
        public string BuildingName { get; set; }
        public string BuildingCode { get; set; }
        public string Room { get; set; }
    }
}