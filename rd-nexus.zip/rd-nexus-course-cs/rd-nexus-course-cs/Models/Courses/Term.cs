using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_course_cs.Models.Courses
{
    public class Term
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("semester")]
        public string Semester { get; set; }

        [BsonElement("year")]
        public int Year { get; set; }

        [BsonElement("start")]
        public DateTime Start { get; set; }

        [BsonElement("end")]
        public DateTime End { get; set; }

        public Term(string id, string semester, int year, DateTime start, DateTime end)
        {
            Id = id;
            Semester = semester;
            Year = year;
            Start = start;
            End = end;
        }

        public static Term FromCreate(TermCreate create)
        {
            return new Term(
                null,
                create.Semester,
                create.Year,
                create.Start,
                create.End
             );
        }

        public static Term FromUpdate(string id, TermUpdate update)
        {
            return new Term(
                id,
                update.Semester,
                update.Year,
                update.Start,
                update.End
            );
        }
    }

    public class TermCreate
    {
        public string Semester { get; set; }
        public int Year { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
    }

    public class TermUpdate
    {
        public string Semester { get; set; }
        public int Year { get; set; }
        public DateTime Start { get; set; }
        public DateTime End { get; set; }
    }
}