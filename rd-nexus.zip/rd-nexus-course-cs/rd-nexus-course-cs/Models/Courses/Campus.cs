using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_course_cs.Models.Courses
{
    public class Campus
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("campusName")]
        public string CampusName { get; set; }

        [BsonElement("streetAddress")]
        public string StreetAddress { get; set; }

        [BsonElement("city")]
        public string City { get; set; }

        [BsonElement("state")]
        public string State { get; set; }

        [BsonElement("zip")]
        public string Zip { get; set; }

        [BsonElement("country")]
        public string Country { get; set; }

        public Campus(string id, string campusName, string streetAddress, string city, string state, string zip, string country)
        {
            Id = id;
            CampusName = campusName;
            StreetAddress = streetAddress;
            City = city;
            State = state;
            Zip = zip;
            Country = country;
        }

        public static Campus FromCreate(CampusCreate create)
        {
            return new Campus(
                null,
                create.CampusName,
                create.StreetAddress,
                create.City,
                create.State,
                create.Zip,
                create.Country
            );
        }

        public static Campus FromUpdate(string id, CampusUpdate update)
        {
            return new Campus(
                id,
                update.CampusName,
                update.StreetAddress,
                update.City,
                update.State,
                update.Zip,
                update.Country
            );
        }
    }

    public class CampusCreate
    {
        public string CampusName { get; set; }
        public string StreetAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Country { get; set; }
    }

    public class CampusUpdate
    {
        public string CampusName { get; set; }
        public string StreetAddress { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zip { get; set; }
        public string Country { get; set; }
    }
}