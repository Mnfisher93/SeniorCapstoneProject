using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_course_cs.Models.Courses
{
	public class Course
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("department")]
        public string Department { get; set; }

        [BsonElement("subject")]
        public string Subject { get; set; }

        [BsonElement("courseNum")]
        public int CourseNum { get; set; }

        [BsonElement("name")]
        public string Name { get; set; }

        [BsonElement("hours")]
        public int Hours { get; set; }

        [BsonElement("courseType")]
        public string CourseType { get; set; }

        [BsonElement("preRequisites")]
        [BsonRepresentation(BsonType.ObjectId)]
        public List<string> PreRequisites { get; set; }

        [BsonElement("coRequisites")]
        [BsonRepresentation(BsonType.ObjectId)]
        public List<string> CoRequisites { get; set; }

        public Course(string id, string department, string subject, int courseNum, string name, int hours, string courseType, List<string> preRequisites, List<string> coRequisites)
        {
            Id = id;
            Department = department;
            Subject = subject;
            CourseNum = courseNum;
            Name = name;
            Hours = hours;
            CourseType = courseType;
            PreRequisites = preRequisites;
            CoRequisites = coRequisites;
        }

        public static Course FromCreate(CourseCreate create)
        {
            return new Course(
                null,
                create.Department,
                create.Subject,
                create.CourseNum,
                create.Name,
                create.Hours,
                create.CourseType,
                create.PreRequisites,
                create.CoRequisites
             );
        }

        public static Course FromUpdate(string id, CourseUpdate update)
        {
            return new Course(
                id,
                update.Department,
                update.Subject,
                update.CourseNum,
                update.Name,
                update.Hours,
                update.CourseType,
                update.PreRequisites,
                update.CoRequisites
            );
        }
    }

    public class CourseCreate
    {
        public string Department { get; set; }
        public string Subject { get; set; }
        public int CourseNum { get; set; }
        public string Name { get; set; }
        public int Hours { get; set; }
        public string CourseType { get; set; }
        public List<string> PreRequisites { get; set; }
        public List<string> CoRequisites { get; set; }
    }

    public class CourseUpdate
    {
        public string Department { get; set; }
        public string Subject { get; set; }
        public int CourseNum { get; set; }
        public string Name { get; set; }
        public int Hours { get; set; }
        public string CourseType { get; set; }
        public List<string> PreRequisites { get; set; }
        public List<string> CoRequisites { get; set; }
    }
}