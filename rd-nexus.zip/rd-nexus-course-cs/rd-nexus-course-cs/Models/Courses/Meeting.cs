using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_course_cs.Models.Courses
{
    public class Meeting
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("crn")]
        public string Crn { get; set; }

        [BsonElement("course")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Course { get; set; }

        [BsonElement("sectionNum")]
        public string SectionNum { get; set; }

        [BsonElement("gradeMode")]
        public string GradeMode { get; set; }
        
        [BsonElement("campus")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Campus { get; set; }

        [BsonElement("method")]
        public string Method { get; set; }

        [BsonElement("term")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Term { get; set; }

        [BsonElement("instructor")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Instructor { get; set; }

        [BsonElement("teachingAssistant")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string TeachingAssistant { get; set; }

        [BsonElement("times")]
        public List<TimeEntry> Times { get; set; }

        [BsonElement("location")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Location { get; set; }

        [BsonElement("alternateLocation")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string AlternateLocation { get; set; }

        [BsonElement("seatsAvailable")]
        public int SeatsAvailable { get; set; }

        [BsonElement("waitList")]
        public int WaitList { get; set; }

        public Meeting(string id, string crn, string sectionNum, string course,string gradeMode, string campus, string method, string term, string instructor, string teachingAssistant, 
            List<TimeEntry> times, string location, string alternateLocation, int seatsAvailable, int waitList)
        {
            Id = id;
            Crn = crn;
            Course = course;
            SectionNum = sectionNum;
            GradeMode = gradeMode;
            Campus = campus;
            Method = method;
            Term = term;
            Instructor = instructor;
            TeachingAssistant = teachingAssistant;
            Times = times;
            Location = location;
            AlternateLocation = alternateLocation;
            SeatsAvailable = seatsAvailable;
            WaitList = waitList;
        }

        public static Meeting FromCreate(MeetingCreate create)
        {
            return new Meeting(
                null,
                create.Crn,
                create.SectionNum,
                create.Course,
                create.GradeMode,
                create.Campus,
                create.Method,
                create.Term,
                create.Instructor,
                create.TeachingAssistant,
                create.Times,
                create.Location,
                create.AlternateLocation,
                create.SeatsAvailable,
                create.WaitList
            );
        }

        public static Meeting FromUpdate(string id, MeetingUpdate update)
        {
            return new Meeting(
                id,
                update.Crn,
                update.SectionNum,
                update.Course,
                update.GradeMode,
                update.Campus,
                update.Method,
                update.Term,
                update.Instructor,
                update.TeachingAssistant,
                update.Times,
                update.Location,
                update.AlternateLocation,
                update.SeatsAvailable,
                update.WaitList
            );
        }
    }

    public class MeetingCreate
    {
        public string Crn { get; set; }
        public string SectionNum { get; set; }
        public string Course { get; set; }
        public string GradeMode { get; set; }
        public string Campus { get; set; }
        public string Method { get; set; }
        public string Term { get; set; }
        public string Instructor { get; set; }
        public string TeachingAssistant { get; set; }
        public List<TimeEntry> Times { get; set; }
        public string Location { get; set; }
        public string AlternateLocation { get; set; }
        public int SeatsAvailable { get; set; }
        public int WaitList { get; set; }
    }

    public class MeetingUpdate
    {
        public string Crn { get; set; }
        public string SectionNum { get; set; }
        public string Course { get; set; }
        public string GradeMode { get; set; }
        public string Campus { get; set; }
        public string Method { get; set; }
        public string Term { get; set; }
        public string Instructor { get; set; }
        public string TeachingAssistant { get; set; }
        public List<TimeEntry> Times { get; set; }
        public string Location { get; set; }
        public string AlternateLocation { get; set; }
        public int SeatsAvailable { get; set; }
        public int WaitList { get; set; }
    }        
}