﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_course_cs.Models
{
    public class DatabaseSettings : IDatabaseSettings
    {
        public string CampusCollectionName { get; set; }
        public string CoursesCollectionName { get; set; }
        public string MeetingCollectionName { get; set; }
        public string ClassLocationCollectionName { get; set; }
        public string TermCollectionName { get; set; }
        public string LoginLogsCollectionName { get; set; }
        public string CourseChangelogCollectionName { get; set; }
        public string LogsCollectionName { get; set; }
        public string DatabaseName { get; set; }
    }

    public interface IDatabaseSettings
    {
        string CampusCollectionName { get; set; }
        string CoursesCollectionName { get; set; }
        string MeetingCollectionName { get; set; }
        string ClassLocationCollectionName { get; set; }
        string TermCollectionName { get; set; }
        string LoginLogsCollectionName { get; set; }
        string CourseChangelogCollectionName { get; set; }
        string LogsCollectionName { get; set; }
        string DatabaseName { get; set; }
    }
}
