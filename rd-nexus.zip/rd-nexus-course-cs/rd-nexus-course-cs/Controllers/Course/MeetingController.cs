﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using rd_nexus_course_cs.Models.Courses;
using rd_nexus_course_cs.Services.Courses;
using Microsoft.AspNetCore.Hosting;
using rd_nexus_course_cs.Helpers.Authorization;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace rd_nexus_course_cs.Controllers.Courses
{
    [Route("api/[controller]")]
    [ApiController]
    public class MeetingController : ControllerBase
    {
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly MeetingService _meetingService;

        public MeetingController(IWebHostEnvironment hostEnvironment, MeetingService meetingService)
        {
            _hostEnvironment = hostEnvironment;
            _meetingService = meetingService;
        }

        [HttpGet]
        public async Task<ActionResult<List<Meeting>>> Get([FromHeader] string authToken)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "courseMtgView"))
            {
                return Unauthorized();
            }

            return await _meetingService.Get();
        }


        [HttpGet("{id:length(24)}")]
        public async Task<ActionResult<Meeting>> Get([FromHeader] string authToken, string id)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "courseMtgView"))
            {
                return Unauthorized();
            }

            var meeting = await _meetingService.Get(id);

            if(meeting == null)
            {
                return NotFound();
            }
            return meeting;
        }

        [HttpPost]
        public async Task<ActionResult<Meeting>> Create([FromHeader]string authToken, MeetingCreate create)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "courseMtgMgr"))
            {
                return Unauthorized();
            }

            Meeting created = await _meetingService.Create(create);

            return Ok(create);
        }

        [HttpPut("{id:length(24)}")]
        public async Task<IActionResult> Update([FromHeader] string authToken, string id, MeetingUpdate update)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "courseMtgMgr"))
            {
                return Unauthorized();
            }

            var meeting = await _meetingService.Get(id);

            if(meeting == null)
            {
                return NotFound();
            }

            _meetingService.Update(id, update);

            return Ok();
        }

    }
}
