﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using rd_nexus_course_cs.Models.Courses;
using rd_nexus_course_cs.Services.Courses;
using Microsoft.AspNetCore.Hosting;
using rd_nexus_course_cs.Helpers.Authorization;

namespace rd_nexus_course_cs.Controllers.Courses
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClassLocationController : ControllerBase
    {
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly ClassLocationService _classLocationService;

        public ClassLocationController(IWebHostEnvironment hostEnvironment, ClassLocationService classLocationService)
        {
            _hostEnvironment = hostEnvironment;
            _classLocationService = classLocationService;
        }

        [HttpGet]
        public async Task<ActionResult<List<ClassLocation>>> Get([FromHeader] string authToken)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "classLocView"))
            {
                return Unauthorized();
            }

            return await _classLocationService.Get();
        }

        [HttpGet("{id:length(24)}")]
        public async Task<ActionResult<ClassLocation>> Get([FromHeader] string authToken, string id)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "classLocView"))
            {
                return Unauthorized();
            }

            var classLocation = await _classLocationService.Get(id);

            if (classLocation == null)
            {
                return NotFound();
            }
            return classLocation;
        }

        [HttpPost]
        public async Task<ActionResult<ClassLocation>> Create([FromHeader] string authToken, ClassLocationCreate create)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "classLocMgr"))
            {
                return Unauthorized();
            }

            ClassLocation created = await _classLocationService.Create(create);

            return Ok(create);
        }

        [HttpPut("{id:length(24)}")]
        public async Task<IActionResult> Update([FromHeader] string authToken, string id, ClassLocationUpdate update)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "classLocMgr"))
            {
                return Unauthorized();
            }

            var classLocation = await _classLocationService.Get(id);
            if (classLocation == null)
            {
                return NotFound();
            }
            _classLocationService.Update(id, update);

            return Ok();
        }

    }
}
