﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using rd_nexus_course_cs.Models.Courses;
using rd_nexus_course_cs.Services.Courses;
using Microsoft.AspNetCore.Hosting;
using rd_nexus_course_cs.Helpers.Authorization;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace rd_nexus_course_cs.Controllers.Courses
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly CourseService _courseService;

        public CourseController(IWebHostEnvironment hostEnvironment, CourseService courseService)
        {
            _hostEnvironment = hostEnvironment;
            _courseService = courseService;
        }

        [HttpGet]
        public async Task<ActionResult<List<Course>>> Get([FromHeader] string authToken)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "courseView"))
            {
                return Unauthorized();
            }

            return await _courseService.Get();
        }

        [HttpGet("{id:length(24)}")]
        public async Task<ActionResult<Course>> Get([FromHeader] string authToken, string id)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "courseView"))
            {
                return Unauthorized();
            }

            var course = await _courseService.Get(id);

            if(course == null)
            {
                return NotFound();
            }
            return course;
        }

        [HttpPost]
        public async Task<ActionResult<Course>> Create([FromHeader] string authToken, CourseCreate create)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "courseMgr"))
            {
                return Unauthorized();
            }

            Course created = await _courseService.Create(create);
            return Ok(create);

        }

        [HttpPut("{id:length(24)}")]
        public async Task<IActionResult> Update([FromHeader] string authToken, string id, CourseUpdate update)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "courseMgr"))
            {
                return Unauthorized();
            }

            var course = await _courseService.Get(id);
            _courseService.Update(id, update);

            return Ok();
        }


    }
}
