﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using rd_nexus_course_cs.DataTransfer;
using rd_nexus_course_cs.Models.Courses;
using rd_nexus_course_cs.Services.Courses;
using Microsoft.AspNetCore.Hosting;
using rd_nexus_course_cs.Helpers.Authorization;

namespace rd_nexus_course_cs.Controllers.Courses
{
    [Route("api/[controller]")]
    [ApiController]
    public class CampusController : ControllerBase
    {
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly CampusService _campusService;

        public CampusController(IWebHostEnvironment hostEnvironment, CampusService campusService)
        {
            _hostEnvironment = hostEnvironment;
            _campusService = campusService;
        }

        [HttpGet]
        public async Task<ActionResult<List<Campus>>> Get([FromHeader] string authToken)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "campusView"))
            {
                return Unauthorized();
            }

            return await _campusService.Get();
        }

        [HttpGet("{id:length(24)}")]
        public async Task<ActionResult<Campus>> Get([FromHeader] string authToken, string id)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "campusView"))
            {
                return Unauthorized();
            }

            var campus = await _campusService.Get(id);
            if (campus == null)
            {
                return NotFound();
            }
            return campus;
        }

        [HttpPost]
        public async Task<ActionResult<Campus>> Create([FromHeader] string authToken, CampusCreate create)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "campusMgr"))
            {
                return Unauthorized();
            }

            Campus created = await _campusService.Create(create);

            return Ok(create);

        }

        [HttpPut("{id:length(24)}")]
        public async Task<ActionResult<Campus>> Update([FromHeader] string authToken, string id, CampusUpdate update)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "campusMgr"))
            {
                return Unauthorized();
            }

            var campus = await _campusService.Get(id);

            if (campus == null)
            {
                return NotFound();
            }

            _campusService.Update(id, update);

            return Ok();
        }
    }
}
