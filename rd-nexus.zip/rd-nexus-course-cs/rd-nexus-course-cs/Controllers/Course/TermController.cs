﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;

using rd_nexus_course_cs.Models.Courses;
using rd_nexus_course_cs.Services.Courses;
using Microsoft.AspNetCore.Hosting;
using rd_nexus_course_cs.Helpers.Authorization;

namespace rd_nexus_course_cs.Controllers.Courses
{
    [Route("api/[controller]")]
    [ApiController]
    public class TermController : ControllerBase
    {
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly TermService _termService;

        public TermController(IWebHostEnvironment hostEnvironment, TermService termService)
        {
            _hostEnvironment = hostEnvironment;
            _termService = termService;
        }

        [HttpGet]
        public async Task<ActionResult<List<Term>>> Get([FromHeader] string authToken)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "termView"))
            {
                return Unauthorized();
            }

            return await _termService.Get();
        }

        [HttpGet("{id:length(24)}")]
        public async Task<ActionResult<Term>> Get([FromHeader] string authToken, string id)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "termView"))
            {
                return Unauthorized();
            }

            var term = await _termService.Get(id);
            if(term == null)
            {
                return NotFound();
            }

            return term;
        }

        [HttpPost]
        public async Task<ActionResult<Term>> Create([FromHeader] string authToken, TermCreate create)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "termMgr"))
            {
                return Unauthorized();
            }

            Term created = await _termService.Create(create);

            return Ok(create);
        }

        [HttpPut("{id:length(24)}")]
        public async Task<IActionResult> Update([FromHeader] string authToken, string id, TermUpdate update)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "termMgr"))
            {
                return Unauthorized();
            }

            var term = await _termService.Get(id);
            if(term == null)
            {
                return NotFound();
            }

            _termService.Update(id, update);

            return Ok();
        }
    }
}
