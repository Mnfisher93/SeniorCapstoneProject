﻿
using System;
using rd_nexus_course_cs.Models;
using rd_nexus_course_cs.Models.Courses;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using rd_nexus_course_cs.Helpers;

namespace rd_nexus_course_cs.Services.Courses
{
    public class MeetingService
    {
        private readonly IMongoCollection<Meeting> _meeting;

        public MeetingService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _meeting = database.GetCollection<Meeting>(settings.MeetingCollectionName);
        }

        public async Task<List<Meeting>> Get() => await _meeting.Find(meeting => true).ToListAsync();

        public async Task<Meeting> Get(string id) => await _meeting.Find<Meeting>(meeting => meeting.Id == id).FirstOrDefaultAsync();

        public async Task<Meeting> Create(MeetingCreate create)
        {
            var meeting = Meeting.FromCreate(create);
            await _meeting.InsertOneAsync(meeting);
            return meeting;
        }

        //public async void Update(Meeting original, MeetingUpdate update)
        //{
        //    await _meeting.ReplaceOneAsync(meeting => meeting.Id == original.Id, Meeting.FromUpdate(original, update));

        //}

        public async void Update(string id, MeetingUpdate update) =>
            await _meeting.ReplaceOneAsync(meeting => meeting.Id == id, Meeting.FromUpdate(id, update));
    }
}
