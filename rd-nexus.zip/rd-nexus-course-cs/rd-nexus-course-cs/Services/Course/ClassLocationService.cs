﻿
using System;
using rd_nexus_course_cs.Models;
using rd_nexus_course_cs.Models.Courses;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using rd_nexus_course_cs.Helpers;

namespace rd_nexus_course_cs.Services.Courses
{
    public class ClassLocationService
    {
        private readonly IMongoCollection<ClassLocation> _classLocation;

        public ClassLocationService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _classLocation = database.GetCollection<ClassLocation>(settings.ClassLocationCollectionName);
        }

        public async Task<List<ClassLocation>> Get() => await _classLocation.Find(classLocation => true).ToListAsync();
        
        public async Task<ClassLocation> Get(string id) => await _classLocation.Find<ClassLocation>(classLocation => classLocation.Id == id).FirstOrDefaultAsync();

        public async Task<ClassLocation> Create(ClassLocationCreate create)
        {
            var classLocation = ClassLocation.FromCreate(create);
            await _classLocation.InsertOneAsync(classLocation);
            return classLocation;
        }

        //public async void Update(ClassLocation original, ClassLocationUpdate update)
        //{
        //    await _classLocation.ReplaceOneAsync(classLocation => classLocation.Id == original.Id, ClassLocation.FromUpdate(original, update));

        //}

        public async void Update(string id, ClassLocationUpdate update) =>
            await _classLocation.ReplaceOneAsync(classLocation => classLocation.Id == id, ClassLocation.FromUpdate(id, update));
    }
}
