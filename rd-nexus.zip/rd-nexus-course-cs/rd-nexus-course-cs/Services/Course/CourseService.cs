﻿
using System;
using rd_nexus_course_cs.Models;
using rd_nexus_course_cs.Models.Courses;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using rd_nexus_course_cs.Helpers;

namespace rd_nexus_course_cs.Services.Courses
{
    public class CourseService
    {
        private readonly IMongoCollection<Course> _course;

        public CourseService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _course = database.GetCollection<Course>(settings.CoursesCollectionName);
        }

        public async Task<List<Course>> Get() => await _course.Find(course => true).ToListAsync();

        public async Task<Course> Get(string id) => await _course.Find<Course>(course => course.Id == id).FirstOrDefaultAsync();

        public async Task<Course> Create(CourseCreate create)
        {
            var course = Course.FromCreate(create);
            await _course.InsertOneAsync(course);
            return course;
        }

        public async void Update(string id, CourseUpdate update) =>
            await _course.ReplaceOneAsync(course => course.Id == id, Course.FromUpdate(id, update));
    }
}
