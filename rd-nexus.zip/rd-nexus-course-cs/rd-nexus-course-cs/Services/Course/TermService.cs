﻿
using System;
using rd_nexus_course_cs.Models;
using rd_nexus_course_cs.Models.Courses;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using rd_nexus_course_cs.Helpers;

namespace rd_nexus_course_cs.Services.Courses
{
    public class TermService
    {
        private readonly IMongoCollection<Term> _term;

        public TermService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _term = database.GetCollection<Term>(settings.TermCollectionName);
        }

        public async Task<List<Term>> Get() => await _term.Find(term => true).ToListAsync();

        public async Task<Term> Get(string id) => await _term.Find<Term>(term => term.Id == id).FirstOrDefaultAsync();

        public async Task<Term> Create(TermCreate create)
        {
            var term = Term.FromCreate(create);
            await _term.InsertOneAsync(term);
            return term;
        }

        //public async void Update(Term original, TermUpdate update)
        //{
        //    await _term.ReplaceOneAsync(term => term.Id == original.Id, Term.FromUpdate(original, update));

        //}

        public async void Update(string id, TermUpdate update) =>
            await _term.ReplaceOneAsync(term => term.Id == id, Term.FromUpdate(id, update));
    }
}
