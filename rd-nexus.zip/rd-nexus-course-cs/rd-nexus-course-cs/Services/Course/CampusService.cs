﻿using System;
using rd_nexus_course_cs.Models;
using rd_nexus_course_cs.Models.Courses;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using rd_nexus_course_cs.Helpers;

namespace rd_nexus_course_cs.Services.Courses
{
    public class CampusService
    {
        private readonly IMongoCollection<Campus> _campus;

        public CampusService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _campus = database.GetCollection<Campus>(settings.CampusCollectionName);
        }

        public async Task<List<Campus>> Get() => await _campus.Find(campus => true).ToListAsync();

        public async Task<Campus> Get(string id) => await _campus.Find<Campus>(campus => campus.Id == id).FirstOrDefaultAsync();

        public async Task<Campus> Create(CampusCreate create)
        {
            var user = Campus.FromCreate(create);
            await _campus.InsertOneAsync(user);
            return user;
        }

        public async void Update(string id, CampusUpdate update) =>
            await _campus.ReplaceOneAsync(campus => campus.Id == id, Campus.FromUpdate(id, update));
    }
}
