﻿using rd_nexus_course_cs.Models;
using rd_nexus_course_cs.Models.Logging;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using rd_nexus_course_cs.Helpers;

namespace rd_nexus_course_cs.Services.Logging
{
    public class LogService
    {
        private readonly IMongoCollection<Log> _logs;

        public LogService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _logs = database.GetCollection<Log>(settings.LogsCollectionName);
        }

        public async Task<List<Log>> Get() =>
            await _logs.Find(log => true).ToListAsync();

        public async Task<Log> Get(string id) =>
            await _logs.Find<Log>(log => log.Id == id).FirstOrDefaultAsync();

        public async Task<Log> Create(Log logIn)
        {
            await _logs.InsertOneAsync(logIn);
            return logIn;
        }
    }
}
