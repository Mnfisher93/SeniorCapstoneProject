﻿using rd_nexus_registration_cs.DataTransfer;
using rd_nexus_registration_cs.Models.Registration;
using rd_nexus_registration_cs.Models.Logging;
using rd_nexus_registration_cs.Services.Registration;
using rd_nexus_registration_cs.Services.Logging;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using rd_nexus_registration_cs.Helpers.Authorization;

namespace rd_nexus_registration_cs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationClassesController : ControllerBase
    {
        private readonly IWebHostEnvironment _hostEnvironment;
        private readonly LogService _logService;
        private readonly RegistrationClassesService _registrationClassesService;

        public RegistrationClassesController(IWebHostEnvironment hostEnvironment, LogService logService, RegistrationClassesService registrationClassesService)
        {
            _hostEnvironment = hostEnvironment;

            _logService = logService;
            _registrationClassesService = registrationClassesService;
        }

        [HttpGet("{userId:length(24)}")]
        public async Task<ActionResult<List<RegistrationClasses>>> Get([FromHeader] string authToken, string userId)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "regView"))
            {
                return Unauthorized();
            }

            var registrationClasses = await _registrationClassesService.Get(userId);

            if (registrationClasses == null)
            {
                return NotFound();
            }

            return registrationClasses;
        }

        [HttpDelete("{userId:length(24)}/{meetingId:length(24)}")]
        public async Task<ActionResult<RegistrationClasses>> Delete([FromHeader] string authToken, string userId,string meetingId)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "regView"))
            {
                return Unauthorized();
            }

             _registrationClassesService.Delete(userId, meetingId);


            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult<RegistrationClasses>> Create([FromHeader] string authToken, RegistrationClassesCreate create)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "regMgr"))
            {
                return Unauthorized();
            }

            RegistrationClasses created = await _registrationClassesService.Create(create);

            await _logService.Create(new Log(
                null,
                null,
                DateTime.UtcNow,
                "Document created.",
                "registration.classes",
                created.Id,
                JsonSerializer.Serialize(created)
            ));

            return Ok(create);
        }

        [HttpPut("{userId:length(24)}/{meetingId:length(24)}")]
        public async Task<IActionResult> Update([FromHeader] string authToken, string userId, string meetingId, [FromBody] RegistrationClassesUpdate update)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "regMgr"))
            {
                return Unauthorized();
            }

            var registrationClasses = await _registrationClassesService.GetByMeetingAndUser(userId, meetingId);

            if (registrationClasses == null)
            {
                return NotFound("fuck you");
            }

            _registrationClassesService.Update(registrationClasses, update);

            await _logService.Create(new Log(
                null,
                null,
                DateTime.UtcNow,
                "Document created.",
                "registration.classes",
                userId,
                JsonSerializer.Serialize(RegistrationClasses.FromUpdate(registrationClasses, update))
            ));

            return Ok();
        }

    }
}
