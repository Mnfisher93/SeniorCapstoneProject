﻿using rd_nexus_registration_cs.DataTransfer;
using rd_nexus_registration_cs.Models.Registration;
using rd_nexus_registration_cs.Models.Logging;
using rd_nexus_registration_cs.Services.Registration;
using rd_nexus_registration_cs.Services.Logging;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using rd_nexus_registration_cs.Helpers.Authorization;

namespace rd_nexus_registration_cs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationCoursesController : ControllerBase
    {
        private readonly IWebHostEnvironment _hostEnvironment;

        private readonly LogService _logService;
        private readonly RegistrationCoursesService _registrationCoursesService;

        public RegistrationCoursesController(IWebHostEnvironment hostEnvironment, LogService logService, RegistrationCoursesService registrationCoursesService)
        {
            _hostEnvironment = hostEnvironment;

            _logService = logService;
            _registrationCoursesService = registrationCoursesService;
        }

        [HttpGet]
        public async Task<ActionResult<List<RegistrationCourses>>> Get([FromHeader] string authToken)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "regView"))
            {
                return Unauthorized();
            }

            return await _registrationCoursesService.Get();
        }

        [HttpGet("{id:length(24)}")]
        public async Task<ActionResult<RegistrationCourses>> Get([FromHeader] string authToken, string id)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "regView"))
            {
                return Unauthorized();
            }

            var registrationCourses = await _registrationCoursesService.Get(id);

            if (registrationCourses == null)
            {
                return NotFound();
            }

            return registrationCourses;
        }

        [HttpPost]
        public async Task<ActionResult<RegistrationCourses>> Create([FromHeader] string authToken, RegistrationCoursesCreate create)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "regMgr"))
            {
                return Unauthorized();
            }

            RegistrationCourses created = await _registrationCoursesService.Create(create);

            await _logService.Create(new Log(
                null,
                null,
                DateTime.UtcNow,
                "Document created.",
                "registration.classes",
                created.Id,
                JsonSerializer.Serialize(created)
            ));

            return Ok(create);
        }

        [HttpPut("{id:length(24)}")]
        public async Task<IActionResult> Update([FromHeader] string authToken, string id, RegistrationCoursesUpdate update)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "regMgr"))
            {
                return Unauthorized();
            }

            var registrationCourses = await _registrationCoursesService.Get(id);

            if (registrationCourses == null)
            {
                return NotFound();
            }

            _registrationCoursesService.Update(registrationCourses, update);

            await _logService.Create(new Log(
                null,
                null,
                DateTime.UtcNow,
                "Document created.",
                "registration.courses",
                id,
                JsonSerializer.Serialize(RegistrationCourses.FromUpdate(registrationCourses, update))
            ));

            return Ok();
        }
    } 
}
