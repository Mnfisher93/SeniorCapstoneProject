﻿using rd_nexus_registration_cs.DataTransfer;
using rd_nexus_registration_cs.Models.Registration;
using rd_nexus_registration_cs.Models.Logging;
using rd_nexus_registration_cs.Services.Registration;
using rd_nexus_registration_cs.Services.Logging;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using rd_nexus_registration_cs.Helpers.Authorization;

namespace rd_nexus_registration_cs.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RegistrationDatesController : ControllerBase
    {
        private readonly IWebHostEnvironment _hostEnvironment;

        private readonly LogService _logService;
        private readonly RegistrationDatesService _registrationDatesService;

        public RegistrationDatesController(IWebHostEnvironment hostEnvironment, LogService logService, RegistrationDatesService registrationDatesService)
        {
            _hostEnvironment = hostEnvironment;

            _logService = logService;
            _registrationDatesService = registrationDatesService;
        }

        [HttpGet]
        public async Task<ActionResult<List<RegistrationDates>>> Get([FromHeader] string authToken)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "regDateView"))
            {
                return Unauthorized();
            }

            return await _registrationDatesService.Get();
        }

        [HttpGet("{id:length(24)}")]
        public async Task<ActionResult<RegistrationDates>> Get([FromHeader] string authToken, string id)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "regDateView"))
            {
                return Unauthorized();

            }
            var registrationDates = await _registrationDatesService.Get(id);

            if (registrationDates == null)
            {
                return NotFound();
            }

            return registrationDates;
        }

        [HttpPost]
        public async Task<ActionResult<RegistrationDates>> Create([FromHeader] string authToken, RegistrationDatesCreate create)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "regDateMgr"))
            {
                return Unauthorized();
            }

            RegistrationDates created = await _registrationDatesService.Create(create);

            await _logService.Create(new Log(
                null,
                null,
                DateTime.UtcNow,
                "Document created.",
                "registration.courses",
                created.Id,
                JsonSerializer.Serialize(created)
            ));

            return Ok(create);
        }

        [HttpPut("{id:length(24)}")]
        public async Task<IActionResult> Update([FromHeader] string authToken, string id, RegistrationDatesUpdate update)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "regDateMgr"))
            {
                return Unauthorized();
            }

            var registrationDates = await _registrationDatesService.Get(id);

            if (registrationDates == null)
            {
                return NotFound();
            }

            _registrationDatesService.Update(registrationDates, update);

            await _logService.Create(new Log(
                null,
                null,
                DateTime.UtcNow,
                "Document created.",
                "registration.courses",
                id,
                JsonSerializer.Serialize(RegistrationDates.FromUpdate(registrationDates, update))
            ));

            return Ok();
        }
    }
}
