﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_registration_cs.Models.Registration
{
    public class TimeEntry
    {
        [BsonElement("day")]
        public string Day { get; set; }

        [BsonElement("start")]
        public int Start { get; set; }

        [BsonElement("end")]
        public int End { get; set; }

        public TimeEntry(string day, int start, int end)
        {
            Day = day;
            Start = start;
            End = end;
        }

        public static TimeEntry FromCreate(TimeEntryCreate create)
        {
            return new TimeEntry(
                create.Day,
                create.Start,
                create.End
            );
        }

        public static TimeEntry FromUpdate(TimeEntryUpdate update)
        {
            return new TimeEntry(
                update.Day,
                update.Start,
                update.End
            );
        }
    }

    public class TimeEntryCreate
    {
        public string Day { get; set; }
        public int Start { get; set; }
        public int End { get; set; }
    }

    public class TimeEntryUpdate
    {
        public string Day { get; set; }
        public int Start { get; set; }
        public int End { get; set; }
    }
}