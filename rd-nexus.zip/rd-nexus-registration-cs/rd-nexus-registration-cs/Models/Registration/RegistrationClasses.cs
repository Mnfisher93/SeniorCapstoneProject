﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Bson.Serialization.Attributes;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_registration_cs.Models.Registration
{
    public class RegistrationClasses
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("meetingId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string MeetingId { get; set; }

        [BsonElement("userId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string UserId { get; set; }

        [BsonElement("registrationStatus")]
        public string RegistrationStatus { get; set; }

        [BsonElement("title")]
        public string Title { get; set; }

        [BsonElement("courseType")]
        public string CourseType { get; set; }

        [BsonElement("hours")]
        public int Hours { get; set; }

        [BsonElement("crn")]
        public string Crn { get; set; }
        [BsonElement("details")]
        public string Details { get; set; }

        [BsonElement("times")]

        public List<TimeEntry> Times { get; set; }

        public RegistrationClasses(string id, string registrationStatus, string meetingId, string userId, string crn, int hours, string courseType, List<TimeEntry> times, string details, string title  )
        {
            Id = id;
            RegistrationStatus = registrationStatus;
            MeetingId = meetingId;
            UserId = userId;
            Crn = crn;
            Hours = hours;
            CourseType = courseType;
            Times = times;
            Details = details;
            Title = title;
        }

        public static RegistrationClasses FromCreate(RegistrationClassesCreate create)
        {
            return new RegistrationClasses(
                null,
                create.RegistrationStatus,
                create.MeetingId,
                create.UserId,
                create.Crn,
                create.Hours,
                create.CourseType,
                create.Times,
                create.Details,
                create.Title
            );
        }
        public static RegistrationClasses FromUpdate(RegistrationClasses original, RegistrationClassesUpdate update)
        {
            return new RegistrationClasses(
                original.Id,
                update.RegistrationStatus,
                original.MeetingId,
                original.UserId,
                original.Crn,
                original.Hours,
                original.CourseType,
                original.Times,
                original.Details,
                original.Title
            );
        }
    }

    public class RegistrationClassesCreate
    {
        public string RegistrationStatus { get; set; }

        public string MeetingId { get; set; }
        public string UserId { get; set; }
        public string Crn { get; set; }
        public int Hours { get; set; }
        public string CourseType { get; set; }
        public List<TimeEntry> Times { get; set; }
        public string Details { get; set; }

        public string Title { get; set; }
    }
    public class RegistrationClassesUpdate
    {
        public string RegistrationStatus { get; set; }

    }
}
