﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_registration_cs.Models.Registration
{
    public class RegistrationCourses
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("classId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string ClassId { get; set; }

        [BsonElement("userId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string UserId { get; set; }

        [BsonElement("final")]
        public char Final { get; set; }

        [BsonElement("mid")]
        public char Mid { get; set; }

        [BsonElement("qualityPoints")]
        public int QualityPoints { get; set; }

        [BsonElement("status")]
        public char Status { get; set; }

        public RegistrationCourses(string id, string classId, string userId, char final, char mid, int qualityPoints, char status)
        {
            Id = id;
            ClassId = classId;
            UserId = userId;
            Final = final;
            Mid = mid;
            QualityPoints = qualityPoints;
            Status = status;
        }

        public static RegistrationCourses FromCreate(RegistrationCoursesCreate create)
        {
            return new RegistrationCourses(
                null,
                create.ClassId,
                create.UserId,
                create.Final,
                create.Mid,
                create.QualityPoints,
                create.Status
            );
        }

        public static RegistrationCourses FromUpdate(RegistrationCourses original, RegistrationCoursesUpdate update)
        {
            return new RegistrationCourses(
                original.Id,
                original.ClassId,
                original.UserId,
                update.Final,
                update.Mid,
                update.QualityPoints,
                update.Status
            );
        }
    }
    public class RegistrationCoursesCreate
    {
        public string ClassId { get; set; }

        public string UserId { get; set; }

        public char Final { get; set; }

        public char Mid { get; set; }

        public int QualityPoints { get; set; }

        public char Status { get; set; }
    }

    public class RegistrationCoursesUpdate
    {

        public char Final { get; set; }

        public char Mid { get; set; }

        public int QualityPoints { get; set; }

        public char Status { get; set; }
    }
}
