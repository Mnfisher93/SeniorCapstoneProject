﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_registration_cs.Models.Registration
{
    public class RegistrationDates
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("term")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Term { get; set; }

        [BsonElement("userID")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string UserId { get; set; }

        [BsonElement("senior")]
        public string Senior { get; set; }

        [BsonElement("junior")]
        public string Junior { get; set; }

        [BsonElement("sophmore")]
        public string Sophmore { get; set; }

        [BsonElement("freshman")]
        public string Freshman { get; set; }

        [BsonElement("drop")]
        public string Drop { get; set; }

        [BsonElement("swap")]
        public string Swap { get; set; }

        [BsonElement("endDate")]
        public string EndDate { get; set; }

        [BsonElement("endDrop")]
        public string EndDrop { get; set; }

        public RegistrationDates(string id, string term, string userId, string senior, string junior, string sophmore, string freshman, string drop, string swap, string endDate, string endDrop)
        {
            Id = id;
            Term = term;
            UserId = userId;
            Senior = senior;
            Junior = junior;
            Sophmore = sophmore;
            Freshman = freshman;
            Drop = drop;
            Swap = swap;
            EndDate = endDate;
            EndDrop = endDrop;
        }

        public static RegistrationDates FromCreate(RegistrationDatesCreate create)
        {
            return new RegistrationDates(
                null,
                create.Term,
                create.UserId,
                create.Senior,
                create.Junior,
                create.Sophmore,
                create.Freshman,
                create.Drop,
                create.Swap,
                create.EndDate,
                create.EndDrop
            );
        }

        public static RegistrationDates FromUpdate(RegistrationDates original, RegistrationDatesUpdate update)
        {
            return new RegistrationDates(
                original.Id,
                original.Term,
                original.UserId,
                update.Senior,
                update.Junior,
                update.Sophmore,
                update.Freshman,
                update.Drop,
                update.Swap,
                update.EndDate,
                update.EndDrop
            );
        }
    }

    public class RegistrationDatesCreate
    {
        public string Term { get; set; }

        public string UserId { get; set; }

        public string Senior { get; set; }

        public string Junior { get; set; }

        public string Sophmore { get; set; }

        public string Freshman { get; set; }

        public string Drop { get; set; }

        public string Swap { get; set; }

        public string EndDate { get; set; }

        public string EndDrop { get; set; }
    }

    public class RegistrationDatesUpdate
    {
        public string Senior { get; set; }

        public string Junior { get; set; }

        public string Sophmore { get; set; }

        public string Freshman { get; set; }

        public string Drop { get; set; }

        public string Swap { get; set; }

        public string EndDate { get; set; }

        public string EndDrop { get; set; }
    }
}
