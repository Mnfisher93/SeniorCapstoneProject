﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_registration_cs.Models
{
    public class DatabaseSettings : IDatabaseSettings
    {
        public string RegistrationCoursesCollectionName { get; set; }
        public string RegistrationDatesCollectionName { get; set; }

        public string RegistrationClassesCollectionName { get; set; }
        public string LogsCollectionName { get; set; }
        public string DatabaseName { get; set; }
    }

    public interface IDatabaseSettings
    {
        string RegistrationCoursesCollectionName { get; set; }
        string RegistrationDatesCollectionName { get; set; }
        string RegistrationClassesCollectionName { get; set; }
        string LogsCollectionName { get; set; }
        string DatabaseName { get; set; }
    }
}
