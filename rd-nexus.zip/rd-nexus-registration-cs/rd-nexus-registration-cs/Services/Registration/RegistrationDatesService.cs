﻿using rd_nexus_registration_cs.Models;
using rd_nexus_registration_cs.Models.Registration;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;
using rd_nexus_registration_cs.Helpers;

namespace rd_nexus_registration_cs.Services.Registration
{
    public class RegistrationDatesService
    {
        private readonly IMongoCollection<RegistrationDates> _dates;


        public RegistrationDatesService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _dates = database.GetCollection<RegistrationDates>(settings.RegistrationDatesCollectionName);
        }

        public async Task<List<RegistrationDates>> Get() =>
            await _dates.Find(registrationDates => true).ToListAsync();

        public async Task<RegistrationDates> Get(string id) =>
            await _dates.Find<RegistrationDates>(registrationDates => registrationDates.Id == id).FirstOrDefaultAsync();

        public async Task<RegistrationDates> GetByTermId(string term) =>
           await _dates.Find<RegistrationDates>(registrationDates => registrationDates.Term == term).FirstOrDefaultAsync();

        public async Task<RegistrationDates> Create(RegistrationDatesCreate create)
        {
            var registrationDates = RegistrationDates.FromCreate(create);
            await _dates.InsertOneAsync(registrationDates);
            return registrationDates;
        }

        public async void Update(RegistrationDates orginal, RegistrationDatesUpdate update)
        {
            await _dates.ReplaceOneAsync(registrationDates => registrationDates.Id == orginal.Id, RegistrationDates.FromUpdate(orginal, update));
        }

        public async void Update(string id, RegistrationDates update) =>
            await _dates.ReplaceOneAsync(registrationDates => registrationDates.Id == id, update);
    }
}
