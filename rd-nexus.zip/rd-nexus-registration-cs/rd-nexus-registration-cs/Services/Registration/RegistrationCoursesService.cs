﻿using rd_nexus_registration_cs.Models;
using rd_nexus_registration_cs.Models.Registration;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;
using rd_nexus_registration_cs.Helpers;

namespace rd_nexus_registration_cs.Services.Registration
{
    public class RegistrationCoursesService
    {
        private readonly IMongoCollection<RegistrationCourses> _courses;

        public RegistrationCoursesService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _courses = database.GetCollection<RegistrationCourses>(settings.RegistrationCoursesCollectionName);
        }

        public async Task<List<RegistrationCourses>> Get() =>
            await _courses.Find(registrationCourses => true).ToListAsync();

        public async Task<RegistrationCourses> Get(string id) =>
            await _courses.Find<RegistrationCourses>(registrationCourses => registrationCourses.Id == id).FirstOrDefaultAsync();

        public async Task<RegistrationCourses> GetByClassId(string classId) =>
            await _courses.Find<RegistrationCourses>(registrationCourses => registrationCourses.ClassId == classId).FirstOrDefaultAsync();

        public async Task<RegistrationCourses> Create(RegistrationCoursesCreate create)
        {
            var registrationCourse = RegistrationCourses.FromCreate(create);
            await _courses.InsertOneAsync(registrationCourse);
            return registrationCourse;
        }

        public async void Update(RegistrationCourses orginal, RegistrationCoursesUpdate update)
        {
            await _courses.ReplaceOneAsync(registrationCourses => registrationCourses.Id == orginal.Id, RegistrationCourses.FromUpdate(orginal, update));
        }

        public async void Update(string id, RegistrationCourses update) =>
            await _courses.ReplaceOneAsync(registrationCourses => registrationCourses.Id == id, update);
        
    }
}
