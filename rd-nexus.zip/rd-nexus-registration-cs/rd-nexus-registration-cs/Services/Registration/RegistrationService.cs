﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_registration_cs.Services.Registration
{
    public class RegistrationService
    {
    }
}
