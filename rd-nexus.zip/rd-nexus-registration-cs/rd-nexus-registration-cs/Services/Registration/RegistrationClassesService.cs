﻿using rd_nexus_registration_cs.Models;
using rd_nexus_registration_cs.Models.Registration;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;
using rd_nexus_registration_cs.Helpers;

namespace rd_nexus_registration_cs.Services.Registration
{
    public class RegistrationClassesService
    {
        private readonly IMongoCollection<RegistrationClasses> _classes;
        public RegistrationClassesService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _classes = database.GetCollection<RegistrationClasses>(settings.RegistrationClassesCollectionName);

        }
        public async Task<List<RegistrationClasses>> Get(string userID) =>
            await _classes.Find<RegistrationClasses>(registrationClasses => registrationClasses.UserId == userID).ToListAsync();

        public async Task<RegistrationClasses> GetById(string id) =>
            await _classes.Find<RegistrationClasses>(registrationClasses => registrationClasses.Id == id).FirstOrDefaultAsync();
        public async Task<RegistrationClasses> GetByMeetingAndUser(string userId, string meetingId) =>
            await _classes.Find<RegistrationClasses>(registrationClasses => registrationClasses.MeetingId == meetingId && registrationClasses.UserId == userId).FirstOrDefaultAsync();
        public async Task<RegistrationClasses> Create(RegistrationClassesCreate create)
        {
            var registrationClasses = RegistrationClasses.FromCreate(create);
            await _classes.InsertOneAsync(registrationClasses);
            return registrationClasses;
        }
        public async void Update(RegistrationClasses original, RegistrationClassesUpdate update)
        {
            await _classes.ReplaceOneAsync(registrationClasses => registrationClasses.Id == original.Id, RegistrationClasses.FromUpdate(original, update));
        }
        public async void Update(string id, RegistrationClasses update) =>
            await _classes.ReplaceOneAsync(registrationClasses => registrationClasses.Id == id, update);
        public async void Delete(string userId, string meetingId) =>
            await _classes.DeleteOneAsync(registrationClasses => registrationClasses.UserId == userId && registrationClasses.MeetingId == meetingId);
    }
}
