﻿using Grpc.Net.Client;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using rd_nexus_registration_cs.Protos.auth;
using System.Diagnostics;
using rd_nexus_registration_cs.Helpers;

namespace rd_nexus_registration_cs.Helpers.Authorization
{
    public class AuthorizationHelpers
    {
        public static async Task<bool> CheckAccess(string token, string permissionKey)
        {
            using var channel = GrpcChannel.ForAddress(SecretHelpers.GetSecret(SecretVarNames.AuthGRPCConnectionString));

            var client = new GrpcAuthService.GrpcAuthServiceClient(channel);
            var reply = await client.CheckAccessAsync(new CheckAccessRequest { Token = token, PermissionKey = permissionKey });

            return reply.AccessGranted;
        }
    }
}
