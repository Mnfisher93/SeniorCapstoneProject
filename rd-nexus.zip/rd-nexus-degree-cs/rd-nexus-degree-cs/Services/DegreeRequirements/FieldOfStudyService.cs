﻿using MongoDB.Driver;
using rd_nexus_auth_grpc_cs.Helpers;
using rd_nexus_degree_cs.Models;
using rd_nexus_degree_cs.Models.DegreeRequirements;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_degree_cs.Services.DegreeRequirements
{
    public class FieldOfStudyService
    {
        private readonly IMongoCollection<FieldOfStudy> _fieldsOfStudy;

        public FieldOfStudyService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _fieldsOfStudy = database.GetCollection<FieldOfStudy>(settings.FieldsOfStudyCollectionName);
        }

        public async Task<List<FieldOfStudy>> Get() =>
           await _fieldsOfStudy.Find(fos => true).ToListAsync();

        public async Task<List<FieldOfStudy>> GetMajors() =>
           await _fieldsOfStudy.Find(fos => fos.Type.ToLower() == "major").ToListAsync();

        public async Task<List<FieldOfStudy>> GetMinors() =>
           await _fieldsOfStudy.Find(fos => fos.Type.ToLower() == "minor").ToListAsync();

        public async Task<FieldOfStudy> Get(string id) =>
            await _fieldsOfStudy.Find<FieldOfStudy>(fos => fos.Id == id).FirstOrDefaultAsync();

        public async Task<FieldOfStudy> Create(FieldOfStudyCreate create)
        {
            var fos = FieldOfStudy.FromCreate(create);
            await _fieldsOfStudy.InsertOneAsync(fos);
            return fos;
        }

        public async void Update(FieldOfStudy original, FieldOfStudyUpdate update)
        {
            await _fieldsOfStudy.ReplaceOneAsync(fos => fos.Id == original.Id, FieldOfStudy.FromUpdate(original, update));
        }
    }
}
