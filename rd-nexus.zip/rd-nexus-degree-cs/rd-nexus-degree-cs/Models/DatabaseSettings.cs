﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_degree_cs.Models
{
    public class DatabaseSettings : IDatabaseSettings
    {
        public string FieldsOfStudyCollectionName { get; set; }
        public string LogsCollectionName { get; set; }
        public string DatabaseName { get; set; }
    }

    public interface IDatabaseSettings
    {
        string FieldsOfStudyCollectionName { get; set; }
        string LogsCollectionName { get; set; }
        string DatabaseName { get; set; }
    }
}
