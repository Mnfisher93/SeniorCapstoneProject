﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_degree_cs.Models.DegreeRequirements
{
    public class FieldOfStudy
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("name")]
        public string Name { get; set; }

        [BsonElement("abbreviation")]
        public string Abbreviation { get; set; }

        [BsonElement("type")]
        public string Type { get; set; }

        [BsonElement("availableDegrees")]
        public List<string> AvailableDegrees { get; set; }

        public FieldOfStudy(string id, string name, string abbreviation, string type, List<string> availableDegrees)
        {
            Id = id;
            Name = name;
            Abbreviation = abbreviation;
            Type = type;
            AvailableDegrees = availableDegrees;
        }

        public static FieldOfStudy FromCreate(FieldOfStudyCreate create)
        {
            return new FieldOfStudy(null, create.Name, create.Abbreviation, create.Type, create.AvailableDegrees);
        }

        public static FieldOfStudy FromUpdate(FieldOfStudy original, FieldOfStudyUpdate update)
        {
            return new FieldOfStudy(original.Id, update.Name, update.Abbreviation, update.Type, update.AvailableDegrees);
        }
    }

    public class FieldOfStudyCreate 
    {
        public string Name { get; set; }
        public string Abbreviation { get; set; }
        public string Type { get; set; }

        public List<string> AvailableDegrees { get; set; }
    }

    public class FieldOfStudyUpdate
    {
        public string Name { get; set; }
        public string Abbreviation { get; set; }
        public string Type { get; set; }

        public List<string> AvailableDegrees { get; set; }
    }
}
