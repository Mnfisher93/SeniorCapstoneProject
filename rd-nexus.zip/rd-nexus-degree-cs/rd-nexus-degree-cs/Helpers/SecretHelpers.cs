﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Threading.Tasks;

namespace rd_nexus_auth_grpc_cs.Helpers
{
    public enum SecretVarNames
    {
        MongoConnectionString,
        AuthGRPCConnectionString
    }

    public class SecretHelpers
    {
        public static string GetSecret(SecretVarNames secret)
        {
            string secretName;

            switch (secret)
            {
                case SecretVarNames.MongoConnectionString:
                    secretName = "Nexus-MongoConnString";
                    break;
                case SecretVarNames.AuthGRPCConnectionString:
                    secretName = "Nexus-AuthGRPCConnString";
                    break;
                default:
                    throw new ArgumentException("Secret does not match existing definitions");
            }

            if (RuntimeInformation.IsOSPlatform(OSPlatform.Windows))
            {
                return Environment.GetEnvironmentVariable(secretName, EnvironmentVariableTarget.Machine);
            }
            else
            {
                return Environment.GetEnvironmentVariable(secretName);
            }
        }
    }
}
