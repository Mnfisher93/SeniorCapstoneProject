﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using rd_nexus_degree_cs.Helpers.Authorization;
using rd_nexus_degree_cs.Models.DegreeRequirements;
using rd_nexus_degree_cs.Services.DegreeRequirements;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_degree_cs.Controllers.DegreeRequirements
{
    [Route("api/[controller]")]
    [ApiController]
    public class FieldOfStudyController : ControllerBase
    {
        private readonly FieldOfStudyService _fieldOfStudyService;

        public FieldOfStudyController(FieldOfStudyService fieldOfStudyService)
        {
            _fieldOfStudyService = fieldOfStudyService;
        }

        [HttpGet]
        public async Task<ActionResult<List<FieldOfStudy>>> Get([FromHeader] string authToken)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "fosView"))
            {
                return Unauthorized();
            }

            return await _fieldOfStudyService.Get();
        }

        [HttpGet("majors")]
        public async Task<ActionResult<List<FieldOfStudy>>> GetMajors([FromHeader] string authToken)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "fosView"))
            {
                return Unauthorized();
            }

            return await _fieldOfStudyService.GetMajors();
        }

        [HttpGet("minors")]
        public async Task<ActionResult<List<FieldOfStudy>>> GetMinors([FromHeader] string authToken)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "fosView"))
            {
                return Unauthorized();
            }

            return await _fieldOfStudyService.GetMinors();
        }

        [HttpGet("{id:length(24)}")]
        public async Task<ActionResult<FieldOfStudy>> Get([FromHeader] string authToken, string id)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "fosView"))
            {
                return Unauthorized();
            }

            var fos = await _fieldOfStudyService.Get(id);

            if (fos == null)
            {
                return NotFound();
            }

            return fos;
        }

        [HttpPost]
        public async Task<ActionResult<FieldOfStudy>> Create([FromHeader] string authToken, FieldOfStudyCreate create)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "fosMgr"))
            {
                return Unauthorized();
            }

            FieldOfStudy created = await _fieldOfStudyService.Create(create);

            return Ok(create);
        }

        [HttpPut("{id:length(24)}")]
        public async Task<ActionResult<FieldOfStudy>> Update([FromHeader] string authToken, string id, FieldOfStudyUpdate update)
        {
            if (!await AuthorizationHelpers.CheckAccess(authToken, "fosMgr"))
            {
                return Unauthorized();
            }

            var fos = await _fieldOfStudyService.Get(id);

            if (fos == null)
            {
                return NotFound();
            }

            _fieldOfStudyService.Update(fos, update);

            return Ok();
        }
    }
}
