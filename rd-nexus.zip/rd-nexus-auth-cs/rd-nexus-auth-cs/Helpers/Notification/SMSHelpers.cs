﻿using Amazon;
using Amazon.Runtime;
using Amazon.SimpleNotificationService;
using Amazon.SimpleNotificationService.Model;
using rd_nexus_auth_grpc_cs.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Helpers.Notification
{
    public class SMSHelpers
    {
        public static async Task<bool> SendVerificationSMS(string countryCode, string phoneNumber, string verificationCode)
        {
            string message = "Your Nexus phone verification code is: " + verificationCode + ". Do NOT share this code with anyone.";

            return await SendSMS("+" + countryCode + phoneNumber, message);
        }

        private static async Task<bool> SendSMS(string phoneNumber, string message)
        {
            string awsAccessKey = SecretHelpers.GetSecret(SecretVarNames.AWSAccessKey);
            string awsSecretKey = SecretHelpers.GetSecret(SecretVarNames.AWSSecretKey);

            var snsClient = new AmazonSimpleNotificationServiceClient(awsAccessKey, awsSecretKey, RegionEndpoint.USEast1);
            PublishRequest publishRequest = new PublishRequest();
            publishRequest.Message = message;
            publishRequest.PhoneNumber = phoneNumber;

            try
            {
                await snsClient.PublishAsync(publishRequest);
            }
            catch(Exception)
            {
                return false;
            }

            return true;
        }
    }
}
