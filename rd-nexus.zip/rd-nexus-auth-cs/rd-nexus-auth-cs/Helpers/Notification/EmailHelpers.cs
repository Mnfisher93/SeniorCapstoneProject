﻿using Amazon;
using Amazon.SimpleEmail;
using Amazon.SimpleEmail.Model;
using rd_nexus_auth_grpc_cs.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Helpers.Notification
{
    public class EmailHelpers
    {
        public static async Task<bool> SendVerificationEmail(string address, string verificationCode)
        {
            string textBody = 
                "Hello!\r\n" +
                "Your email verifification code is " + verificationCode + ".\r\n" +
                "Please do not share this code with anyone.\r\n" +
                "If you did not request this verification code, you can safely ignore this email.";

            string htmlBody =
                "<html><head></head><body>" +
                "<h1>Verify Email</h1>" +
                "<p>Hello! Your email verification code is " + verificationCode + ". Please do not share this code with anyone.</p>" +
                "<p>If you did not request this verification code, you can safely ignore this email.</p>" +
                "</body></html>";

            return await SendEmail(new List<string> { address }, "Nexus - Verify Email", htmlBody, textBody);
        }

        public static async Task<bool> SendAdminPasswordResetEmail(string address, string password)
        {
            string textBody =
                "Hello!\r\n" +
                "Your password was reset by an administrator. Your new password is:\r\n" +
                password + "\r\n" + 
                "You should change your password immediately upon logging in.\r\n" + 
                "Have a nice day!";

            string htmlBody =
                "<html><head></head><body>" +
                "<h1>Password Reset by Administrator</h1>" +
                "<p>Your password was reset by an administrator. Your new password is:</p>" +
                "<p><strong>" + password + "</strong></p>" + 
                "<p>You should change your password immediately upon logging in.</p>" + 
                "<p>Have a nice day!</p>" +
                "</body></html>";

            return await SendEmail(new List<string> { address }, "Nexus - Password Reset by Administrator", htmlBody, textBody);
        }

        private static async Task<bool> SendEmail(List<string> to, string subject, string htmlBody, string textBody)
        {
            string awsAccessKey = SecretHelpers.GetSecret(SecretVarNames.AWSAccessKey);
            string awsSecretKey = SecretHelpers.GetSecret(SecretVarNames.AWSSecretKey);
            string fromAddress = Startup.StaticConfiguration.GetSection("EmailSettings")["FromAddress"];

            using (var client = new AmazonSimpleEmailServiceClient(awsAccessKey, awsSecretKey, RegionEndpoint.USEast2))
            {
                var sendRequest = new SendEmailRequest
                {
                    Source = fromAddress,
                    Destination = new Destination { ToAddresses = to },
                    Message = new Message
                    {
                        Subject = new Content(subject),
                        Body = new Body
                        {
                            Html = new Content { Charset = "UTF-8", Data = htmlBody },
                            Text = new Content { Charset = "UTF-8", Data = textBody }
                        }
                    }
                };

                try
                {
                    await client.SendEmailAsync(sendRequest);
                }
                catch (Exception)
                {
                    return false;
                }
            }

            return true;
        }
    }
}
