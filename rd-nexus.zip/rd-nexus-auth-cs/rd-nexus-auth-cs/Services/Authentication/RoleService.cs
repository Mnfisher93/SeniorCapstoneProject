﻿using rd_nexus_auth_cs.Models;
using rd_nexus_auth_cs.Models.Authentication;
using rd_nexus_auth_grpc_cs.Helpers;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using rd_nexus_auth_grpc_cs.Helpers;

namespace rd_nexus_auth_cs.Services.Authentication
{
    public class RoleService
    {
        private readonly IMongoCollection<Role> _roles;

        public RoleService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _roles = database.GetCollection<Role>(settings.RolesCollectionName);
        }

        public async Task<List<Role>> Get() =>
            await _roles.Find(role => true).ToListAsync();

        public async Task<Role> Get(string id) =>
            await _roles.Find<Role>(role => role.Id == id).FirstOrDefaultAsync();

        public async Task<Role> Create(RoleCreate create)
        {
            var role = Role.FromCreate(create);
            await _roles.InsertOneAsync(role);
            return role;
        }

        public async void Update(string id, RoleUpdate update) =>
            await _roles.ReplaceOneAsync(role => role.Id == id, Role.FromUpdate(id, update));
    }
}
