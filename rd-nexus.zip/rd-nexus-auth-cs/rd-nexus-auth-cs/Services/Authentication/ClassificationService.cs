﻿using MongoDB.Driver;
using rd_nexus_auth_cs.Models;
using rd_nexus_auth_cs.Models.Authentication;
using rd_nexus_auth_grpc_cs.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Services.Authentication
{
    public class ClassificationService
    {
        private readonly IMongoCollection<Classification> _classifications;

        public ClassificationService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _classifications = database.GetCollection<Classification>(settings.ClassificationsCollectionName);
        }

        public async Task<List<Classification>> Get() =>
           await _classifications.Find(classification => true).ToListAsync();

        public async Task<Classification> Get(string id) =>
            await _classifications.Find<Classification>(classification => classification.Id == id).FirstOrDefaultAsync();

        public async Task<Classification> Create(ClassificationCreate create)
        {
            var classification = Classification.FromCreate(create);
            await _classifications.InsertOneAsync(classification);
            return classification;
        }
    }
}
