﻿using rd_nexus_auth_cs.Models;
using rd_nexus_auth_cs.Models.Authentication;
using MongoDB.Driver;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System;
using rd_nexus_auth_grpc_cs.Helpers;

namespace rd_nexus_auth_cs.Services.Authentication
{
    public class UserService
    {
        private readonly IMongoCollection<User> _users;

        public UserService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _users = database.GetCollection<User>(settings.UsersCollectionName);
        }

        public async Task<List<User>> Get() =>
            await _users.Find(user => true).ToListAsync();

        public async Task<User> Get(string id) =>
            await _users.Find<User>(user => user.Id == id).FirstOrDefaultAsync();

        public async Task<User> GetByUserId(string userId) =>
            await _users.Find<User>(user => user.UserId == userId).FirstOrDefaultAsync();

        public async Task<List<User>> GetByClassification(string classificationId)
        {
            var filter = Builders<User>.Filter.Where(u => u.Classifications.Any(c => c == classificationId));

            return await _users.Find<User>(filter).ToListAsync();
        }

        public async Task<User> GetByUsername(string username) =>
            await _users.Find<User>(user => user.Username.ToLower() == username.ToLower()).FirstOrDefaultAsync();

        public async Task<User> Create(UserCreate create)
        {
            var user = User.FromCreate(create);
            await _users.InsertOneAsync(user);
            return user;
        }

        public async void Update(User original, UserUpdate update)
        {
            await _users.ReplaceOneAsync(user => user.Id == original.Id, User.FromUpdate(original, update));
        }

        public async void Update(string id, User update) =>
            await _users.ReplaceOneAsync(user => user.Id == id, update);

        public async void AddEmail(string userId, EmailEntry entry)
        {
            var filter = Builders<User>.Filter.Eq(u => u.Id, userId);
            var update = Builders<User>.Update.Push<EmailEntry>(u => u.Emails, entry);

            await _users.UpdateOneAsync(filter, update);
        }

        public async void RemoveEmail(string userId, string address)
        {
            var filter = Builders<User>.Filter.Eq(u => u.Id, userId);
            var update = Builders<User>.Update.PullFilter<EmailEntry>(u => u.Emails, e => e.Email.ToLower() == address.ToLower());

            await _users.UpdateOneAsync(filter, update);
        }

        public async void UpdateEmailPrimary(string userId, string address, bool primaryFlag)
        {
            var filter = Builders<User>.Filter.Where(u => u.Id == userId && u.Emails.Any(e => e.Email.ToLower() == address.ToLower()));
            var update = Builders<User>.Update.Set(u => u.Emails[-1].PrimaryFlag, primaryFlag);

            await _users.UpdateOneAsync(filter, update);
        }

        public async void VerifyEmail(string userId, string address)
        {
            var filter = Builders<User>.Filter.Where(u => u.Id == userId && u.Emails.Any(e => e.Email.ToLower() == address.ToLower()));
            var update = Builders<User>.Update.Set(u => u.Emails[-1].VerifiedFlag, true);

            await _users.UpdateOneAsync(filter, update);
        }

        public async void AddPhoneNumber(string userId, PhoneNumberEntry entry)
        {
            var filter = Builders<User>.Filter.Eq(u => u.Id, userId);
            var update = Builders<User>.Update.Push<PhoneNumberEntry>(u => u.PhoneNumbers, entry);

            await _users.UpdateOneAsync(filter, update);
        }

        public async void RemovePhoneNumber(string userId, string phoneNumber)
        {
            var filter = Builders<User>.Filter.Eq(u => u.Id, userId);
            var update = Builders<User>.Update.PullFilter<PhoneNumberEntry>(u => u.PhoneNumbers, e => e.PhoneNumber.ToLower() == phoneNumber.ToLower());

            await _users.UpdateOneAsync(filter, update);
        }

        public async void UpdatePhonePrimary(string userId, string phoneNumber, bool primaryFlag)
        {
            var filter = Builders<User>.Filter.Where(u => u.Id == userId && u.PhoneNumbers.Any(e => e.PhoneNumber.ToLower() == phoneNumber.ToLower()));
            var update = Builders<User>.Update.Set(u => u.PhoneNumbers[-1].PrimaryFlag, primaryFlag);

            await _users.UpdateOneAsync(filter, update);
        }

        public async void VerifyPhone(string userId, string phoneNumber)
        {
            var filter = Builders<User>.Filter.Where(u => u.Id == userId && u.PhoneNumbers.Any(e => e.PhoneNumber.ToLower() == phoneNumber.ToLower()));
            var update = Builders<User>.Update.Set(u => u.PhoneNumbers[-1].VerifiedFlag, true);

            await _users.UpdateOneAsync(filter, update);
        }
    }
}
