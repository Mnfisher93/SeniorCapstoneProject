﻿using rd_nexus_auth_cs.Models;
using rd_nexus_auth_cs.Models.Authentication;
using rd_nexus_auth_grpc_cs.Helpers;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using rd_nexus_auth_grpc_cs.Helpers;

namespace rd_nexus_auth_cs.Services.Authentication
{
    public class PermissionService
    {
        private readonly IMongoCollection<Permission> _permissions;

        public PermissionService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _permissions = database.GetCollection<Permission>(settings.PermissionsCollectionName);
        }

        public async Task<List<Permission>> Get() =>
            await _permissions.Find(permission => true).ToListAsync();

        public async Task<Permission> Get(string id) =>
            await _permissions.Find<Permission>(permission => permission.Id == id).FirstOrDefaultAsync();
    }
}
