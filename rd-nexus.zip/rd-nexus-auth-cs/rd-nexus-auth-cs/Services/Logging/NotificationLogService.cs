﻿using MongoDB.Driver;
using rd_nexus_auth_cs.Models;
using rd_nexus_auth_cs.Models.Logging;
using rd_nexus_auth_grpc_cs.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Services.Logging
{
    public class NotificationLogService
    {
        private readonly IMongoCollection<NotificationLog> _notificationLogs;

        public NotificationLogService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _notificationLogs = database.GetCollection<NotificationLog>(settings.NotificationLogsCollectionName);
        }

        public async Task<List<NotificationLog>> Get() =>
            await _notificationLogs.Find(notificationLog => true).ToListAsync();

        public async Task<NotificationLog> Get(string id) =>
            await _notificationLogs.Find<NotificationLog>(notificationLog => notificationLog.Id == id).FirstOrDefaultAsync();

        public async Task<NotificationLog> Create(NotificationLog create)
        {
            await _notificationLogs.InsertOneAsync(create);
            return create;
        }
    }
}
