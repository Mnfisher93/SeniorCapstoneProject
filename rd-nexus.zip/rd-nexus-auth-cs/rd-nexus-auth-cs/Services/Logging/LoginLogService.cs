﻿using MongoDB.Driver;
using rd_nexus_auth_cs.Models;
using rd_nexus_auth_cs.Models.Logging;
using rd_nexus_auth_grpc_cs.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Services.Logging
{
    public class LoginLogService
    {
        private readonly IMongoCollection<LoginLog> _loginLogs;

        public LoginLogService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _loginLogs = database.GetCollection<LoginLog>(settings.LoginLogsCollectionName);
        }

        public async Task<List<LoginLog>> Get() =>
            await _loginLogs.Find(log => true).ToListAsync();

        public async Task<LoginLog> Get(string id) =>
            await _loginLogs.Find<LoginLog>(loginLog => loginLog.Id == id).FirstOrDefaultAsync();

        public async Task<LoginLog> Create(LoginLog create)
        {
            await _loginLogs.InsertOneAsync(create);
            return create;
        }
    }
}
