﻿using MongoDB.Driver;
using rd_nexus_auth_cs.Models;
using rd_nexus_auth_cs.Models.Logging;
using rd_nexus_auth_grpc_cs.Helpers;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Services.Logging
{
    public class UserChangelogService
    {
        private readonly IMongoCollection<UserChangelog> _logs;

        public UserChangelogService(IDatabaseSettings settings)
        {
            var client = new MongoClient(SecretHelpers.GetSecret(SecretVarNames.MongoConnectionString));
            var database = client.GetDatabase(settings.DatabaseName);

            _logs = database.GetCollection<UserChangelog>(settings.UserChangelogCollectionName);
        }

        public async Task<List<UserChangelog>> Get() =>
            await _logs.Find(log => true).ToListAsync();

        public async Task<UserChangelog> Get(string id) =>
            await _logs.Find<UserChangelog>(log => log.Id == id).FirstOrDefaultAsync();

        public async Task<UserChangelog> Create(UserChangelog create)
        {
            await _logs.InsertOneAsync(create);
            return create;
        }
    }
}
