﻿using MongoDB.Bson.Serialization.Attributes;
using rd_nexus_auth_cs.Helpers.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Models.Authentication
{
    public class PhoneNumberEntry
    {
        [BsonElement("countryCode")]
        public string CountryCode { get; set; }

        [BsonElement("phoneNumber")]
        public string PhoneNumber { get; set; }

        [BsonElement("primaryFlag")]
        public bool PrimaryFlag { get; set; }

        [BsonElement("verifiedFlag")]
        public bool VerifiedFlag { get; set; }

        [BsonElement("verificationCode")]
        public string VerificationCode { get; set; }

        public PhoneNumberEntry(string countryCode, string phoneNumber, bool primaryFlag, bool verifiedFlag, string verificationCode)
        {
            CountryCode = countryCode;
            PhoneNumber = phoneNumber;
            PrimaryFlag = primaryFlag;
            VerifiedFlag = verifiedFlag;
            VerificationCode = verificationCode;
        }

        public static PhoneNumberEntry FromCreate(PhoneNumberEntryCreate create)
        {
            return new PhoneNumberEntry(create.CountryCode, create.PhoneNumber, create.PrimaryFlag, false, AuthenticationHelpers.GenerateVerificationCode());
        }
    }

    public class PhoneNumberEntryCreate
    {
        public string CountryCode { get; set; }

        public string PhoneNumber { get; set; }

        public bool PrimaryFlag { get; set; }
    }
}
