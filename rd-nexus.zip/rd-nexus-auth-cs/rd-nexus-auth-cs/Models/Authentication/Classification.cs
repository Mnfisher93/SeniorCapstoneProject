﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Models.Authentication
{
    public class Classification
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("name")]
        public string Name { get; set; }

        public Classification(string id, string name)
        {
            Id = id;
            Name = name;
        }

        public static Classification FromCreate(ClassificationCreate create)
        {
            return new Classification(null, create.name);
        }
    }

    public class ClassificationCreate
    {
        public string name { get; set; }
    }
}
