﻿using MongoDB.Bson.Serialization.Attributes;
using rd_nexus_auth_cs.Helpers.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Models.Authentication
{
    public class EmailEntry
    {
        [BsonElement("email")]
        public string Email { get; set; }

        [BsonElement("primaryFlag")]
        public bool PrimaryFlag { get; set; }

        [BsonElement("verifiedFlag")]
        public bool VerifiedFlag { get; set; }

        [BsonElement("verificationCode")]
        public string VerificationCode { get; set; }

        public EmailEntry(string email, bool primaryFlag, bool verifiedFlag, string verificationCode)
        {
            Email = email;
            PrimaryFlag = primaryFlag;
            VerifiedFlag = verifiedFlag;
            VerificationCode = verificationCode;
        }

        public static EmailEntry FromCreate(EmailEntryCreate create)
        {
            return new EmailEntry(create.Email, create.PrimaryFlag, false, AuthenticationHelpers.GenerateVerificationCode());
        }
    }

    public class EmailEntryCreate
    {
        public string Email { get; set; }

        public bool PrimaryFlag { get; set; }
    }
}
