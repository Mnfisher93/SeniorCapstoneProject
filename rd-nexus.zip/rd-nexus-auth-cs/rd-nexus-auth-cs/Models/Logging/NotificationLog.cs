﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Models.Logging
{
    public class NotificationLog
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("userId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string UserId { get; set; }

        [BsonElement("type")]
        public string Type { get; set; }

        [BsonElement("utc")]
        public DateTime Utc { get; set; }

        [BsonElement("reason")]
        public string Reason { get; set; }

        [BsonElement("status")]
        public string Status { get; set; }

        public NotificationLog(string id, string userId, string type, DateTime utc, string reason, string status)
        {
            Id = id;
            UserId = userId;
            Type = type;
            Utc = utc;
            Reason = reason;
            Status = status;
        }
    }
}
