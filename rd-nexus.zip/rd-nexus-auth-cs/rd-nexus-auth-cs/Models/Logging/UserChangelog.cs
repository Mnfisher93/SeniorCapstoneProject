﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Models.Logging
{
    public class UserChangelog
    {
        [BsonId]
        [BsonRepresentation(BsonType.ObjectId)]
        public string Id { get; set; }

        [BsonElement("userId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string UserId { get; set; }

        [BsonElement("timestampUtc")]
        public DateTime TimestampUtc { get; set; }

        [BsonElement("message")]
        public string message { get; set; }

        [BsonElement("documentId")]
        [BsonRepresentation(BsonType.ObjectId)]
        public string DocumentId { get; set; }

        [BsonElement("document")]
        public string Document { get; set; }

        public UserChangelog(string id, string userId, DateTime timestampUtc, string message, string documentId, string document)
        {
            Id = id;
            UserId = userId;
            TimestampUtc = timestampUtc;
            this.message = message;
            DocumentId = documentId;
            Document = document;
        }
    }
}
