﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Models
{
    public class DatabaseSettings : IDatabaseSettings
    {
        public string UsersCollectionName { get; set; }
        public string PermissionsCollectionName { get; set; }
        public string RolesCollectionName { get; set; }
        public string TokensCollectionName { get; set; }
        public string LoginLogsCollectionName { get; set; }
        public string UserChangelogCollectionName { get; set; }
        public string LogsCollectionName { get; set; }
        public string NotificationLogsCollectionName { get; set; }
        public string ClassificationsCollectionName { get; set; }
        public string DatabaseName { get; set; }
    }

    public interface IDatabaseSettings
    {
        string UsersCollectionName { get; set; }
        string PermissionsCollectionName { get; set; }
        string RolesCollectionName { get; set; }
        string TokensCollectionName { get; set; }
        string LoginLogsCollectionName { get; set; }
        string UserChangelogCollectionName { get; set; }
        string LogsCollectionName { get; set; }
        string NotificationLogsCollectionName { get; set; }
        string ClassificationsCollectionName { get; set; }
        string DatabaseName { get; set; }
    }
}
