﻿using rd_nexus_auth_cs.DataTransfer;
using rd_nexus_auth_cs.Helpers.Authentication;
using rd_nexus_auth_cs.Models.Authentication;
using rd_nexus_auth_cs.Models.Logging;
using rd_nexus_auth_cs.Services.Authentication;
using rd_nexus_auth_cs.Services.Logging;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;
using rd_nexus_auth_cs.DataTransfer.Helpers;
using rd_nexus_auth_cs.Helpers.Notification;

namespace rd_nexus_auth_cs.Controllers.Authentication
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IWebHostEnvironment _hostEnvironment;

        private readonly AuthenticationService _authenticationService;
        private readonly UserChangelogService _changelogService;
        private readonly LoginLogService _loginLogService;
        private readonly NotificationLogService _notificationLogService;
        private readonly UserService _userService;
        private readonly RoleService _roleService;
        private readonly PermissionService _permissionService;
        private readonly TokenService _tokenService;

        public UserController(IWebHostEnvironment hostEnvironment, AuthenticationService authenticationService, UserChangelogService changelogService, LoginLogService loginLogService, NotificationLogService notificationLogService, UserService userService, RoleService roleService, PermissionService permissionService, TokenService tokenService)
        {
            _hostEnvironment = hostEnvironment;

            _authenticationService = authenticationService;
            _changelogService = changelogService;
            _loginLogService = loginLogService;
            _notificationLogService = notificationLogService;
            _userService = userService;
            _roleService = roleService;
            _permissionService = permissionService;
            _tokenService = tokenService;
        }

        [HttpGet]
        public async Task<ActionResult<List<User>>> Get([FromHeader] string authToken)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userView"))
            {
                return Unauthorized();
            }

            return await _userService.Get();
        }

        [HttpGet("classification")]
        public async Task<ActionResult<List<User>>> GetByClassification([FromHeader] string authToken, [FromQuery] string classificationId)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userView"))
            {
                return Unauthorized();
            }

            return await _userService.GetByClassification(classificationId);
        }

        [HttpGet("paginated")]
        public async Task<ActionResult<PaginatedItemsDto<User>>> GetPaginated(
            [FromHeader] string authToken,
            [FromQuery] int pageIndex = 0,
            [FromQuery] int pageSize = 1,
            [FromQuery] string orderBy = "LastName",
            [FromQuery] bool isAscending = true,
            [FromQuery] UserSearchParameters searchParameters = null
        )
        {
            if (pageIndex < 0)
            {
                return BadRequest("Page index must be greater than or equal to 0.");
            }

            if (pageSize < 1)
            {
                return BadRequest("Page size must be greater than or equal to 1.");
            }

            if (!await _authenticationService.CheckAccess(authToken, "userView"))
            {
                return Unauthorized();
            }

            var users = await _userService.Get();
            var queryable = users.AsQueryable();
            var filtered = GetFiltered(queryable, searchParameters);
            var ordered = isAscending ? filtered.OrderByMember(orderBy) : filtered.OrderByMemberDescending(orderBy);
            var paginated = ordered.Skip(pageIndex * pageSize).Take(pageSize);

            long totalCount = ordered.LongCount();

            return Ok(new PaginatedItemsDto<User>(pageIndex, pageSize, totalCount, paginated));
        }

        [HttpGet("{id:length(24)}")]
        public async Task<ActionResult<User>> Get([FromHeader] string authToken, string id)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userView"))
            {
                return Unauthorized();
            }

            var user = await _userService.Get(id);

            if (user == null)
            {
                return NotFound();
            }

            return user;
        }

        [HttpPost]
        public async Task<ActionResult<User>> Create([FromHeader] string authToken, UserCreate create)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userMgr"))
            {
                return Unauthorized();
            }

            User created = await _userService.Create(create);

            await _changelogService.Create(new UserChangelog(
                null,
                AuthenticationHelpers.GetUserIdFromToken(authToken),
                DateTime.UtcNow,
                "Document created.",
                created.Id,
                JsonSerializer.Serialize(created)
            ));

            created = await _userService.GetByUsername(created.Username);

            return Ok(created);
        }

        [HttpPut("{id:length(24)}")]
        public async Task<IActionResult> Update([FromHeader] string authToken, string id, UserUpdate update)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userMgr"))
            {
                return Unauthorized();
            }

            var user = await _userService.Get(id);

            if (user == null)
            {
                return NotFound();
            }

            if (!user.Password.Equals(update.Password))
            {
                bool notificationSuccess = await EmailHelpers.SendAdminPasswordResetEmail(user.Emails.Find(e => e.PrimaryFlag).Email, update.Password);

                await _notificationLogService.Create(new NotificationLog(
                    null,
                    id,
                    "Email",
                    DateTime.UtcNow,
                    "Password changed by administrator.",
                    notificationSuccess ? "Success" : "Fail"
                ));

                update.Password = AuthenticationHelpers.EncrpytPassword(update.Password);

                // Kill all active sessions
                await _tokenService.InvalidateUserTokens(user.Id);
            }

            var permDiff = user.Permissions.Except(update.Permissions);
            var roleDiff = user.Roles.Except(update.Roles);

            // If the user's roles or permissions have changed, kill their sessions
            if (permDiff.Count() != 0 || roleDiff.Count() != 0)
            {
                // Kill all active sessions
                await _tokenService.InvalidateUserTokens(user.Id);
            }

            _userService.Update(user, update);

            await _changelogService.Create(new UserChangelog(
                null,
                AuthenticationHelpers.GetUserIdFromToken(authToken),
                DateTime.UtcNow,
                "Document modified.",
                id,
                JsonSerializer.Serialize(rd_nexus_auth_cs.Models.Authentication.User.FromUpdate(user, update))
            ));

            return Ok();
        }

        [HttpPost("{id:length(24)}/email/add")]
        public async Task<IActionResult> AddEmail([FromHeader] string authToken, [FromRoute] string id, [FromBody] EmailEntryCreate create)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userMgr"))
            {
                return Unauthorized();
            }

            var user = await _userService.Get(id);

            if (user == null)
            {
                return NotFound("user not found");
            }

            EmailEntry newEntry = EmailEntry.FromCreate(create);

            if (user.Emails.Exists(email => email.Email.Equals(newEntry.Email, StringComparison.OrdinalIgnoreCase)))
            {
                return BadRequest("email already exists");
            }

            if (newEntry.PrimaryFlag)
            {
                foreach(EmailEntry entry in user.Emails.Where(e => e.PrimaryFlag))
                {
                    _userService.UpdateEmailPrimary(id, entry.Email, false);
                }
            }

            _userService.AddEmail(id, newEntry);

            bool notificationSuccess = await EmailHelpers.SendVerificationEmail(newEntry.Email, newEntry.VerificationCode);

            await _notificationLogService.Create(new NotificationLog(
                null,
                id,
                "Email",
                DateTime.UtcNow,
                "New email address added.",
                notificationSuccess ? "Success" : "Fail"
            ));

            await _changelogService.Create(new UserChangelog(
                null,
                AuthenticationHelpers.GetUserIdFromToken(authToken),
                DateTime.UtcNow,
                "Email address added.",
                id,
                JsonSerializer.Serialize(_userService.GetByUserId(id))
            ));

            return Ok();
        }

        [HttpPost("{id:length(24)}/email/remove/{address}")]
        public async Task<IActionResult> RemoveEmail([FromHeader] string authToken, [FromRoute] string id, [FromRoute] string address)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userMgr"))
            {
                return Unauthorized();
            }

            var user = await _userService.Get(id);

            if (user == null)
            {
                return NotFound("user not found");
            }

            if(!user.Emails.Exists(email => email.Email.Equals(address, StringComparison.OrdinalIgnoreCase)))
            {
                return BadRequest("email does not exist");
            }

            _userService.RemoveEmail(id, address);

            await _changelogService.Create(new UserChangelog(
                null,
                AuthenticationHelpers.GetUserIdFromToken(authToken),
                DateTime.UtcNow,
                "Email address removed.",
                id,
                JsonSerializer.Serialize(_userService.GetByUserId(id))
            ));

            return Ok();
        }

        [HttpPut("{id:length(24)}/email/setPrimary/{address}")]
        public async Task<IActionResult> SetPrimaryEmail([FromHeader] string authToken, [FromRoute] string id, [FromRoute] string address)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userMgr"))
            {
                return Unauthorized();
            }

            var user = await _userService.Get(id);

            if (user == null)
            {
                return NotFound("user not found");
            }

            if (!user.Emails.Exists(email => email.Email.Equals(address, StringComparison.OrdinalIgnoreCase)))
            {
                return BadRequest("email does not exist");
            }

            foreach (EmailEntry entry in user.Emails.Where(e => e.PrimaryFlag))
            {
                _userService.UpdateEmailPrimary(id, entry.Email, false);
            }

            _userService.UpdateEmailPrimary(id, address, true);

            await _changelogService.Create(new UserChangelog(
                null,
                AuthenticationHelpers.GetUserIdFromToken(authToken),
                DateTime.UtcNow,
                "Primary email address changed.",
                id,
                JsonSerializer.Serialize(_userService.GetByUserId(id))
            ));

            return Ok();
        }

        [HttpPost("{id:length(24)}/email/verify/{address}/{code}")]
        public async Task<IActionResult> VerifyEmail([FromHeader] string authToken, [FromRoute] string id, [FromRoute] string address, [FromRoute] string code)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userMgr"))
            {
                return Unauthorized();
            }

            var user = await _userService.Get(id);

            if (user == null)
            {
                return NotFound("user not found");
            }

            if (!user.Emails.Exists(email => email.Email.Equals(address, StringComparison.OrdinalIgnoreCase)))
            {
                return BadRequest("email does not exist");
            }

            EmailEntry entry = user.Emails.Find(e => e.Email.ToLower() == address.ToLower());

            if (entry.VerificationCode != code)
            {
                return BadRequest("invalid verification code");
            }

            _userService.VerifyEmail(id, address);

            await _changelogService.Create(new UserChangelog(
                null,
                AuthenticationHelpers.GetUserIdFromToken(authToken),
                DateTime.UtcNow,
                "Email address verified.",
                id,
                JsonSerializer.Serialize(_userService.GetByUserId(id))
            ));

            return Ok();
        }

        [HttpPost("{id:length(24)}/phone/add")]
        public async Task<IActionResult> AddPhoneNumber([FromHeader] string authToken, [FromRoute] string id, [FromBody] PhoneNumberEntryCreate create)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userMgr"))
            {
                return Unauthorized();
            }

            var user = await _userService.Get(id);

            if (user == null)
            {
                return NotFound("user not found");
            }

            PhoneNumberEntry newEntry = PhoneNumberEntry.FromCreate(create);

            if (user.PhoneNumbers.Exists(p => p.PhoneNumber.Equals(newEntry.PhoneNumber, StringComparison.OrdinalIgnoreCase)))
            {
                return BadRequest("phone number already exists");
            }

            if (newEntry.PrimaryFlag)
            {
                foreach (PhoneNumberEntry entry in user.PhoneNumbers.Where(p => p.PrimaryFlag))
                {
                    _userService.UpdatePhonePrimary(id, entry.PhoneNumber, false);
                }
            }

            _userService.AddPhoneNumber(id, newEntry);

            bool notificationSuccess = await SMSHelpers.SendVerificationSMS(newEntry.CountryCode, newEntry.PhoneNumber, newEntry.VerificationCode);

            await _notificationLogService.Create(new NotificationLog(
                null,
                id,
                "SMS",
                DateTime.UtcNow,
                "New phone number added.",
                notificationSuccess ? "Success" : "Fail"
            ));

            await _changelogService.Create(new UserChangelog(
                null,
                AuthenticationHelpers.GetUserIdFromToken(authToken),
                DateTime.UtcNow,
                "Phone number added.",
                id,
                JsonSerializer.Serialize(_userService.GetByUserId(id))
            ));

            return Ok();
        }

        [HttpPost("{id:length(24)}/phone/remove/{phoneNumber}")]
        public async Task<IActionResult> RemovePhoneNumber([FromHeader] string authToken, [FromRoute] string id, [FromRoute] string phoneNumber)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userMgr"))
            {
                return Unauthorized();
            }

            var user = await _userService.Get(id);

            if (user == null)
            {
                return NotFound("user not found");
            }

            if (!user.PhoneNumbers.Exists(p => p.PhoneNumber.Equals(phoneNumber, StringComparison.OrdinalIgnoreCase)))
            {
                return BadRequest("phone number does not exist");
            }

            _userService.RemovePhoneNumber(id, phoneNumber);

            await _changelogService.Create(new UserChangelog(
                null,
                AuthenticationHelpers.GetUserIdFromToken(authToken),
                DateTime.UtcNow,
                "Phone number removed.",
                id,
                JsonSerializer.Serialize(_userService.GetByUserId(id))
            ));

            return Ok();
        }

        [HttpPut("{id:length(24)}/phone/setPrimary/{phoneNumber}")]
        public async Task<IActionResult> SetPrimaryPhoneNumber([FromHeader] string authToken, [FromRoute] string id, [FromRoute] string phoneNumber)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userMgr"))
            {
                return Unauthorized();
            }

            var user = await _userService.Get(id);

            if (user == null)
            {
                return NotFound("user not found");
            }

            if (!user.PhoneNumbers.Exists(p => p.PhoneNumber.Equals(phoneNumber, StringComparison.OrdinalIgnoreCase)))
            {
                return BadRequest("phone number does not exist");
            }

            foreach (PhoneNumberEntry entry in user.PhoneNumbers.Where(p => p.PrimaryFlag))
            {
                _userService.UpdatePhonePrimary(id, entry.PhoneNumber, false);
            }

            _userService.UpdatePhonePrimary(id, phoneNumber, true);

            await _changelogService.Create(new UserChangelog(
                null,
                AuthenticationHelpers.GetUserIdFromToken(authToken),
                DateTime.UtcNow,
                "Primary phone number changed.",
                id,
                JsonSerializer.Serialize(_userService.GetByUserId(id))
            ));

            return Ok();
        }

        [HttpPost("{id:length(24)}/phone/verify/{phoneNumber}/{code}")]
        public async Task<IActionResult> VerifyPhoneNumber([FromHeader] string authToken, [FromRoute] string id, [FromRoute] string phoneNumber, [FromRoute] string code)
        {
            if (!await _authenticationService.CheckAccess(authToken, "userMgr"))
            {
                return Unauthorized();
            }

            var user = await _userService.Get(id);

            if (user == null)
            {
                return NotFound("user not found");
            }

            if (!user.PhoneNumbers.Exists(p => p.PhoneNumber.Equals(phoneNumber, StringComparison.OrdinalIgnoreCase)))
            {
                return BadRequest("phone number does not exist");
            }

            PhoneNumberEntry entry = user.PhoneNumbers.Find(p => p.PhoneNumber.ToLower() == phoneNumber.ToLower());

            if (entry.VerificationCode != code)
            {
                return BadRequest("invalid verification code");
            }

            _userService.VerifyPhone(id, phoneNumber);

            await _changelogService.Create(new UserChangelog(
                null,
                AuthenticationHelpers.GetUserIdFromToken(authToken),
                DateTime.UtcNow,
                "Phone number verified.",
                id,
                JsonSerializer.Serialize(_userService.GetByUserId(id))
            ));

            return Ok();
        }

        [HttpGet("login")]
        public async Task<IActionResult> Login([FromQuery] string username, [FromQuery] string password)
        {
            User user = await _userService.GetByUsername(username);
            string ipAddress = Request.HttpContext.Connection.RemoteIpAddress.ToString();

            if (user == null)
            {
                await _loginLogService.Create(new LoginLog(null, username, ipAddress, "Username does not exist", "Fail"));
                return NotFound("username does not exist");
            }

            if (!AuthenticationHelpers.IsPasswordValid(password, user.Password))
            {
                await _loginLogService.Create(new LoginLog(null, username, ipAddress, "Incorrect password", "Fail"));
                return Unauthorized("incorrect password");
            }

            // Check if user has access to login
            List<Role> userRoles = new List<Role>();

            foreach (string roleId in user.Roles)
            {
                userRoles.Add(await _roleService.Get(roleId));
            }

            if (!AuthenticationHelpers.IsPermissionGranted(user, userRoles, Startup.StaticConfiguration.GetSection("PermissionIds")["login"]))
            {
                await _loginLogService.Create(new LoginLog(null, username, ipAddress, "Login unauthorized", "Fail"));
                return Unauthorized("not authorized for login");
            }

            string authToken = AuthenticationHelpers.GenerateAuthToken(user, await _roleService.Get(), await _permissionService.Get());

            await _tokenService.Create(new Token(
                null,
                user.Id,
                "auth",
                authToken,
                DateTime.UtcNow,
                new List<TokenAction>(),
                false,
                true
            ));

            var createdAuthToken = await _tokenService.GetByToken(authToken);

            string refreshToken = AuthenticationHelpers.GenerateRefreshToken(user, createdAuthToken.Id);

            await _tokenService.Create(new Token(
                null,
                user.Id,
                "refresh",
                refreshToken,
                DateTime.UtcNow,
                new List<TokenAction>(),
                false,
                true
            ));

            await _loginLogService.Create(new LoginLog(null, username, ipAddress, null, "Success"));

            return Ok(
                new Dictionary<string, string>
                {
                    { "authToken", authToken },
                    { "refreshToken", refreshToken }
                }
            );
        }

        [HttpGet("refresh")]
        public async Task<IActionResult> RefreshToken([FromQuery] string refreshToken)
        {
            Token token = await _tokenService.GetByToken(refreshToken);

            if (token == null)
            {
                return NotFound("refresh token not found");
            }

            // Check if token is valid in MongoDB
            if (!token.ValidFlag)
            {
                return Problem("invalidated token");
            }

            if (token.UsedFlag)
            {
                await _tokenService.InvalidateUserTokens(token.UserId);
                return Problem("refresh token already used");
            }

            // Check token validity (Expiration, issuer, audience, etc.)
            if (!AuthenticationHelpers.IsTokenValid(refreshToken))
            {
                return Problem("token failed validation");
            }

            var decodedToken = AuthenticationHelpers.ReadToken(refreshToken);

            await _tokenService.InvalidateToken(decodedToken.Claims.First(c => c.Type == "authTokenId").Value);
            await _tokenService.UseToken(token.Id);
            await _tokenService.AddUsage(token.Id, new TokenAction(DateTime.UtcNow, "Used refresh token to generate new pair."));

            // Generate new token pair
            var user = await _userService.Get(token.UserId);

            string authToken = AuthenticationHelpers.GenerateAuthToken(user, await _roleService.Get(), await _permissionService.Get());

            await _tokenService.Create(new Token(
                null,
                user.Id,
                "auth",
                authToken,
                DateTime.UtcNow,
                new List<TokenAction>(),
                false,
                true
            ));

            var createdAuthToken = await _tokenService.GetByToken(authToken);

            string newRefreshToken = AuthenticationHelpers.GenerateRefreshToken(user, createdAuthToken.Id);

            await _tokenService.Create(new Token(
                null,
                user.Id,
                "refresh",
                newRefreshToken,
                DateTime.UtcNow,
                new List<TokenAction>(),
                false,
                true
            ));

            return Ok(
                new Dictionary<string, string>
                {
                    { "authToken", authToken },
                    { "refreshToken", newRefreshToken }
                }
            );
        }

        private IQueryable<User> GetFiltered(IQueryable<User> query, UserSearchParameters search)
        {
            var result = query;

            if (search == null)
            {
                return result;
            }

            if (!string.IsNullOrEmpty(search.UserId))
            {
                result = result.Where(e => e.UserId.ToLower().Contains(search.UserId.ToLower()));
            }

            if (!string.IsNullOrEmpty(search.LastName))
            {
                result = result.Where(e => !string.IsNullOrEmpty(e.LastName) && e.LastName.ToLower().Contains(search.LastName.ToLower()));
            }

            if (!string.IsNullOrEmpty(search.FirstName))
            {
                result = result.Where(e => !string.IsNullOrEmpty(e.FirstName) && e.FirstName.ToLower().Contains(search.FirstName.ToLower()));
            }

            if (!string.IsNullOrEmpty(search.Username))
            {
                result = result.Where(e => !string.IsNullOrEmpty(e.Username) && e.Username.ToLower().Contains(search.Username.ToLower()));
            }

            if (!string.IsNullOrEmpty(search.Status))
            {
                result = result.Where(e => !string.IsNullOrEmpty(e.Status) && e.Status.ToLower().Contains(search.Status.ToLower()));
            }

            return result;
        }

        public class UserSearchParameters
        {
            public string UserId { get; set; }
            public string LastName { get; set; }
            public string FirstName { get; set; }
            public string Username { get; set; }
            public string Status { get; set; }
        }
    }
}
