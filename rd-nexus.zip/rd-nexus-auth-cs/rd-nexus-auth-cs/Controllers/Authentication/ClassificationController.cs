﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using rd_nexus_auth_cs.Models.Authentication;
using rd_nexus_auth_cs.Services.Authentication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace rd_nexus_auth_cs.Controllers.Authentication
{
    [Route("api/[controller]")]
    [ApiController]
    public class ClassificationController : ControllerBase
    {
        private readonly AuthenticationService _authenticationService;
        private readonly ClassificationService _classificationService;

        public ClassificationController(AuthenticationService authenticationService, ClassificationService classificationService)
        {
            _authenticationService = authenticationService;
            _classificationService = classificationService;
        }

        [HttpGet]
        public async Task<ActionResult<List<Classification>>> Get([FromHeader] string authToken)
        {
            if (!await _authenticationService.CheckAccess(authToken, "classificationView"))
            {
                return Unauthorized();
            }

            return await _classificationService.Get();
        }

        [HttpGet("{id:length(24)}")]
        public async Task<ActionResult<Classification>> Get([FromHeader] string authToken, string id)
        {
            if (!await _authenticationService.CheckAccess(authToken, "classificationView"))
            {
                return Unauthorized();
            }

            var classification = await _classificationService.Get(id);

            if (classification == null)
            {
                return NotFound();
            }

            return classification;
        }

        [HttpPost]
        public async Task<ActionResult<Classification>> Create([FromHeader] string authToken, ClassificationCreate create)
        {
            if (!await _authenticationService.CheckAccess(authToken, "classificationMgr"))
            {
                return Unauthorized();
            }

            Classification created = await _classificationService.Create(create);

            return Ok(create);
        }
    }
}
